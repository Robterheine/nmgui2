"""
NMGUI — NONMEM Run Manager
Flask backend for PSN-based NONMEM run management.
"""

import os
import sys
import json
import time
import signal
import shlex
import subprocess
import platform
import tempfile
import threading
from pathlib import Path
from datetime import datetime
from flask import (
    Flask, render_template, request, jsonify, Response, send_from_directory
)

IS_WINDOWS = os.name == 'nt'

from parser import parse_lst, find_runs, read_table_file, inject_estimates, parse_nmtran_errors, extract_param_names, parse_ext_file, extract_table_files, parse_phi_file

app = Flask(__name__)

# Configuration
HOME = Path.home()
CONFIG_DIR = HOME / '.nmgui'
CONFIG_DIR.mkdir(exist_ok=True)
RUNS_FILE = CONFIG_DIR / 'runs.json'
SETTINGS_FILE = CONFIG_DIR / 'settings.json'
COMMENTS_FILE = CONFIG_DIR / 'comments.json'
META_FILE = CONFIG_DIR / 'model_meta.json'

# Active processes
active_processes = {}
process_lock = threading.Lock()
config_lock = threading.Lock()


def load_model_meta():
    """Load model metadata. Migrates from old comments.json if needed.
    Returns dict: {path: {comment, star, based_on}}"""
    meta = {}
    # Try new format first
    if META_FILE.exists():
        try:
            with open(META_FILE, encoding='utf-8-sig') as f:
                meta = json.load(f)
        except (json.JSONDecodeError, ValueError):
            meta = {}
    # Migrate from old comments.json if meta is empty but comments exist
    if not meta and COMMENTS_FILE.exists():
        try:
            with open(COMMENTS_FILE, encoding='utf-8-sig') as f:
                old = json.load(f)
            for path, val in old.items():
                if isinstance(val, str):
                    meta[path] = {'comment': val, 'star': False, 'based_on': None}
                elif isinstance(val, dict):
                    meta[path] = val
            save_model_meta(meta)
        except (json.JSONDecodeError, ValueError):
            pass
    return meta


def save_model_meta(meta):
    """Save model metadata dict. Caller must hold config_lock."""
    with open(META_FILE, 'w', encoding='utf-8') as f:
        json.dump(meta, f, indent=2)


def get_meta(meta, path):
    """Get metadata for a model path, with defaults."""
    entry = meta.get(path, {})
    if isinstance(entry, str):
        entry = {'comment': entry, 'star': False, 'based_on': None}
    return {
        'comment': entry.get('comment', ''),
        'star': entry.get('star', False),
        'based_on': entry.get('based_on', None),
    }


def load_runs():
    if RUNS_FILE.exists():
        try:
            with open(RUNS_FILE, encoding='utf-8-sig') as f:
                return json.load(f)
        except (json.JSONDecodeError, ValueError):
            return []
    return []


def save_runs(runs):
    with open(RUNS_FILE, 'w', encoding='utf-8') as f:
        json.dump(runs, f, indent=2, default=str)


def load_settings():
    if SETTINGS_FILE.exists():
        with open(SETTINGS_FILE, encoding='utf-8-sig') as f:
            return json.load(f)
    return {'working_directory': str(HOME), 'last_model': '', 'last_tool': 'execute'}


def save_settings(settings):
    with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
        json.dump(settings, f, indent=2)


# ── Routes ──────────────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/api/settings', methods=['GET', 'POST'])
def settings():
    if request.method == 'GET':
        s = load_settings()
        s['home'] = str(HOME)  # Always include home dir
        return jsonify(s)
    else:
        s = load_settings()
        s.update(request.json)
        save_settings(s)
        return jsonify(s)


# ── Bookmarks ───────────────────────────

BOOKMARKS_FILE = CONFIG_DIR / 'bookmarks.json'


def load_bookmarks():
    if BOOKMARKS_FILE.exists():
        try:
            with open(BOOKMARKS_FILE, encoding='utf-8-sig') as f:
                return json.load(f)
        except (json.JSONDecodeError, ValueError):
            return []
    return []


def save_bookmarks(bookmarks):
    with open(BOOKMARKS_FILE, 'w', encoding='utf-8') as f:
        json.dump(bookmarks, f, indent=2)


@app.route('/api/bookmarks', methods=['GET'])
def get_bookmarks():
    return jsonify(load_bookmarks())


@app.route('/api/bookmarks/add', methods=['POST'])
def add_bookmark():
    data = request.json
    path = data.get('path', '')
    description = data.get('description', '')
    if not path or not os.path.isdir(path):
        return jsonify({'error': 'Invalid directory'}), 400
    with config_lock:
        bookmarks = load_bookmarks()
        # Don't duplicate
        if any(b['path'] == path for b in bookmarks):
            # Update description
            for b in bookmarks:
                if b['path'] == path:
                    b['description'] = description
            save_bookmarks(bookmarks)
            return jsonify(bookmarks)
        bookmarks.append({
            'path': path,
            'description': description,
            'name': os.path.basename(path),
            'added': datetime.now().isoformat(),
        })
        save_bookmarks(bookmarks)
    return jsonify(bookmarks)


@app.route('/api/bookmarks/remove', methods=['POST'])
def remove_bookmark():
    path = request.json.get('path', '')
    with config_lock:
        bookmarks = load_bookmarks()
        bookmarks = [b for b in bookmarks if b['path'] != path]
        save_bookmarks(bookmarks)
    return jsonify(bookmarks)


@app.route('/api/bookmarks/update', methods=['POST'])
def update_bookmark():
    data = request.json
    path = data.get('path', '')
    description = data.get('description', '')
    with config_lock:
        bookmarks = load_bookmarks()
        for b in bookmarks:
            if b['path'] == path:
                b['description'] = description
        save_bookmarks(bookmarks)
    return jsonify(bookmarks)


@app.route('/api/browse', methods=['POST'])
def browse_directory():
    """List files/directories at a given path."""
    data = request.json
    path = data.get('path', '').strip()
    filter_ext = data.get('filter', None)

    # Default to home if empty or invalid
    if not path:
        path = str(HOME)

    p = Path(path)
    if not p.exists():
        # Try home as fallback
        p = HOME
        path = str(HOME)

    if not p.is_dir():
        # If it's a file, go to its parent
        p = p.parent
        path = str(p)

    items = []
    try:
        for item in sorted(p.iterdir()):
            if item.name.startswith('.'):
                continue
            # Fix #20: Skip common Windows hidden/system files
            if item.name.lower() in ('desktop.ini', 'thumbs.db', '$recycle.bin', 'system volume information'):
                continue
            try:
                entry = {
                    'name': item.name,
                    'path': str(item),
                    'is_dir': item.is_dir(),
                }
                if item.is_file():
                    entry['size'] = item.stat().st_size
                    entry['ext'] = item.suffix.lower()
                items.append(entry)
            except (PermissionError, OSError):
                continue  # Skip inaccessible items
    except PermissionError:
        return jsonify({'error': 'Permission denied', 'path': str(p), 'parent': str(p.parent)}), 403

    if filter_ext:
        items = [i for i in items if i.get('is_dir') or i.get('ext', '') in filter_ext]

    return jsonify({
        'path': str(p),
        'parent': str(p.parent),
        'items': items
    })


@app.route('/api/file/read', methods=['POST'])
def read_file():
    """Read a text file."""
    filepath = request.json.get('path', '')
    if not os.path.isfile(filepath):
        return jsonify({'error': 'File not found'}), 404
    try:
        with open(filepath, 'r', encoding='utf-8-sig', errors='replace') as f:
            content = f.read()
        return jsonify({'path': filepath, 'content': content, 'name': os.path.basename(filepath)})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/file/save', methods=['POST'])
def save_file():
    """Save content to a file."""
    data = request.json
    filepath = data.get('path', '')
    content = data.get('content', '')
    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        return jsonify({'success': True, 'path': filepath})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/run/start', methods=['POST'])
def start_run():
    """Start a PSN run."""
    data = request.json
    model_path = data.get('model', '')
    tool = data.get('tool', 'execute')
    extra_args = data.get('extra_args', '')
    working_dir = data.get('working_dir', '')
    clean = data.get('clean', True)  # Clean old run artifacts by default

    if not os.path.isfile(model_path):
        return jsonify({'error': 'Model file not found'}), 404

    model_name = os.path.basename(model_path)
    run_name = os.path.splitext(model_name)[0]
    cwd = working_dir or os.path.dirname(model_path)

    # Clean up previous run artifacts if requested
    if clean:
        import shutil
        # Remove old run directory (PSN execute style)
        old_run_dir = os.path.join(cwd, run_name)
        if os.path.isdir(old_run_dir):
            try:
                shutil.rmtree(old_run_dir)
            except Exception as e:
                return jsonify({'error': f'Could not clean old run directory: {e}'}), 500

        # Remove old .lst file in same directory (nmfe style)
        old_lst = os.path.join(cwd, run_name + '.lst')
        if os.path.isfile(old_lst):
            try:
                os.remove(old_lst)
            except Exception:
                pass  # Non-critical

        # Remove FMSG/PRDERR from previous run
        for fname in ['FMSG', 'PRDERR', 'FDATA', 'FREPORT', 'FSUBS', 'FSUBS2',
                       'FSTREAM', 'FCON', 'FLIB', 'LINK.LNK', 'nmprd4p.mod',
                       'INTER', 'OUTPUT', 'nmsub.emod']:
            fpath = os.path.join(cwd, fname)
            if os.path.isfile(fpath):
                try:
                    os.remove(fpath)
                except Exception:
                    pass

    # Build command — resolve tool to full path and quote paths
    import shutil as _shutil
    tool_path = _shutil.which(tool)
    if not tool_path:
        # On macOS, the login shell PATH may differ from /bin/sh PATH.
        # Try sourcing the user's shell profile to get the full PATH.
        if not IS_WINDOWS:
            try:
                shell = os.environ.get('SHELL', '/bin/sh')
                result = subprocess.run(
                    [shell, '-l', '-c', f'which {tool}'],
                    capture_output=True, text=True, timeout=5
                )
                found = result.stdout.strip()
                if found and os.path.isfile(found):
                    tool_path = found
            except Exception:
                pass
    if not tool_path:
        return jsonify({'error': f'"{tool}" not found on PATH. Is PsN installed and on your PATH?'}), 404

    quoted_path = f'"{model_path}"' if IS_WINDOWS else shlex.quote(model_path)
    cmd_parts = [tool_path, quoted_path]

    # Directory = run name (PSN execute)
    if tool == 'execute':
        cmd_parts.append(f'-directory={run_name}')

    if extra_args.strip():
        cmd_parts.extend(extra_args.strip().split())

    cmd = ' '.join(cmd_parts)

    # Run ID
    run_id = f"{run_name}_{int(time.time())}"

    # Log run
    run_info = {
        'id': run_id,
        'run_name': run_name,
        'model': model_path,
        'tool': tool,
        'command': cmd,
        'working_dir': working_dir or os.path.dirname(model_path),
        'status': 'running',
        'started': datetime.now().isoformat(),
        'finished': None,
        'output_dir': os.path.join(working_dir or os.path.dirname(model_path), run_name),
    }

    runs = load_runs()
    runs.insert(0, run_info)
    save_runs(runs)

    # Start process
    try:
        # Get the user's full environment (including Homebrew, PsN paths)
        run_env = os.environ.copy()
        if not IS_WINDOWS:
            # On macOS/Linux, /bin/sh may have a stripped PATH.
            # Ensure subprocess gets the same PATH as the user's login shell.
            try:
                shell = os.environ.get('SHELL', '/bin/sh')
                env_result = subprocess.run(
                    [shell, '-l', '-c', 'echo $PATH'],
                    capture_output=True, text=True, timeout=5
                )
                login_path = env_result.stdout.strip()
                if login_path:
                    run_env['PATH'] = login_path
            except Exception:
                pass

        popen_kwargs = dict(
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            cwd=cwd,
            text=True,
            bufsize=1,
            env=run_env,
        )
        if IS_WINDOWS:
            popen_kwargs['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            popen_kwargs['preexec_fn'] = os.setsid

        proc = subprocess.Popen(cmd, **popen_kwargs)
        with process_lock:
            active_processes[run_id] = {
                'process': proc,
                'output': [],
                'run_info': run_info,
            }

        # Background thread to capture output
        def capture_output(rid, process):
            try:
                for line in iter(process.stdout.readline, ''):
                    with process_lock:
                        if rid in active_processes:
                            active_processes[rid]['output'].append(line)
                process.wait()
            finally:
                # Update run status
                runs = load_runs()
                for r in runs:
                    if r['id'] == rid:
                        r['status'] = 'finished' if process.returncode == 0 else 'failed'
                        r['finished'] = datetime.now().isoformat()
                        r['return_code'] = process.returncode
                        break
                save_runs(runs)

        t = threading.Thread(target=capture_output, args=(run_id, proc), daemon=True)
        t.start()

        return jsonify({'run_id': run_id, 'command': cmd, 'pid': proc.pid})

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/run/stop', methods=['POST'])
def stop_run():
    """Stop a running process."""
    run_id = request.json.get('run_id', '')
    with process_lock:
        if run_id in active_processes:
            proc = active_processes[run_id]['process']
            try:
                if IS_WINDOWS:
                    proc.terminate()
                else:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            except (ProcessLookupError, OSError):
                pass
            return jsonify({'success': True})
    return jsonify({'error': 'Process not found'}), 404


@app.route('/api/run/output/<run_id>')
def stream_output(run_id):
    """SSE stream for live run output."""
    def generate():
        idx = 0
        while True:
            with process_lock:
                if run_id not in active_processes:
                    yield f"data: {json.dumps({'type': 'done'})}\n\n"
                    return
                output = active_processes[run_id]['output']
                proc = active_processes[run_id]['process']

            while idx < len(output):
                line = output[idx]
                yield f"data: {json.dumps({'type': 'line', 'text': line})}\n\n"
                idx += 1

            if proc.poll() is not None:
                # Process finished, send remaining
                with process_lock:
                    remaining = active_processes[run_id]['output'][idx:]
                for line in remaining:
                    yield f"data: {json.dumps({'type': 'line', 'text': line})}\n\n"
                yield f"data: {json.dumps({'type': 'done', 'returncode': proc.returncode})}\n\n"
                # Clean up
                with process_lock:
                    if run_id in active_processes:
                        del active_processes[run_id]
                return

            time.sleep(0.3)

    return Response(generate(), mimetype='text/event-stream',
                    headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'})


@app.route('/api/runs')
def list_runs():
    """List all tracked runs."""
    return jsonify(load_runs())


@app.route('/api/runs/scan', methods=['POST'])
def scan_runs():
    """Scan a directory for NONMEM run results."""
    directory = request.json.get('directory', '')
    if not directory:
        return jsonify({'error': 'No directory specified'}), 400
    results = find_runs(directory)
    # Strip raw_text to avoid massive JSON responses
    for r in results:
        r.pop('raw_text', None)
    return jsonify(results)


@app.route('/api/run/parse', methods=['POST'])
def parse_run():
    """Parse a specific .lst file."""
    lst_path = request.json.get('path', '')
    if not lst_path:
        return jsonify({'error': 'No path specified'}), 400
    result = parse_lst(lst_path)
    # Don't send raw text in the list view
    result.pop('raw_text', None)
    return jsonify(result)


@app.route('/api/run/lst', methods=['POST'])
def get_lst():
    """Get raw .lst file content."""
    lst_path = request.json.get('path', '')
    if not os.path.isfile(lst_path):
        return jsonify({'error': 'File not found'}), 404
    with open(lst_path, 'r', encoding='utf-8-sig', errors='replace') as f:
        return jsonify({'content': f.read()})


@app.route('/api/data/read', methods=['POST'])
def read_data():
    """Read a data file (CSV, tab, dat) for the viewer."""
    filepath = request.json.get('path', '')
    max_rows = request.json.get('max_rows', 5000)
    header, rows = read_table_file(filepath, max_rows)
    if header is None:
        return jsonify({'error': 'Could not parse file'}), 400
    return jsonify({
        'columns': header,
        'data': rows,
        'n_rows': len(rows),
        'path': filepath,
        'name': os.path.basename(filepath)
    })


@app.route('/api/data/columns', methods=['POST'])
def get_column_values():
    """Get unique values for a column (for filtering)."""
    filepath = request.json.get('path', '')
    column = request.json.get('column', '')
    header, rows = read_table_file(filepath, 10000)
    if header is None or column not in header:
        return jsonify({'error': 'Column not found'}), 400
    col_idx = header.index(column)
    unique = sorted(set(str(row[col_idx]) for row in rows if col_idx < len(row)))
    return jsonify({'column': column, 'values': unique[:200]})


@app.route('/api/run/delete', methods=['POST'])
def delete_run():
    """Remove a run from tracking (does not delete files)."""
    run_id = request.json.get('run_id', '')
    runs = load_runs()
    runs = [r for r in runs if r['id'] != run_id]
    save_runs(runs)
    return jsonify({'success': True})


@app.route('/api/models/scan', methods=['POST'])
def scan_models():
    """Scan a directory for .mod/.ctl files, extract $PROBLEM, check run status."""
    directory = request.json.get('directory', '')
    if not directory or not os.path.isdir(directory):
        return jsonify({'error': 'Invalid directory'}), 400

    models = []
    p = Path(directory)
    all_meta = load_model_meta()

    for f in sorted(p.iterdir()):
        if not f.is_file():
            continue
        ext = f.suffix.lower()
        if ext not in ('.mod', '.ctl'):
            continue

        model = {
            'name': f.name,
            'path': str(f),
            'stem': f.stem,
            'ext': ext,
            'problem': '',
            'has_run': False,
            'run_dir': '',
            'lst_path': '',
            'ofv': None,
            'minimization_successful': None,
            'minimization_message': '',
            'covariance_step': None,
            'thetas': [],
            'omegas': [],
            'sigmas': [],
            'omega_matrix': [],
            'sigma_matrix': [],
            'theta_ses': [],
            'omega_ses': [],
            'sigma_ses': [],
            'omega_se_matrix': [],
            'sigma_se_matrix': [],
            'condition_number': None,
            'eta_shrinkage': [],
            'eps_shrinkage': [],
            'runtime': None,
            'n_thetas': 0,
            'n_omegas': 0,
            'data_file': '',
            'theta_names': [],
            'omega_names': [],
            'sigma_names': [],
            'theta_units': [],
            'omega_units': [],
            'sigma_units': [],
            'theta_fixed': [],
            'omega_fixed': [],
            'sigma_fixed': [],
            'correlation_matrix': [],
            'cor_labels': [],
            'n_individuals': None,
            'n_observations': None,
            'sig_digits': None,
            'boundary': False,
            'n_estimated_params': None,
            'aic': None,
            'bic': None,
            'estimation_method': '',
            'cov_failure_reason': '',
            'etabar': [],
            'etabar_se': [],
            'etabar_pval': [],
            'stale': False,
            'table_files': [],
            'table_runno': '',
        }

        # Extract $PROBLEM, $DATA, and parameter names from control stream
        mod_mtime = f.stat().st_mtime
        data_mtime = None
        try:
            with open(f, 'r', encoding='utf-8-sig', errors='replace') as fh:
                content = fh.read()
            import re as _re
            prob = _re.search(r'\$PROB(?:LEM)?\s+(.*?)(?:\n|\$)', content, _re.IGNORECASE)
            if prob:
                model['problem'] = prob.group(1).strip()[:120]
            data = _re.search(r'\$DATA\s+(\S+)', content, _re.IGNORECASE)
            if data:
                model['data_file'] = data.group(1).strip()
                # Resolve data file path for stale detection
                data_path = os.path.join(str(p), model['data_file'])
                if os.path.isfile(data_path):
                    data_mtime = os.path.getmtime(data_path)
            # Extract parameter names from comments
            pnames = extract_param_names(content)
            model['theta_names'] = pnames['theta_names']
            model['omega_names'] = pnames['omega_names']
            model['sigma_names'] = pnames['sigma_names']
            model['theta_units'] = pnames.get('theta_units', [])
            model['omega_units'] = pnames.get('omega_units', [])
            model['sigma_units'] = pnames.get('sigma_units', [])
            model['theta_fixed'] = pnames['theta_fixed']
            model['omega_fixed'] = pnames['omega_fixed']
            model['sigma_fixed'] = pnames['sigma_fixed']
            # Extract $TABLE file names and auto-detect runno
            tfiles = extract_table_files(content)
            model['table_files'] = tfiles['table_files']
            model['table_runno'] = tfiles['runno']
        except Exception:
            pass

        # Check for matching .lst file
        # Strategy 1: .lst in same directory (nmfe direct execution)
        lst_same_dir = p / (f.stem + '.lst')
        # Strategy 2: .lst in subdirectory (PSN execute -directory)
        run_dir = p / f.stem
        lst_in_subdir = None
        if run_dir.is_dir():
            lst_candidates = list(run_dir.glob('*.lst'))
            if lst_candidates:
                lst_in_subdir = lst_candidates[0]

        # Pick the .lst file — prefer same-dir, fallback to subdir
        lst_path = None
        if lst_same_dir.is_file():
            lst_path = lst_same_dir
            model['run_dir'] = str(p)
        elif lst_in_subdir:
            lst_path = lst_in_subdir
            model['run_dir'] = str(run_dir)

        if lst_path:
            model['has_run'] = True
            model['lst_path'] = str(lst_path)
            result = parse_lst(str(lst_path))
            for key in ('ofv', 'minimization_successful', 'minimization_message',
                        'covariance_step',
                        'n_individuals', 'n_observations', 'sig_digits',
                        'boundary', 'n_estimated_params', 'aic', 'bic',
                        'thetas', 'omegas', 'sigmas',
                        'omega_matrix', 'sigma_matrix',
                        'theta_ses', 'omega_ses', 'sigma_ses',
                        'omega_se_matrix', 'sigma_se_matrix',
                        'correlation_matrix', 'cor_labels',
                        'estimation_method',
                        'cov_failure_reason', 'etabar', 'etabar_se', 'etabar_pval',
                        'condition_number', 'eta_shrinkage',
                        'eps_shrinkage', 'runtime'):
                model[key] = result.get(key)
            model['n_thetas'] = len(result.get('thetas', []))
            model['n_omegas'] = len(result.get('omegas', []))

            # Stale detection: .mod or $DATA modified after .lst (2s tolerance)
            lst_mtime = lst_path.stat().st_mtime
            if mod_mtime > lst_mtime + 2:
                model['stale'] = True
            elif data_mtime and data_mtime > lst_mtime + 2:
                model['stale'] = True

        # Model metadata (comment, star, based_on)
        meta = get_meta(all_meta, str(f))
        model['comment'] = meta['comment']
        model['star'] = meta['star']
        model['based_on'] = meta['based_on']
        models.append(model)

    return jsonify(models)


@app.route('/api/model/duplicate', methods=['POST'])
def duplicate_model():
    """Duplicate a model file, optionally injecting final estimates with jitter."""
    data = request.json
    source_path = data.get('source', '')
    new_name = data.get('new_name', '')
    use_estimates = data.get('use_estimates', False)
    jitter = data.get('jitter', 0)  # e.g. 0.2 for ±20%

    if not os.path.isfile(source_path):
        return jsonify({'error': 'Source file not found'}), 404

    source_dir = os.path.dirname(source_path)
    new_path = os.path.join(source_dir, new_name)

    if os.path.exists(new_path):
        return jsonify({'error': f'{new_name} already exists'}), 400

    with open(source_path, 'r', encoding='utf-8-sig', errors='replace') as f:
        content = f.read()

    if use_estimates:
        stem = os.path.splitext(os.path.basename(source_path))[0]
        lst_path = os.path.join(source_dir, stem + '.lst')
        if not os.path.isfile(lst_path):
            lst_in_subdir = os.path.join(source_dir, stem, stem + '.lst')
            if os.path.isfile(lst_in_subdir):
                lst_path = lst_in_subdir
            else:
                return jsonify({'error': 'No .lst file found for this model'}), 404
        content = inject_estimates(content, lst_path, jitter=float(jitter) if jitter else 0)

    with open(new_path, 'w', encoding='utf-8') as f:
        f.write(content)

    # Store ancestry: new model is based_on the source model's stem
    source_stem = os.path.splitext(os.path.basename(source_path))[0]
    with config_lock:
        meta = load_model_meta()
        entry = get_meta(meta, new_path)
        entry['based_on'] = source_stem
        meta[new_path] = entry
        save_model_meta(meta)

    return jsonify({'success': True, 'path': new_path, 'name': new_name})


@app.route('/api/model/errors', methods=['POST'])
def model_errors():
    """Get NMTRAN errors for a model."""
    model_path = request.json.get('path', '')
    if not model_path:
        return jsonify({'errors': []})

    base_dir = os.path.dirname(model_path)
    stem = os.path.splitext(os.path.basename(model_path))[0]
    errors = parse_nmtran_errors(base_dir, stem)
    return jsonify({'errors': errors})


@app.route('/api/ext/read', methods=['POST'])
def read_ext():
    """Read a NONMEM .ext file for convergence data."""
    model_path = request.json.get('path', '')
    if not model_path:
        return jsonify({'error': 'No path specified'}), 400

    stem = os.path.splitext(os.path.basename(model_path))[0]
    base_dir = os.path.dirname(model_path)

    # Look for .ext in same dir, then in run subdir
    ext_path = os.path.join(base_dir, stem + '.ext')
    if not os.path.isfile(ext_path):
        ext_path = os.path.join(base_dir, stem, stem + '.ext')
    if not os.path.isfile(ext_path):
        # Try modelfit_dir pattern and PsN 5.5+ patterns
        for subdir in [stem, stem + '_modelfit', stem + '.dir', stem + '.mod.dir']:
            candidate = os.path.join(base_dir, subdir)
            if os.path.isdir(candidate):
                for f in os.listdir(candidate):
                    if f.endswith('.ext'):
                        ext_path = os.path.join(candidate, f)
                        break

    if not os.path.isfile(ext_path):
        return jsonify({'error': '.ext file not found'}), 404

    result = parse_ext_file(ext_path)
    if result is None:
        return jsonify({'error': 'Could not parse .ext file'}), 400
    return jsonify(result)


@app.route('/api/phi/read', methods=['POST'])
def read_phi():
    """Read a NONMEM .phi file for individual OBJ contributions."""
    model_path = request.json.get('path', '')
    if not model_path:
        return jsonify({'error': 'No path specified'}), 400

    stem = os.path.splitext(os.path.basename(model_path))[0]
    base_dir = os.path.dirname(model_path)

    # Look for .phi in same dir, then in run subdir
    phi_path = os.path.join(base_dir, stem + '.phi')
    if not os.path.isfile(phi_path):
        phi_path = os.path.join(base_dir, stem, stem + '.phi')
    if not os.path.isfile(phi_path):
        for subdir in [stem, stem + '_modelfit', stem + '.dir', stem + '.mod.dir']:
            candidate = os.path.join(base_dir, subdir)
            if os.path.isdir(candidate):
                for f in os.listdir(candidate):
                    if f.endswith('.phi'):
                        phi_path = os.path.join(candidate, f)
                        break

    if not os.path.isfile(phi_path):
        return jsonify({'error': '.phi file not found. NONMEM 7.2+ produces this file automatically.'}), 404

    result = parse_phi_file(phi_path)
    if not result['ids']:
        return jsonify({'error': 'Could not parse .phi file or no data found'}), 400
    return jsonify(result)


@app.route('/api/comments', methods=['GET'])
def get_comments():
    """Get all model comments."""
    return jsonify(load_model_meta())


@app.route('/api/comments/save', methods=['POST'])
def save_comment():
    """Save a comment for a model."""
    model_path = request.json.get('path', '')
    comment = request.json.get('comment', '')
    if not model_path:
        return jsonify({'error': 'No path'}), 400
    with config_lock:
        meta = load_model_meta()
        entry = get_meta(meta, model_path)
        entry['comment'] = comment.strip()
        if entry['comment'] or entry['star'] or entry['based_on']:
            meta[model_path] = entry
        else:
            meta.pop(model_path, None)
        save_model_meta(meta)
    return jsonify({'ok': True})


@app.route('/api/model/star', methods=['POST'])
def toggle_star():
    """Toggle star status for a model."""
    model_path = request.json.get('path', '')
    if not model_path:
        return jsonify({'error': 'No path'}), 400
    with config_lock:
        meta = load_model_meta()
        entry = get_meta(meta, model_path)
        entry['star'] = not entry['star']
        if entry['comment'] or entry['star'] or entry['based_on']:
            meta[model_path] = entry
        else:
            meta.pop(model_path, None)
        save_model_meta(meta)
    return jsonify({'ok': True, 'star': entry['star']})


@app.route('/api/model/tree', methods=['POST'])
def model_tree():
    """Return model ancestry tree for visualization."""
    directory = request.json.get('directory', '')
    if not directory or not os.path.isdir(directory):
        return jsonify({'error': 'Invalid directory'}), 400

    all_meta = load_model_meta()
    p = Path(directory)
    nodes = []
    edges = []
    stems = set()

    for f in sorted(p.iterdir()):
        if not f.is_file() or f.suffix.lower() not in ('.mod', '.ctl'):
            continue
        meta = get_meta(all_meta, str(f))
        node = {
            'id': f.stem,
            'name': f.stem,
            'star': meta['star'],
            'based_on': meta['based_on'],
            'comment': meta['comment'],
            'ofv': None,
            'status': None,
            'estimation_method': '',
            'stale': False,
        }

        # Parse .lst for summary info
        lst = p / (f.stem + '.lst')
        run_dir = p / f.stem
        if not lst.is_file() and run_dir.is_dir():
            lst_candidates = list(run_dir.glob('*.lst'))
            if lst_candidates:
                lst = lst_candidates[0]
        if lst.is_file():
            result = parse_lst(str(lst))
            node['ofv'] = result.get('ofv')
            node['status'] = result.get('minimization_message', '')
            node['estimation_method'] = result.get('estimation_method', '')
            # Stale check
            if f.stat().st_mtime > lst.stat().st_mtime + 2:
                node['stale'] = True

        nodes.append(node)
        stems.add(f.stem)

        if meta['based_on'] and meta['based_on'] in stems:
            edges.append({'from': meta['based_on'], 'to': f.stem})

    # Second pass: add edges for based_on referencing earlier models
    for node in nodes:
        if node['based_on'] and node['based_on'] in stems:
            edge = {'from': node['based_on'], 'to': node['id']}
            if edge not in edges:
                edges.append(edge)

    return jsonify({'nodes': nodes, 'edges': edges})


@app.route('/api/launch/rstudio', methods=['POST'])
def launch_rstudio():
    """Launch RStudio with a given working directory."""
    directory = request.json.get('directory', '')
    if not directory or not os.path.isdir(directory):
        return jsonify({'error': 'Invalid directory'}), 400

    # Find or create an .Rproj file — this is how RStudio opens a directory as a project
    rproj_files = [f for f in os.listdir(directory) if f.endswith('.Rproj')]
    if rproj_files:
        rproj_path = os.path.join(directory, rproj_files[0])
    else:
        # Create a minimal .Rproj file
        proj_name = os.path.basename(directory.rstrip('/'))
        rproj_path = os.path.join(directory, proj_name + '.Rproj')
        try:
            with open(rproj_path, 'w', encoding='utf-8') as f:
                f.write('Version: 1.0\n\nRestoreWorkspace: Default\nSaveWorkspace: Default\nAlwaysSaveHistory: Default\n')
        except Exception as e:
            return jsonify({'error': f'Cannot create .Rproj file: {e}'}), 500

    system = platform.system()
    try:
        if system == 'Darwin':
            subprocess.Popen(['open', '-a', 'RStudio', rproj_path])
        elif system == 'Linux':
            subprocess.Popen(['rstudio', rproj_path],
                             preexec_fn=os.setsid if not IS_WINDOWS else None)
        elif system == 'Windows':
            rstudio_paths = [
                os.path.expandvars(r'%LOCALAPPDATA%\Programs\Posit\RStudio\rstudio.exe'),
                os.path.expandvars(r'%PROGRAMFILES%\Posit\RStudio\rstudio.exe'),
                os.path.expandvars(r'%PROGRAMFILES%\RStudio\rstudio.exe'),
                os.path.expandvars(r'%PROGRAMFILES%\RStudio\bin\rstudio.exe'),
                os.path.expandvars(r'%LOCALAPPDATA%\Programs\RStudio\rstudio.exe'),
                'rstudio',
            ]
            launched = False
            for rpath in rstudio_paths:
                try:
                    subprocess.Popen([rpath, rproj_path])
                    launched = True
                    break
                except FileNotFoundError:
                    continue
            if not launched:
                return jsonify({'error': 'RStudio not found. Install it or add it to PATH.'}), 404
        else:
            return jsonify({'error': f'Unsupported platform: {system}'}), 400
        return jsonify({'ok': True})
    except FileNotFoundError:
        return jsonify({'error': 'RStudio not found. Install it or add it to PATH.'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500


def _find_rscript():
    """Find Rscript executable. Checks PATH, login shell, Windows install dirs."""
    import shutil as _sh
    rscript = _sh.which('Rscript')
    if rscript:
        return rscript
    # macOS/Linux: try login shell PATH (Homebrew, etc.)
    if not IS_WINDOWS:
        try:
            shell = os.environ.get('SHELL', '/bin/sh')
            rv = subprocess.run(
                [shell, '-l', '-c', 'which Rscript'],
                capture_output=True, text=True, timeout=5
            )
            found = rv.stdout.strip()
            if found and os.path.isfile(found):
                return found
        except Exception:
            pass
    if IS_WINDOWS:
        import glob
        search_patterns = [
            os.path.expandvars(r'%PROGRAMFILES%\R\R-*\bin\Rscript.exe'),
            os.path.expandvars(r'%PROGRAMFILES%\R\R-*\bin\x64\Rscript.exe'),
            os.path.expandvars(r'%LOCALAPPDATA%\Programs\R\R-*\bin\Rscript.exe'),
        ]
        for pattern in search_patterns:
            matches = sorted(glob.glob(pattern), reverse=True)
            if matches:
                return matches[0]
    return None


def _get_r_env():
    """Get environment dict with login shell PATH for R subprocess."""
    run_env = os.environ.copy()
    if not IS_WINDOWS:
        try:
            shell = os.environ.get('SHELL', '/bin/sh')
            rv = subprocess.run(
                [shell, '-l', '-c', 'echo $PATH'],
                capture_output=True, text=True, timeout=5
            )
            login_path = rv.stdout.strip()
            if login_path:
                run_env['PATH'] = login_path
        except Exception:
            pass
    return run_env


def _sanitize_for_r(s):
    """Escape a string for safe embedding in R double-quoted strings."""
    return s.replace('\\', '/').replace('"', '\\"')


@app.route('/api/r/check', methods=['GET'])
def check_r():
    """Check if R and vpc/xpose/xpose4 packages are available."""
    result = {'r_available': False, 'r_version': '', 'vpc_available': False, 'xpose_available': False, 'xpose4_available': False}
    rscript = _find_rscript()
    if not rscript:
        return jsonify(result)
    r_env = _get_r_env()
    try:
        rv = subprocess.run([rscript, '--version'], capture_output=True, text=True, timeout=10, env=r_env)
        version_text = rv.stderr.strip() or rv.stdout.strip()
        result['r_available'] = True
        result['r_version'] = version_text[:80]
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return jsonify(result)

    # Check vpc package
    try:
        rv = subprocess.run(
            [rscript, '-e', 'library(vpc); cat("OK")'],
            capture_output=True, text=True, timeout=15, env=r_env
        )
        result['vpc_available'] = 'OK' in rv.stdout
    except Exception:
        pass

    # Check xpose package (tidyverse)
    try:
        rv = subprocess.run(
            [rscript, '-e', 'library(xpose); cat("OK")'],
            capture_output=True, text=True, timeout=15, env=r_env
        )
        result['xpose_available'] = 'OK' in rv.stdout
    except Exception:
        pass

    # Check xpose4 package (legacy)
    try:
        rv = subprocess.run(
            [rscript, '-e', 'library(xpose4); cat("OK")'],
            capture_output=True, text=True, timeout=15, env=r_env
        )
        result['xpose4_available'] = 'OK' in rv.stdout
    except Exception:
        pass

    return jsonify(result)


@app.route('/api/vpc/generate', methods=['POST'])
def generate_vpc():
    """Generate a VPC plot using R's vpc, xpose, or xpose4 package."""
    data = request.json
    vpc_folder = data.get('folder', '')
    tool = data.get('tool', 'vpc')
    custom_script = data.get('custom_script', '')

    if not vpc_folder or not os.path.isdir(vpc_folder):
        return jsonify({'error': 'VPC folder not found'}), 400

    # Normalize paths for R
    r_vpc_folder = _sanitize_for_r(vpc_folder)
    output_png = os.path.join(vpc_folder, 'nmgui_vpc.png')
    r_output_png = _sanitize_for_r(output_png)

    # ── Auto-unzip m1.zip if m1/ doesn't exist ──
    m1_dir = os.path.join(vpc_folder, 'm1')
    m1_zip = os.path.join(vpc_folder, 'm1.zip')
    if not os.path.isdir(m1_dir) and os.path.isfile(m1_zip):
        try:
            import zipfile
            with zipfile.ZipFile(m1_zip, 'r') as zf:
                # Safety: reject entries with path traversal
                for name in zf.namelist():
                    if name.startswith('/') or '..' in name:
                        return jsonify({'error': 'm1.zip contains unsafe paths'}), 400
                zf.extractall(vpc_folder)
        except Exception as e:
            return jsonify({'error': f'Failed to unzip m1.zip: {e}'}), 500

    # ── Validate folder contents (all tools, not just vpc) ──
    if not custom_script:
        folder_contents = os.listdir(vpc_folder)
        has_vpctab = any(f.startswith('vpctab') for f in folder_contents)
        has_m1 = os.path.isdir(m1_dir)
        has_vpc_results = any(f.startswith('vpc_results') for f in folder_contents)

        if tool == 'vpc' and not has_vpctab and not has_m1:
            return jsonify({
                'error': 'VPC folder missing PsN output (vpctab* or m1/). '
                         'Run PsN vpc first, then point to the output directory.'
            }), 400
        elif tool in ('xpose4',) and not has_vpc_results:
            return jsonify({
                'error': 'VPC folder missing vpc_results.csv. '
                         'This file is produced by PsN vpc.'
            }), 400

    # ── Resolve run directory (for xpose/xpose4 which need sdtab files) ──
    run_dir = data.get('run_dir', '').strip()
    r_run_dir = r_vpc_folder  # default for vpc tool (doesn't use run_dir)
    if tool == 'xpose':
        if run_dir and os.path.isdir(run_dir):
            r_run_dir = _sanitize_for_r(run_dir)
        elif run_dir:
            return jsonify({
                'error': f'Run directory not found: {run_dir}. '
                         'Point this to the directory containing sdtab/patab files from the original model run.'
            }), 400
        else:
            # Try auto-detect: look for sdtab* in vpc_folder first (PsN copies them),
            # otherwise warn the user
            has_sdtab = any(f.startswith('sdtab') for f in os.listdir(vpc_folder))
            if has_sdtab:
                r_run_dir = r_vpc_folder
            else:
                return jsonify({
                    'error': 'Run directory required for xpose. '
                             'Set it to the directory containing sdtab/patab files from the original NONMEM run '
                             '(e.g., the PsN execute output folder).'
                }), 400

    # ── Validate numeric inputs ──
    nbins = data.get('nbins', '8')
    try:
        nbins_int = int(nbins)
        if nbins_int < 1 or nbins_int > 100:
            nbins_int = 8
    except (ValueError, TypeError):
        nbins_int = 8

    lloq_val = data.get('lloq', '').strip()
    if lloq_val:
        try:
            float(lloq_val)
        except ValueError:
            return jsonify({'error': f'LLOQ must be numeric, got: {lloq_val}'}), 400

    # ── Build R script ──
    if custom_script:
        r_script = custom_script
    elif tool == 'vpc':
        pred_corr = 'TRUE' if data.get('pred_corr') else 'FALSE'
        lloq = lloq_val if lloq_val else 'NULL'
        bins = _sanitize_for_r(data.get('bins', 'jenks'))
        strat = data.get('stratify', '').strip()
        log_y = data.get('log_y', False)

        # PI/CI: frontend sends float like 0.95
        pi_raw = data.get('pi', '0.95')
        ci_raw = data.get('ci', '0.95')
        try:
            pi_level = float(pi_raw)
            pi_lo = round((1 - pi_level) / 2, 4)
            pi_hi = round(1 - pi_lo, 4)
        except (ValueError, TypeError):
            pi_lo, pi_hi = 0.025, 0.975
        try:
            ci_level = float(ci_raw)
            ci_lo = round((1 - ci_level) / 2, 4)
            ci_hi = round(1 - ci_lo, 4)
        except (ValueError, TypeError):
            ci_lo, ci_hi = 0.025, 0.975

        # Stratify
        if strat:
            vars_list = [_sanitize_for_r(v.strip()) for v in strat.split(',') if v.strip()]
            strat_line = '  stratify = c(' + ', '.join(f'"{v}"' for v in vars_list) + '),'
        else:
            strat_line = ''
        log_line = '  log_y = TRUE,' if log_y else ''

        r_script = f'''library(vpc)
library(ggplot2)

tryCatch({{
  vpc_plot <- vpc(
    psn_folder = "{r_vpc_folder}",
    pred_corr  = {pred_corr},
    lloq       = {lloq},
    bins       = "{bins}",
    n_bins     = {nbins_int},
  {strat_line}
    pi         = c({pi_lo}, {pi_hi}),
    ci         = c({ci_lo}, {ci_hi}),
  {log_line}
    show       = list(obs_dv = TRUE, obs_ci = TRUE, pi = TRUE, pi_as_area = TRUE, pi_ci = TRUE, obs_median = TRUE)
  )
  if (is.null(vpc_plot)) stop("vpc() returned NULL — check vpctab/m1 folder contents")
  ggsave("{r_output_png}", vpc_plot, width = 8, height = 6, dpi = 150)
  cat("NMGUI_VPC_OK")
}}, error = function(e) {{
  cat("NMGUI_VPC_ERROR:", conditionMessage(e), "\\n")
}})
'''
    elif tool == 'xpose':
        runno = data.get('runno', '').strip() or '001'
        runno = _sanitize_for_r(runno)
        strat = data.get('stratify', '').strip()
        pred_corr = data.get('pred_corr', False)
        log_y = data.get('log_y', False)

        vpc_opt_parts = [f'n_bins = {nbins_int}']
        if lloq_val:
            vpc_opt_parts.append(f'lloq = {lloq_val}')
        if pred_corr:
            vpc_opt_parts.append('pred_corr = TRUE')

        vpc_data_parts = [f'opt = vpc_opt({", ".join(vpc_opt_parts)})']
        if strat:
            vars_list = [_sanitize_for_r(v.strip()) for v in strat.split(',') if v.strip()]
            if len(vars_list) == 1:
                vpc_data_parts.append(f'stratify = "{vars_list[0]}"')
            else:
                vpc_data_parts.append('stratify = c(' + ', '.join(f'"{v}"' for v in vars_list) + ')')

        vpc_data_parts.append(f'psn_folder = "{r_vpc_folder}"')

        vpc_call = 'vpc()'
        if log_y:
            vpc_call = 'vpc() + ggplot2::scale_y_log10()'

        r_script = f'''library(xpose)
library(ggplot2)

tryCatch({{
  # Try loading model database from run directory
  xpdb <- xpose_data(runno = "{runno}", dir = "{r_run_dir}/")

  # Add VPC simulation data from PsN vpc output folder
  vpc_plot <- xpdb %>%
    vpc_data({", ".join(vpc_data_parts)}) %>%
    {vpc_call}

  if (is.null(vpc_plot)) stop("xpose vpc() returned NULL")
  ggsave("{r_output_png}", vpc_plot, width = 8, height = 6, dpi = 150)
  cat("NMGUI_VPC_OK")
}}, error = function(e) {{
  msg <- conditionMessage(e)
  # Help the user figure out the right runno and directory
  lst_files  <- list.files("{r_run_dir}", pattern = "\\\\.lst$")
  sdtab_files <- list.files("{r_run_dir}", pattern = "^sdtab")
  # Also check subdirectories (PsN execute -directory creates a subfolder)
  sub_sdtab <- character(0)
  subdirs <- list.dirs("{r_run_dir}", recursive = FALSE)
  for (d in subdirs) {{
    found <- list.files(d, pattern = "^sdtab")
    if (length(found) > 0) sub_sdtab <- c(sub_sdtab, paste0(basename(d), "/", found))
  }}
  cat("NMGUI_VPC_ERROR:", msg, "\\n")
  cat("  .lst files in run dir:", paste(lst_files, collapse = ", "), "\\n")
  cat("  sdtab files in run dir:", paste(sdtab_files, collapse = ", "), "\\n")
  if (length(sub_sdtab) > 0) cat("  sdtab in subdirs:", paste(sub_sdtab, collapse = ", "), "\\n")
  if (length(sdtab_files) == 0 && length(sub_sdtab) > 0) {{
    subdir <- dirname(sub_sdtab[1])
    cat("  ** Try setting Run directory to:", file.path("{r_run_dir}", subdir), "\\n")
  }}
  cat("  Hint: set Run number to match file names (e.g. sdtab001 -> runno = 001)\\n")
}})
'''
    elif tool == 'xpose4':
        # xpose4 VPC: read vpctab directly from PsN output — no xpose.data() needed
        r_script = f'''library(xpose4)

tryCatch({{
  # Find vpctab in PsN vpc output folder
  vpctab_files <- list.files("{r_vpc_folder}", pattern = "^vpctab", full.names = TRUE)
  if (length(vpctab_files) == 0) stop("No vpctab file found in VPC folder")
  vpctab_file <- vpctab_files[1]

  vpc_info <- file.path("{r_vpc_folder}", "vpc_results.csv")
  if (!file.exists(vpc_info)) stop("vpc_results.csv not found in VPC folder")

  png("{r_output_png}", width = 1200, height = 900, res = 150)
  print(xpose.VPC(vpctab = vpctab_file, vpc.info = vpc_info))
  dev.off()
  cat("NMGUI_VPC_OK")
}}, error = function(e) {{
  try(dev.off(), silent = TRUE)
  cat("NMGUI_VPC_ERROR:", conditionMessage(e), "\\n")
}})
'''
    else:
        return jsonify({'error': f'Unknown tool: {tool}'}), 400

    # ── Write R script ──
    # Add tool marker for debugging
    r_script = f'# NMGUI VPC — tool: {tool}\n' + r_script

    # Delete previous output to prevent stale image serving
    if os.path.isfile(output_png):
        try:
            os.remove(output_png)
        except Exception:
            pass

    script_path = os.path.join(vpc_folder, 'nmgui_vpc_script.R')
    try:
        with open(script_path, 'w', encoding='utf-8') as f:
            f.write(r_script)
    except Exception as e:
        return jsonify({'error': f'Cannot write R script: {e}'}), 500

    # ── Find R and run ──
    rscript = _find_rscript()
    if not rscript:
        return jsonify({
            'error': 'Rscript not found. Is R installed and on PATH?',
            'r_script': r_script,
        }), 404

    try:
        rv = subprocess.run(
            [rscript, script_path],
            capture_output=True, text=True, timeout=300,
            cwd=vpc_folder,
            env=_get_r_env()
        )
        stdout = rv.stdout
        stderr = rv.stderr

        if 'NMGUI_VPC_OK' in stdout and os.path.isfile(output_png):
            # Verify PNG is not empty (xpose4 could create 0-byte PNG)
            if os.path.getsize(output_png) < 1000:
                return jsonify({
                    'error': 'R script created an empty or broken image — the plot likely failed silently.',
                    'r_script': r_script,
                    'stdout': stdout[-1000:] if len(stdout) > 1000 else stdout,
                    'stderr': stderr[-1000:] if len(stderr) > 1000 else stderr,
                }), 400
            return jsonify({
                'ok': True,
                'tool': tool,
                'image_path': output_png,
                'r_script': r_script,
                'stdout': stdout[-500:] if len(stdout) > 500 else stdout,
                'stderr': stderr[-500:] if len(stderr) > 500 else stderr,
            })
        else:
            # Extract R-level error message from tryCatch output
            r_error = ''
            for line in stdout.split('\n'):
                if 'NMGUI_VPC_ERROR:' in line:
                    r_error = line.split('NMGUI_VPC_ERROR:', 1)[1].strip()
                    break
            if not r_error:
                # Look for R Error: lines in stderr
                for line in stderr.split('\n'):
                    if line.strip().startswith('Error'):
                        r_error = line.strip()
                        break
            error_msg = r_error if r_error else 'R script did not produce a VPC plot'
            return jsonify({
                'error': error_msg,
                'r_script': r_script,
                'stdout': stdout[-1000:] if len(stdout) > 1000 else stdout,
                'stderr': stderr[-1000:] if len(stderr) > 1000 else stderr,
            }), 400
    except subprocess.TimeoutExpired:
        return jsonify({
            'error': 'R script timed out (5 min). Try fewer simulations or a simpler VPC.',
            'r_script': r_script,
        }), 504
    except FileNotFoundError:
        return jsonify({'error': 'Rscript not found. Is R installed and on PATH?'}), 404
    except Exception as e:
        return jsonify({'error': str(e), 'r_script': r_script}), 500


@app.route('/api/vpc/image', methods=['GET'])
def vpc_image():
    """Serve a generated VPC image."""
    image_path = request.args.get('path', '')
    if not image_path or not os.path.isfile(image_path):
        return 'Image not found', 404
    from flask import send_file
    return send_file(image_path, mimetype='image/png')


if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 5151
    print(f"\n  NMGUI — NONMEM Run Manager")
    print(f"  Open http://localhost:{port} in your browser\n")
    app.run(host='0.0.0.0', port=port, debug=False, threaded=True)
