# NMGUI Changelog

Vibe coded by Rob ter Heine with Claude.

---

## v1.4 — 21 March 2026

### VPC overhaul (21+ bug fixes)

**Critical R script fixes**
- xpose4 completely rewritten: reads `vpctab` directly from PsN vpc folder via `list.files()`, no longer calls `xpose.data()`. No run number or run directory needed.
- xpose tidyverse: added `vpc_folder` parameter to `vpc_data()` for correct PsN simulation data. Error handler reports available sdtab/lst files with runno hint.
- All three tools wrapped in `tryCatch`: failures produce `NMGUI_VPC_ERROR: <message>` parsed by backend. `cat("NMGUI_VPC_OK")` only on success.
- Empty/corrupt PNGs (< 1KB) detected and rejected — catches silent R failures.
- Old `nmgui_vpc.png` deleted before running new R script — prevents stale image serving.

**Tool switching and input handling**
- `generateVPC()` never sends `custom_script` — only "Run custom script" button does. Fixes second-tool-run always re-executing first script.
- PI/CI select values fixed: single floats (0.9, 0.95) not unparseable comma strings.
- LLOQ validated as numeric; nbins clamped to [1,100].
- Folder validation for all three tools, not just vpc.
- m1.zip auto-extracted with path traversal guard.

**Execution environment**
- R subprocess receives login shell PATH via `_get_r_env()` (fixes macOS Homebrew).
- `_find_rscript()` with macOS/Linux login shell fallback.
- `check_r()` also passes login shell env to package checks.
- Shell fallback `/bin/sh` on all platforms (was `/bin/zsh`).
- Timeout 300s (was 120s).
- R stderr returned on success.

**UI**
- Generate button disabled during execution.
- Stale image cleared on new generate.
- Advanced R script panel auto-expands on error.
- Unavailable R packages greyed out in dropdown.
- Tool label shown above VPC image ("Generated with: vpc").
- xpose4 simplified: no run number or run directory fields.
- xpose: run directory with Browse button.

**$TABLE file extraction**
- New `extract_table_files()` parser: extracts FILE= from $TABLE records.
- Auto-detects runno from sdtab file names (e.g. `sdtab001` → `001`).
- Fallback to patab/catab/cotab.
- `table_files` and `table_runno` added to model scan.
- xpose runno auto-populated from control stream, not model stem.

### GOF figure labels
- Panel labels A/B/C/D repositioned with `yanchor: 'bottom'` above subplot areas.
- Top row y-domain adjusted to [0.56, 0.98] to create label clearance.
- Top margin increased from 30px to 50px.
- Export dimensions updated to match (720px height).

### Individual fit plot pagination fix
- `indFitPrev()` and `indFitNext()` were calling `drawIndividualFits()` which reset page to 0. Now call `renderIndFitPage()` directly using cached column references.

### Individual OFV waterfall plot
- New card in Model Evaluation tab: "Individual OFV Contributions"
- Reads `.phi` file (NONMEM 7.2+) via `parse_phi_file()` parser and `/api/phi/read` endpoint.
- Sorted bar chart — largest individual OBJ contributors on the left.
- Red→blue color gradient. Hover shows exact iOFV value.
- Auto-shrinking tick labels for large populations (>50 subjects).

### Auto-load evaluation data
- Browse → selecting a table file now immediately loads it (no Load button needed).
- Selecting a model auto-populates the eval file path from `$TABLE FILE=sdtab...`.

### Test suite
- 342 tests (246 validation + 96 parser) — all pass.
- New: phi parser (7 tests), pagination (3 tests), $TABLE extraction, xpose4 vpctab, LLOQ validation, m1.zip unzip, PI/CI parsing, sanitize/R env helpers.

---

## v1.3 — 21 March 2026

### Model workflow & ancestry (6 features inspired by bbr)

**Star/flag models**
- Gold ★ toggle in model table, persists in `~/.nmgui/model_meta.json`
- Instant toggle, no confirmation needed

**Model ancestry**
- Duplicate auto-records `based_on` (parent model stem)
- "↳ from parent" shown in model list below model name
- Stored as stem (portable across machines)

**Ancestry tree visualization**
- 🌳 button in header opens SVG tree modal
- Server-side layout (BFS), no JS dependency
- OFV gradient coloring (green → blue), status dots, stale indicators
- Starred models highlighted with gold stroke

**Stale run detection**
- Models whose .mod or $DATA file was modified after the .lst get a "modified" tag
- 2-second mtime tolerance to handle filesystem granularity

**Initial estimate jitter**
- Duplicate dialog: checkbox to apply ±N% perturbation
- Applies to THETA + diagonal OMEGA/SIGMA only
- Respects bounds, skips FIX'd parameters, never touches off-diagonals
- Default 20%, configurable 1–100%

**Parameter units**
- Extracts `[unit]` from control stream comments (e.g., `; CL [L/h]`)
- Displayed in parameter panel and run report
- Unit text stripped from parameter name to avoid duplication

### Storage migration
- `comments.json` → `model_meta.json` with `{comment, star, based_on}` per model
- Backward-compatible: auto-migrates old format on first load
- `get_meta()` helper normalizes legacy string entries

### VPC tab overhaul (21 bug fixes)

**Critical fixes**
- m1.zip auto-extracted before R execution (PsN compresses m1/ by default)
- Tool switching no longer re-runs the previous R script (custom_script leak from textarea)
- xpose4 `runno` no longer produces empty-argument R syntax error
- xpose/xpose4 now use separate run directory (for sdtab/patab) vs VPC folder (for vpc_results.csv)
- PI/CI selectors actually work (was sending unparseable comma-separated strings)

**Input validation**
- LLOQ validated as numeric, returns clear error on invalid input
- N bins validated as integer, clamped to [1,100], defaults to 8
- Folder contents validated for all three tools, not just vpc
- R string injection prevented via `_sanitize_for_r()` helper

**Execution environment**
- R subprocess receives login shell PATH (fixes macOS Homebrew R not found)
- `_find_rscript()` tries login shell fallback on macOS/Linux
- Timeout increased from 120s to 300s for large VPC datasets
- R stderr returned on success (package warnings now visible)

**UI improvements**
- Generate button disabled during execution (prevents race condition)
- Stale image cleared before new generate attempt
- Advanced R script panel auto-expands on error for debugging
- Unavailable R packages greyed out in tool dropdown
- Run number auto-populated from selected model stem
- Run directory fields with Browse buttons added for xpose and xpose4
- Folder button relabeled with correct tooltip

### Test suite
- 310 tests (214 validation + 96 parser) — all pass
- New: star, based_on, tree, stale, units, jitter, VPC m1.zip unzip, LLOQ validation, PI/CI parsing, runno defaults, sanitize helper

---

## v1.2 — 21 March 2026

### Cross-platform compatibility (24 fixes)
Full Windows 10/11 support alongside existing macOS and Linux.

**Process management (fixes #1, #2, #22)**
- PsN run start uses CREATE_NEW_PROCESS_GROUP on Windows, preexec_fn=os.setsid on Unix
- Run stop uses proc.terminate() on Windows, os.killpg on Unix
- shell=True retained on all platforms for PsN .bat wrapper compatibility

**Path handling (fixes #3, #5, #15, #16, #17)**
- PsN commands: model paths quoted with shlex.quote (Unix) / double quotes (Windows)
- VPC R scripts: all injected paths normalized to forward slashes (backslashes break R)
- JS browseUp(): splits on both / and \, handles Windows drive roots (C:\)
- JS pathBasename(): cross-platform filename extraction replaces split('/').pop()
- JS detectVpcFolder(): uses platform-aware separators, adds PsN 5.5+ .dir pattern

**File encoding (fixes #10, #13, #14, #23)**
- All file reads use encoding='utf-8-sig' (handles Windows BOM transparently)
- All file writes use encoding='utf-8'
- Python text mode already normalizes \r\n line endings

**External tool discovery (fixes #8, #9)**
- _find_rscript(): searches Windows R install paths via glob when Rscript not on PATH
- RStudio launcher: added Posit install paths for rebranded RStudio on Windows

**VPC improvements (fixes #6, #7, #11, #12, #18, #19)**
- Multi-variable stratify: "SEX,DOSE" correctly generates c("SEX","DOSE") in R scripts
- VPC folder validation: checks for vpctab/m1 before running R, shows informative error
- PsN 5.5+ directory detection: .dir pattern added to .ext search and VPC auto-detect
- Guidance text in VPC tab explaining two-step workflow (PsN vpc → R plot)
- Stratify placeholders show correct format: "e.g. SEX or SEX,DOSE"

**Robustness (fixes #20, #21, #24)**
- File browser filters Windows system files (desktop.ini, Thumbs.db)
- run.py: webbrowser.open wrapped in try/except, URL always printed to console
- README: added macOS Gatekeeper, Windows PATH, and spaces-in-paths troubleshooting

---

## v1.1 — 21 March 2026

### Multi-estimation method support
- Parser auto-detects estimation method from $EST METHOD= in control stream
- Supported methods: FO, FOCE, FOCE-I, SAEM, IMP, ITS, BAYES, NUTS
- Multi-step estimation detected: SAEM→IMP, SAEM→FOCE shown as combined label
- OFV parsing expanded: handles "MINIMUM VALUE OF OBJECTIVE FUNCTION" (classical), "#OBJV" (SAEM/IMP), "-2 LOG LIKELIHOOD" (SAEM/BAYES), "OBJECTIVE FUNCTION VALUE" (IMP)
- Status detection expanded: "STATISTICAL PORTION WAS COMPLETED" (SAEM), "IMPORTANCE SAMPLING COMPLETED" (IMP), "BAYES ESTIMATION COMPLETED", "NUTS ESTIMATION COMPLETED"
- Estimation method shown as a small tag next to model name in the model list
- Method included in run report subtitle
- All existing parser functionality (SEs, shrinkage, ETABAR, correlation matrix, etc.) continues to work across all methods

---

## v1.0 — 21 March 2026

First official release.

### MDV=1 filtering
- Data Viewer scatter plots: "Exclude MDV=1" checkbox (checked by default) filters non-observation records before plotting
- GOF figure: same filter applied to all four panels (DV vs PRED, DV vs IPRED, CWRES vs PRED, CWRES vs TIME)
- Individual fit plots: MDV=1 records excluded from DV scatter points; PRED/IPRED lines kept at all timepoints
- Residual distribution: MDV=1 excluded from CWRES and IWRES histograms

### Custom plot filters
- Two configurable filters in the Data Viewer scatter plot area
- Each filter: pick a column, choose an operator (=, >, <, ≥, ≤, ≠), enter a value
- Useful for filtering by compartment (CMT=2), study (STUDY=1), excluding BLQ (BLQ=0), etc.
- Filters stack with each other and with the MDV exclusion
- Applied live — change any dropdown or value and the plot updates

### Model comments / annotations
- Text field below editor toolbar: "Add a note about this model..."
- Auto-saves on blur to ~/.nmgui/comments.json
- Comment appears in model list (blue italic), run report header
- Persists across sessions

### VPC tab
- Dedicated tab with three R tool options: vpc (Ron Keizer), xpose (tidyverse), xpose4 (legacy)
- Full options per tool: prediction correction, LLOQ, binning, stratification, log Y
- Advanced panel for editing generated R scripts
- R dependency checker with install guidance

### RStudio launcher
- Blue "R" button in header bar opens RStudio in project directory via .Rproj file
- Platform-aware: macOS, Linux, Windows

### Fully standalone
- All assets bundled locally (Plotly.js, CodeMirror)
- No internet connection required

### Parser and diagnostics
- ETABAR test with p-values (flags p < 0.05)
- COV failure diagnostics (R matrix singular, S matrix singular, etc.)
- Parameter names and FIX status from control stream
- nInd, nObs, nPar, AIC/BIC, significant digits, boundary warnings
- Correlation matrix with high-correlation flagging
- .ext file parser for convergence plots

### UI
- Compact model table: single-letter status badges, merged name+description column
- Reference model selector for ΔOFV
- Dark theme with readable plot axis labels
- Desktop launchers for macOS (.command and .app bundle)
- In-app changelog (click version badge)

---

## RC4 — 20 March 2026

### Model comments / annotations
- Text field below editor toolbar: "Add a note about this model..."
- Type a note, click away (or press Enter) — auto-saves to ~/.nmgui/comments.json
- Comment appears in the model list as a third line (blue italic) under name and description
- Comment included in run report header
- Persists across sessions, keyed by model file path
- Clear comment by deleting the text

### UI polish
- RStudio button moved to top-right header bar (visible on all tabs)
- Fixed header-right stacking — now horizontal flex row with gap
- Tab buttons tightened for 5-tab navigation
- Credit text auto-hides on narrow windows

---

## RC3 — 20 March 2026

### VPC tab (new)
- Dedicated VPC tab in the main navigation
- Browse to a PsN vpc output directory or auto-detect from selected model
- Three tool options:
  - **vpc** (Ron Keizer): prediction correction, LLOQ, binning (jenks/kmeans/ntile/pam/pretty), N bins, stratification, PI/CI ranges, log Y
  - **xpose** (tidyverse, UUPharmacometrics): run number, directory, stratification, N bins, LLOQ, prediction correction, log Y
  - **xpose4** (legacy): run number
- Generates R script dynamically, runs via Rscript subprocess
- VPC plot displayed inline as PNG image
- Advanced panel: view and edit the generated R script, re-run with custom modifications
- R dependency checker: auto-detects R, vpc, xpose, and xpose4 availability on tab open — green/yellow/red status indicator with install instructions
- Removed VPC placeholder from Model Evaluation tab

### RStudio launcher
- Blue "R" button in the project toolbar opens RStudio with the project directory as working directory
- Platform-aware: macOS (open -a RStudio), Linux (rstudio), Windows (searches common install paths)
- Clear error message if RStudio not found

### Fully offline
- Removed last external dependency: Google Fonts @import in run report replaced with system font stack (Georgia + system sans-serif)
- All assets (Plotly.js, CodeMirror) confirmed bundled locally

---

## RC2 — 18 March 2026

### Fully offline / standalone
- Removed Google Fonts dependency from run report — replaced with system font stack (Georgia for headings, system sans-serif for body)
- All JavaScript libraries (Plotly.js 2.27.0, CodeMirror 5 with addons) bundled locally in static/vendor/
- Zero external HTTP requests — runs fully air-gapped

### Desktop launcher (macOS)
- Added NMGUI.command — double-click to start (opens Terminal + browser)
- Added NMGUI.app bundle — double-click to start without visible Terminal window

### Plot readability on dark theme
- Fixed axis labels, tick marks, and titles on Model Evaluation plots (individual fits, residual distribution, convergence) — were dark text on dark background, now light (#aab) on dark paper (#171922)
- GOF figure remains white-background for publication export

### Model table layout
- Fixed column widths for all numeric columns (OFV 62px, nI/nO/nP 32px, AIC 58px, etc.)
- Model column gets all remaining space — description no longer truncated to unreadable width
- Description uses -webkit-line-clamp: 2 with ellipsis overflow

---

## RC1 — 17 March 2026

First release candidate.

### Models Tab
- Project directory scanner for .mod/.ctl files
- Integrated CodeMirror 5 editor with NONMEM syntax highlighting
- Parameter estimates panel with names parsed from control stream comments
- Full OMEGA/SIGMA matrix display with SEs, RSE%, CV%
- FIX labels sourced from control stream (not inferred from missing SEs)
- COV badge: OK / FAILED / NO COV
- COV failure diagnostics: R matrix singular, S matrix singular, Hessian singular, etc.
- Condition number from eigenvalues (handles ** decoration and column headers)
- Eta-shrinkage and epsilon-shrinkage
- ETABAR test with p-values — flags significant deviations (p < 0.05) in red
- Run execution via PSN with live SSE console in bottom drawer
- Auto-cleanup of old run artifacts before re-run (fixes PSN directory conflict)
- Unsaved changes indicator with pulsing badge
- Warns before running with unsaved changes
- Duplicate model with optional final estimate injection
- NMTRAN error display (parses FMSG/PRDERR)
- Project bookmarks stored in ~/.nmgui/bookmarks.json
- Run report: publication-ready HTML in new tab with Source Serif 4 / Inter typography

### Model Table
- Compact layout: merged model name + $PROBLEM description in one column
- Single-letter status badges: S (successful), T (terminated), Y/N (COV), B (boundary)
- Full messages available as tooltips on hover
- Reference model selector: dropdown defaults to best OFV, user-selectable
- Columns: OFV, ΔOFV, nInd, nObs, nPar, AIC, condition number, runtime
- Fixed column widths for numeric columns, model column gets remaining space

### Run Report
- Summary boxes: OFV, minimization status, covariance step (with failure reason), condition number, runtime, shrinkage
- THETA table with parameter names, estimates, FIX tags, SE, RSE%
- Full OMEGA matrix with names, FIX tags, RSE%, CV%
- SIGMA table with FIX tags
- Correlation matrix of parameter estimates with color-coded high correlations (|r| > 0.95)
- Shrinkage tables (eta and epsilon)
- ETABAR test table with highlighted p < 0.05
- Print-ready via Cmd+P / Ctrl+P

### Run Overview Tab
- Scans project directory and subdirectories for .lst files
- Comparison table with OFV, ΔOFV, parameters, condition number, shrinkage, runtime
- Side-by-side model comparison of selected runs
- Run detail panel with output file listing, "View" and "GOF" buttons

### Model Evaluation Tab
- GOF figure: 2×2 publication plot (DV vs PRED, DV vs IPRED, CWRES vs PRED, CWRES vs TIME)
  - White background, panel labels A-D, Y=X and Y=0 reference lines
  - Export PNG at 3× scale (2400×2100px)
- Individual fit plots: paginated grid (2×2, 3×3, 4×4)
  - DV as blue dots, IPRED as red line, PRED as dashed line, per subject
- Residual distribution: CWRES/WRES histogram with normal density overlay
- OFV / parameter convergence: parsed from .ext file, dual-panel (OFV + THETA traces)

### Data Viewer Tab
- File sidebar listing .csv/.tab/.dat files in project directory and subdirectories
- Paginated table (500 rows) with Excel-style stackable column filters
- Scatter plot with configurable X/Y, dot size 6, Y=X line, Y=0 line, LOESS smoother
- GOF presets: DV vs PRED, DV vs IPRED, CWRES vs TIME, CWRES vs PRED, |IWRES| vs IPRED
- ETA vs covariate selector with auto-detected ETA columns
- QQ plot of CWRES with reference line through Q1/Q3

### Parser (parser.py)
- OFV, minimization status, covariance step detection
- nInd, nObs from "TOT. NO. OF..." lines
- Significant digits from .lst
- Boundary warning detection
- Estimated parameter count (excludes FIX'd parameters)
- AIC (OFV + 2p) and BIC (OFV + p×ln(n))
- Full THETA/OMEGA/SIGMA estimates with lower-triangular matrices
- Standard errors with ......... → null alignment for fixed parameters
- Condition number from eigenvalues (handles NONMEM 7 format with ** decoration)
- Correlation matrix of estimates with labels and null for fixed parameters
- Eta-shrinkage, epsilon-shrinkage
- ETABAR, ETABAR SE, ETABAR p-values
- COV failure reason (R matrix singular, S matrix singular, etc.)
- Runtime extraction
- Parameter names and FIX status from control stream comments
- Final estimate injection into control stream (for model duplication)
- NMTRAN error parsing (FMSG/PRDERR)
- .ext file parsing for convergence data

### Infrastructure
- Flask backend, single dependency
- SSE (Server-Sent Events) for live console streaming
- Process group management for run stop button
- Settings and bookmarks stored in ~/.nmgui/
- CodeMirror 5 with custom NONMEM syntax highlighting mode
- Dark theme UI throughout
