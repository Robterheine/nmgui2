#!/usr/bin/env python3
"""Launch NMGUI and open browser."""
import sys
import os
import threading
import webbrowser
import time

# Add project dir to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 5151
URL = f'http://localhost:{PORT}'

def open_browser():
    time.sleep(1.2)
    try:
        webbrowser.open(URL)
    except Exception:
        pass  # URL is always printed to console as fallback

if __name__ == '__main__':
    print(f'\n  NMGUI — NONMEM Run Manager')
    print(f'  Open {URL} in your browser')
    print(f'  Press Ctrl+C to stop\n')
    threading.Thread(target=open_browser, daemon=True).start()
    from app import app
    app.run(host='127.0.0.1', port=PORT, debug=False, threaded=True)
