/* ═══ NMGUI — Main Application Logic ═══ */

// ── State ──────────────────────────────
let currentRunId = null;
let eventSource = null;
let browseTarget = null;
let browseSelectedPath = null;
let browseCurrentPath = '';
let scannedModels = [];       // models from project dir scan
let selectedModelIdx = -1;    // currently selected model in list
let currentEditorPath = '';   // path of file loaded in editor
let overviewRuns = [];
let viewerData = null;
let activeFilters = {};
let homeDir = '/';            // set from server
let evalData = null;          // data loaded in Model Evaluation tab

// ── Init ───────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
    initTabs();
    initSplitHandle();
    const settings = await fetchJson('/api/settings');
    homeDir = settings.home || '/';
    if (settings.working_directory) {
        document.getElementById('inp-project-dir').value = settings.working_directory;
        document.getElementById('inp-scan-dir').value = settings.working_directory;
        document.getElementById('inp-data-dir').value = settings.working_directory;
        scanModels();
    }
    document.getElementById('btn-settings').onclick = () => {
        document.getElementById('inp-settings-workdir').value =
            document.getElementById('inp-project-dir').value;
        document.getElementById('modal-settings').style.display = 'flex';
    };
    // When switching to data viewer tab, refresh file list
    document.querySelector('[data-tab="viewer"]').addEventListener('click', () => {
        const dir = document.getElementById('inp-data-dir').value || document.getElementById('inp-project-dir').value;
        if (dir) { document.getElementById('inp-data-dir').value = dir; refreshDataFiles(); }
    });
    // Load bookmarks
    loadBookmarks();
});

function initTabs() {
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
            // Auto-scan when switching to overview tab
            if (btn.dataset.tab === 'overview') {
                const dir = document.getElementById('inp-scan-dir').value || document.getElementById('inp-project-dir').value;
                if (dir) {
                    document.getElementById('inp-scan-dir').value = dir;
                    scanRuns();
                }
            }
            // Check R status when switching to VPC tab
            if (btn.dataset.tab === 'vpc') {
                checkRStatus();
            }
        });
    });
}

function initSplitHandle() {
    const handle = document.getElementById('split-handle');
    const left = document.getElementById('models-list-panel');
    let startX, startW;
    handle.addEventListener('mousedown', (e) => {
        startX = e.clientX;
        startW = left.offsetWidth;
        const onMove = (e2) => {
            const newW = Math.max(250, Math.min(startW + e2.clientX - startX, window.innerWidth - 400));
            left.style.width = newW + 'px';
        };
        const onUp = () => {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
        e.preventDefault();
    });
}

// ── Utilities ──────────────────────────
async function fetchJson(url, opts = {}) {
    try {
        const res = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...opts });
        return await res.json();
    } catch (e) { console.error('Fetch error:', e); return { error: e.message }; }
}
async function postJson(url, body, method) {
    if (method === 'GET') return fetchJson(url, { method: 'GET' });
    return fetchJson(url, { method: 'POST', body: JSON.stringify(body) });
}
function formatNum(n, digits = 4) {
    if (n === null || n === undefined) return '—';
    if (typeof n === 'number') {
        if (Math.abs(n) > 1e6 || (Math.abs(n) < 0.001 && n !== 0)) return n.toExponential(digits);
        return n.toFixed(digits);
    }
    return String(n);
}
function formatTime(secs) {
    if (!secs) return '—';
    if (secs < 60) return secs.toFixed(1) + 's';
    if (secs < 3600) return (secs / 60).toFixed(1) + 'm';
    return (secs / 3600).toFixed(2) + 'h';
}
function escapeHtml(str) {
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function pathBasename(p) {
    return p.split(/[/\\]/).filter(Boolean).pop() || p;
}

// ── Settings ───────────────────────────
async function saveAppSettings() {
    const wd = document.getElementById('inp-settings-workdir').value;
    await postJson('/api/settings', { working_directory: wd });
    document.getElementById('inp-project-dir').value = wd;
    document.getElementById('inp-scan-dir').value = wd;
    document.getElementById('modal-settings').style.display = 'none';
    scanModels();
}

// ══════════════════════════════════════════
// ══ MODELS TAB ═══════════════════════════
// ══════════════════════════════════════════

async function scanModels() {
    const dir = document.getElementById('inp-project-dir').value.trim();
    if (!dir) return;
    const models = await postJson('/api/models/scan', { directory: dir });
    if (models.error) { console.error(models.error); return; }
    scannedModels = models;
    selectedModelIdx = -1;
    renderModelList();
    // Sync other dir inputs
    document.getElementById('inp-scan-dir').value = dir;
    document.getElementById('inp-data-dir').value = dir;
    postJson('/api/settings', { working_directory: dir });
}

function renderModelList() {
    const tbody = document.getElementById('models-body');
    tbody.innerHTML = '';

    if (scannedModels.length === 0) {
        tbody.innerHTML = '<tr><td colspan="13" style="text-align:center;color:var(--text-2);padding:30px">No .mod or .ctl files found in this directory</td></tr>';
        return;
    }

    // Populate reference model selector
    const refSel = document.getElementById('sel-ref-model');
    const curRef = refSel.value;
    refSel.innerHTML = '<option value="">Best OFV</option>';
    scannedModels.forEach((m, idx) => {
        if (m.has_run && m.ofv !== null) {
            refSel.innerHTML += `<option value="${idx}">${m.name}</option>`;
        }
    });
    refSel.value = curRef;

    // Reference OFV
    let refOFV = null;
    if (refSel.value !== '') {
        const refIdx = parseInt(refSel.value);
        if (refIdx < scannedModels.length) refOFV = scannedModels[refIdx].ofv;
    } else {
        const ofvs = scannedModels.filter(m => m.ofv !== null).map(m => m.ofv);
        refOFV = ofvs.length > 0 ? Math.min(...ofvs) : null;
    }

    scannedModels.forEach((m, idx) => {
        // Status: compact badge with tooltip
        let statusBadge = '<span style="color:var(--text-2)">\u2014</span>';
        if (m.has_run) {
            if (m.minimization_successful === true) {
                statusBadge = '<span class="status-ok" title="' + escapeHtml(m.minimization_message || 'SUCCESSFUL') + '">S</span>';
            } else if (m.minimization_successful === false) {
                statusBadge = '<span class="status-fail" title="' + escapeHtml(m.minimization_message || 'TERMINATED') + '">T</span>';
            } else {
                statusBadge = '<span class="text-muted" title="Run completed">?</span>';
            }
        }
        const deltaOFV = (m.ofv !== null && refOFV !== null) ? (m.ofv - refOFV).toFixed(2) : '\u2014';

        const covBadge = m.covariance_step === true ? '<span class="status-ok">Y</span>' :
            m.covariance_step === false ? '<span class="status-fail" title="' + escapeHtml(m.cov_failure_reason || 'Failed') + '">N</span>' : '\u2014';

        const bndText = m.boundary ? '<span class="status-fail">B</span>' : '';

        const tr = document.createElement('tr');
        tr.className = idx === selectedModelIdx ? 'model-selected' : '';
        const starCls = m.star ? 'star-btn starred' : 'star-btn';
        const starChar = m.star ? '\u2605' : '\u2606';
        const staleTag = m.stale ? ' <span class="stale-tag" title="Control stream or data modified since last run">modified</span>' : '';
        const methodTag = m.estimation_method ? ' <span class="method-tag">' + escapeHtml(m.estimation_method) + '</span>' : '';
        const basedOn = m.based_on ? '<br><span class="based-on-tag">\u21b3 from ' + escapeHtml(m.based_on) + '</span>' : '';
        const commentLine = m.comment ? '<br><span class="model-comment">' + escapeHtml(m.comment) + '</span>' : '';
        tr.innerHTML = `
            <td><input type="checkbox" class="model-chk" data-idx="${idx}" onclick="event.stopPropagation()"></td>
            <td class="model-name-cell"><span class="${starCls}" onclick="event.stopPropagation(); toggleStar(${idx})" title="Star this model">${starChar}</span> <strong>${m.stem || m.name}</strong>${methodTag}${staleTag}<br><span class="model-desc">${m.problem || ''}</span>${basedOn}${commentLine}</td>
            <td style="text-align:center">${statusBadge}</td>
            <td style="text-align:center">${covBadge}</td>
            <td style="text-align:center">${bndText}</td>
            <td>${formatNum(m.ofv, 2)}</td>
            <td>${deltaOFV}</td>
            <td>${m.n_individuals || '\u2014'}</td>
            <td>${m.n_observations || '\u2014'}</td>
            <td>${m.n_estimated_params || '\u2014'}</td>
            <td>${m.aic != null ? formatNum(m.aic, 2) : '\u2014'}</td>
            <td>${m.condition_number ? formatNum(m.condition_number, 1) : '\u2014'}</td>
            <td>${formatTime(m.runtime)}</td>
        `;
        tr.onclick = () => selectModel(idx);
        tbody.appendChild(tr);
    });
}

async function selectModel(idx) {
    selectedModelIdx = idx;
    const m = scannedModels[idx];

    // Highlight row
    document.querySelectorAll('#models-body tr').forEach((tr, i) => {
        tr.className = i === idx ? 'model-selected' : '';
    });

    // Load in editor
    const data = await postJson('/api/file/read', { path: m.path });
    if (!data.error) {
        currentEditorPath = m.path;
        setEditorContent(data.content);
        document.getElementById('editor-filename').textContent = m.name;
        document.getElementById('editor-status').textContent = '';
        document.getElementById('btn-run-model').disabled = false;
        // Check for NMTRAN errors
        if (m.has_run) checkErrors(m.path);
        else document.getElementById('btn-errors').style.display = 'none';
        // Clear error panel
        const ep = document.getElementById('error-panel');
        if (ep) ep.innerHTML = '';
        // Show parameter estimates
        renderParamPanel(m);
        // Load comment
        document.getElementById('inp-model-comment').value = m.comment || '';
        // Auto-populate eval file from $TABLE sdtab if available
        if (m.has_run && m.table_files && m.table_files.length) {
            var sdtab = m.table_files.find(f => f.toLowerCase().startsWith('sdtab'));
            if (sdtab) {
                var runDir = m.run_dir || m.path.replace(/[/\\][^/\\]+$/, '');
                document.getElementById('inp-eval-file').value = runDir + (runDir.includes('\\') ? '\\' : '/') + sdtab;
            }
        }
    }
}

function toggleParamPanel() {
    const body = document.getElementById('param-panel-body');
    const btn = body.previousElementSibling?.querySelector('button:last-child');
    if (body.style.display === 'none') {
        body.style.display = 'block';
        if (btn) btn.textContent = '▾';
    } else {
        body.style.display = 'none';
        if (btn) btn.textContent = '▸';
    }
}

async function saveModelComment() {
    if (selectedModelIdx < 0) return;
    var m = scannedModels[selectedModelIdx];
    var comment = document.getElementById('inp-model-comment').value.trim();
    if (comment === (m.comment || '')) return;
    m.comment = comment;
    await postJson('/api/comments/save', { path: m.path, comment: comment });
    renderModelList();
}

async function toggleStar(idx) {
    var m = scannedModels[idx];
    var result = await postJson('/api/model/star', { path: m.path });
    if (result && result.ok) {
        m.star = result.star;
        renderModelList();
    }
}

async function showModelTree() {
    var dir = document.getElementById('inp-project-dir').value;
    if (!dir) { alert('Set a project directory first.'); return; }
    var data = await postJson('/api/model/tree', { directory: dir });
    if (!data || !data.nodes) return;
    renderTreeSvg(data.nodes, data.edges);
    document.getElementById('modal-tree').style.display = 'flex';
}

function renderTreeSvg(nodes, edges) {
    if (!nodes.length) {
        document.getElementById('tree-svg-container').innerHTML = '<p style="color:var(--text-2);padding:20px">No models found.</p>';
        return;
    }

    // Build adjacency: find roots (nodes with no incoming edge)
    var childSet = new Set(edges.map(function(e) { return e.to; }));
    var childrenOf = {};
    edges.forEach(function(e) {
        if (!childrenOf[e.from]) childrenOf[e.from] = [];
        childrenOf[e.from].push(e.to);
    });
    var roots = nodes.filter(function(n) { return !childSet.has(n.id); });
    if (!roots.length) roots = [nodes[0]]; // fallback: pick first

    // Assign x,y positions via BFS-like layout
    var nodeMap = {};
    nodes.forEach(function(n) { nodeMap[n.id] = n; });

    var nodeW = 140, nodeH = 52, gapX = 40, gapY = 70;
    var positions = {}; // id -> {x, y}
    var maxCol = [0]; // track max column per depth level

    function layoutTree(nodeId, depth, colStart) {
        var children = childrenOf[nodeId] || [];
        if (children.length === 0) {
            positions[nodeId] = { x: colStart, y: depth };
            return colStart + 1;
        }
        var col = colStart;
        children.forEach(function(cid) {
            col = layoutTree(cid, depth + 1, col);
        });
        // Center parent above children
        var firstChild = positions[children[0]].x;
        var lastChild = positions[children[children.length - 1]].x;
        positions[nodeId] = { x: (firstChild + lastChild) / 2, y: depth };
        return col;
    }

    var col = 0;
    roots.forEach(function(r) { col = layoutTree(r.id, 0, col); });

    // Also place orphan nodes (not connected to any tree)
    nodes.forEach(function(n) {
        if (!positions[n.id]) {
            positions[n.id] = { x: col, y: 0 };
            col++;
        }
    });

    var maxX = 0, maxY = 0;
    Object.values(positions).forEach(function(p) {
        if (p.x > maxX) maxX = p.x;
        if (p.y > maxY) maxY = p.y;
    });

    var svgW = (maxX + 1) * (nodeW + gapX) + 40;
    var svgH = (maxY + 1) * (nodeH + gapY) + 40;

    function px(col) { return 20 + col * (nodeW + gapX); }
    function py(row) { return 20 + row * (nodeH + gapY); }

    // Find OFV range for color gradient
    var ofvs = nodes.map(function(n) { return n.ofv; }).filter(function(v) { return v != null && isFinite(v); });
    var ofvMin = Math.min.apply(null, ofvs);
    var ofvMax = Math.max.apply(null, ofvs);

    function ofvColor(ofv) {
        if (ofv == null || !isFinite(ofv) || ofvMin === ofvMax) return '#2a2f45';
        var t = (ofv - ofvMin) / (ofvMax - ofvMin);
        // green (low OFV) to blue (high OFV)
        var r = Math.round(40 + t * 20);
        var g = Math.round(180 - t * 130);
        var b = Math.round(100 + t * 120);
        return 'rgb(' + r + ',' + g + ',' + b + ')';
    }

    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + svgW + '" height="' + svgH + '" style="font-family:var(--sans);font-size:11px">';

    // Draw edges
    edges.forEach(function(e) {
        if (!positions[e.from] || !positions[e.to]) return;
        var x1 = px(positions[e.from].x) + nodeW / 2;
        var y1 = py(positions[e.from].y) + nodeH;
        var x2 = px(positions[e.to].x) + nodeW / 2;
        var y2 = py(positions[e.to].y);
        var midY = (y1 + y2) / 2;
        svg += '<path d="M' + x1 + ' ' + y1 + ' C' + x1 + ' ' + midY + ' ' + x2 + ' ' + midY + ' ' + x2 + ' ' + y2 + '" fill="none" stroke="#555" stroke-width="1.5"/>';
    });

    // Draw nodes
    nodes.forEach(function(n) {
        if (!positions[n.id]) return;
        var x = px(positions[n.id].x);
        var y = py(positions[n.id].y);
        var fill = ofvColor(n.ofv);
        var strokeColor = n.star ? '#f59e0b' : '#555';
        var strokeWidth = n.star ? 2.5 : 1;
        var dashArray = n.stale ? '4,3' : 'none';

        svg += '<rect x="' + x + '" y="' + y + '" width="' + nodeW + '" height="' + nodeH + '" rx="8" fill="' + fill + '" stroke="' + strokeColor + '" stroke-width="' + strokeWidth + '" stroke-dasharray="' + dashArray + '"/>';

        // Model name
        var label = n.star ? '\u2605 ' + n.name : n.name;
        svg += '<text x="' + (x + nodeW / 2) + '" y="' + (y + 18) + '" text-anchor="middle" fill="#f0f0f0" font-weight="600" font-size="12">' + escapeHtml(label) + '</text>';

        // OFV
        var ofvText = n.ofv != null ? 'OFV ' + Number(n.ofv).toFixed(1) : 'not run';
        svg += '<text x="' + (x + nodeW / 2) + '" y="' + (y + 34) + '" text-anchor="middle" fill="#bbb" font-size="9.5">' + ofvText + '</text>';

        // Status
        if (n.status) {
            var statusColor = n.status === 'SUCCESSFUL' || n.status.indexOf('COMPLETED') >= 0 ? '#4ade80' : '#f87171';
            svg += '<circle cx="' + (x + nodeW - 10) + '" cy="' + (y + 10) + '" r="4" fill="' + statusColor + '"/>';
        }
    });

    svg += '</svg>';
    document.getElementById('tree-svg-container').innerHTML = svg;
}

function renderParamPanel(m) {
    const panel = document.getElementById('param-panel');
    const content = document.getElementById('param-content');
    const badge = document.getElementById('param-cov-badge');

    if (!m.has_run || (!m.thetas.length && !m.omegas.length)) {
        panel.style.display = 'none';
        return;
    }

    panel.style.display = 'block';

    // Covariance badge
    if (m.covariance_step === true) {
        badge.textContent = 'COV OK';
        badge.className = 'cov-badge cov-badge-ok';
    } else if (m.covariance_step === false) {
        badge.textContent = 'COV FAILED';
        badge.className = 'cov-badge cov-badge-fail';
    } else {
        badge.textContent = 'NO COV';
        badge.className = 'cov-badge cov-badge-na';
    }

    const hasSE = m.covariance_step === true && m.theta_ses && m.theta_ses.some(s => s != null);
    const tNames = m.theta_names || [];
    const oNames = m.omega_names || [];
    const sNames = m.sigma_names || [];
    const tUnits = m.theta_units || [];
    const oUnits = m.omega_units || [];
    const sUnits = m.sigma_units || [];
    let html = '';

    // ── THETA table ──
    if (m.thetas && m.thetas.length) {
        html += '<table class="data-table data-table-sm"><thead><tr><th>#</th><th>Name</th><th>Estimate</th>';
        if (hasSE) html += '<th>SE</th><th>RSE%</th>';
        html += '</tr></thead><tbody>';
        m.thetas.forEach((val, i) => {
            const name = tNames[i] || '';
            const unit = tUnits[i] ? ' <span class="param-unit">[' + escapeHtml(tUnits[i]) + ']</span>' : '';
            const se = hasSE ? (m.theta_ses || [])[i] : undefined;
            const isFix = (m.theta_fixed || [])[i] === true;
            const rse = (se != null && val !== 0) ? (se / Math.abs(val) * 100).toFixed(1) : (isFix ? 'FIX' : '—');
            const fixTag = isFix ? ' <span style="color:var(--accent);font-size:10px;font-weight:600">FIX</span>' : '';
            html += `<tr><td class="param-label">θ${i + 1}</td><td style="color:var(--text-1);font-size:11px">${escapeHtml(name)}${unit}</td><td>${formatNum(val, 4)}${fixTag}</td>`;
            if (hasSE) html += `<td>${se != null ? formatNum(se, 4) : '—'}</td><td>${rse}</td>`;
            html += '</tr>';
        });
        html += '</tbody></table>';
    }

    // ── OMEGA table (full matrix) ──
    const omMatrix = m.omega_matrix || [];
    const omSEMatrix = m.omega_se_matrix || [];
    if (omMatrix.length) {
        const dim = omMatrix.length;
        const oFixed = m.omega_fixed || [];
        html += '<table class="data-table data-table-sm" style="margin-top:8px"><thead><tr><th>OMEGA</th><th>Name</th>';
        for (let j = 0; j < dim; j++) html += `<th>η${j + 1}</th>`;
        if (hasSE) html += '<th>RSE%</th>';
        html += '</tr></thead><tbody>';
        for (let i = 0; i < dim; i++) {
            const name = oNames[i] || '';
            const unit = oUnits[i] ? ' <span class="param-unit">[' + escapeHtml(oUnits[i]) + ']</span>' : '';
            const isFix = oFixed[i] === true;
            const fixTag = isFix ? ' <span style="color:var(--accent);font-size:9px;font-weight:600">FIX</span>' : '';
            html += `<tr><td class="param-label">η${i + 1}</td><td style="color:var(--text-1);font-size:11px">${escapeHtml(name)}${unit}${fixTag}</td>`;
            for (let j = 0; j <= i; j++) {
                const val = (omMatrix[i] || [])[j];
                let extra = '';
                if (i === j && val != null && val > 0) {
                    extra = ` title="CV=${(Math.sqrt(val) * 100).toFixed(1)}%"`;
                }
                html += `<td${extra}>${val != null ? formatNum(val, 4) : '—'}</td>`;
            }
            for (let j = i + 1; j < dim; j++) html += '<td></td>';
            if (hasSE) {
                if (isFix) {
                    html += '<td>FIX</td>';
                } else {
                    const diagVal = (omMatrix[i] || [])[i];
                    const diagSE = (omSEMatrix[i] || [])[i];
                    const rse = (diagSE != null && diagVal != null && diagVal !== 0)
                        ? (diagSE / Math.abs(diagVal) * 100).toFixed(1) : '—';
                    html += `<td>${rse}</td>`;
                }
            }
            html += '</tr>';
        }
        html += '</tbody></table>';
    }

    // ── SIGMA table (full matrix) ──
    const sigMatrix = m.sigma_matrix || [];
    const sigSEMatrix = m.sigma_se_matrix || [];
    if (sigMatrix.length) {
        const dim = sigMatrix.length;
        const sFixed = m.sigma_fixed || [];
        html += '<table class="data-table data-table-sm" style="margin-top:8px"><thead><tr><th>SIGMA</th><th>Name</th>';
        for (let j = 0; j < dim; j++) html += `<th>ε${j + 1}</th>`;
        if (hasSE) html += '<th>RSE%</th>';
        html += '</tr></thead><tbody>';
        for (let i = 0; i < dim; i++) {
            const name = sNames[i] || '';
            const unit = sUnits[i] ? ' <span class="param-unit">[' + escapeHtml(sUnits[i]) + ']</span>' : '';
            const isFix = sFixed[i] === true;
            const fixTag = isFix ? ' <span style="color:var(--accent);font-size:9px;font-weight:600">FIX</span>' : '';
            html += `<tr><td class="param-label">ε${i + 1}</td><td style="color:var(--text-1);font-size:11px">${escapeHtml(name)}${unit}${fixTag}</td>`;
            for (let j = 0; j <= i; j++) {
                const val = (sigMatrix[i] || [])[j];
                html += `<td>${val != null ? formatNum(val, 4) : '—'}</td>`;
            }
            for (let j = i + 1; j < dim; j++) html += '<td></td>';
            if (hasSE) {
                if (isFix) {
                    html += '<td>FIX</td>';
                } else {
                    const diagVal = (sigMatrix[i] || [])[i];
                    const diagSE = (sigSEMatrix[i] || [])[i];
                    const rse = (diagSE != null && diagVal != null && diagVal !== 0)
                        ? (diagSE / Math.abs(diagVal) * 100).toFixed(1) : '—';
                    html += `<td>${rse}</td>`;
                }
            }
            html += '</tr>';
        }
        html += '</tbody></table>';
    }

    // ── Summary line ──
    const parts = [];
    if (m.condition_number) parts.push(`Cond#: ${formatNum(m.condition_number, 1)}`);
    if (m.eta_shrinkage && m.eta_shrinkage.length)
        parts.push(`η-Shr: ${m.eta_shrinkage.map(s => formatNum(s, 1) + '%').join(', ')}`);
    if (m.eps_shrinkage && m.eps_shrinkage.length)
        parts.push(`ε-Shr: ${m.eps_shrinkage.map(s => formatNum(s, 1) + '%').join(', ')}`);
    if (parts.length)
        html += `<div style="margin-top:6px;font-size:11px;color:var(--text-2)">${parts.join(' &nbsp;│&nbsp; ')}</div>`;

    // COV failure reason
    if (m.covariance_step === false && m.cov_failure_reason) {
        html += `<div style="margin-top:4px;font-size:11px;color:var(--red)">COV: ${escapeHtml(m.cov_failure_reason)}</div>`;
    }

    // ETABAR test
    if (m.etabar_pval && m.etabar_pval.length) {
        const sigEtas = [];
        m.etabar_pval.forEach((p, i) => {
            if (p < 0.05) sigEtas.push(`η${i+1} (p=${p.toFixed(3)})`);
        });
        if (sigEtas.length) {
            html += `<div style="margin-top:4px;font-size:11px;color:var(--red)">ETABAR ≠ 0: ${sigEtas.join(', ')}</div>`;
        }
    }

    content.innerHTML = html;
}

function toggleAllModels(chk) {
    document.querySelectorAll('.model-chk').forEach(c => { c.checked = chk.checked; });
}

// ── Run Report Generation ──────────────
function generateReport() {
    if (selectedModelIdx < 0) return;
    const m = scannedModels[selectedModelIdx];
    if (!m.has_run) { alert('No completed run for this model.'); return; }

    const hasSE = m.covariance_step === true && m.theta_ses && m.theta_ses.some(s => s != null);
    const tNames = m.theta_names || [];
    const oNames = m.omega_names || [];
    const sNames = m.sigma_names || [];
    const tUnitsR = m.theta_units || [];
    const oUnitsR = m.omega_units || [];
    const sUnitsR = m.sigma_units || [];
    const now = new Date().toLocaleDateString('en-GB', { year: 'numeric', month: 'long', day: 'numeric' });

    let h = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Run Report: ' + m.name + '</title>\n';
    h += '<style>\n';
    h += "* { box-sizing: border-box; margin: 0; padding: 0; }\n";
    h += "body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; font-size: 11pt; color: #1a1a1a; padding: 40px 50px; max-width: 900px; margin: 0 auto; line-height: 1.5; }\n";
    h += "h1 { font-family: Georgia, 'Times New Roman', serif; font-size: 20pt; font-weight: 700; margin-bottom: 4px; }\n";
    h += "h2 { font-family: Georgia, 'Times New Roman', serif; font-size: 14pt; font-weight: 600; margin: 24px 0 10px; border-bottom: 2px solid #2563eb; padding-bottom: 4px; color: #1e3a5f; }\n";
    h += 'h3 { font-size: 11pt; font-weight: 600; margin: 16px 0 6px; color: #374151; }\n';
    h += '.subtitle { color: #6b7280; font-size: 10pt; margin-bottom: 20px; }\n';
    h += '.summary-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; margin: 12px 0 20px; }\n';
    h += '.summary-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px 14px; }\n';
    h += '.summary-label { font-size: 9pt; text-transform: uppercase; letter-spacing: 0.5px; color: #6b7280; font-weight: 600; }\n';
    h += '.summary-value { font-size: 14pt; font-weight: 600; color: #1a1a1a; margin-top: 2px; }\n';
    h += '.summary-value.ok { color: #16a34a; } .summary-value.fail { color: #dc2626; }\n';
    h += 'table { width: 100%; border-collapse: collapse; margin: 8px 0 16px; font-size: 10pt; }\n';
    h += 'th { background: #f1f5f9; color: #374151; font-weight: 600; text-align: left; padding: 6px 10px; border: 1px solid #e2e8f0; font-size: 9pt; text-transform: uppercase; letter-spacing: 0.3px; }\n';
    h += "td { padding: 5px 10px; border: 1px solid #e2e8f0; font-family: 'SF Mono', 'Menlo', monospace; font-size: 9.5pt; }\n";
    h += ".param-name { color: #6b7280; font-size: 9pt; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }\n";
    h += '.cor-high { background: #fef2f2; color: #dc2626; font-weight: 600; }\n';
    h += '.cor-low { background: #eff6ff; color: #2563eb; font-weight: 600; }\n';
    h += '.cor-diag { background: #f0fdf4; font-weight: 500; }\n';
    h += '.footer { margin-top: 30px; padding-top: 12px; border-top: 1px solid #e2e8f0; font-size: 9pt; color: #9ca3af; text-align: center; }\n';
    h += '@media print { body { padding: 20px; } }\n';
    h += '</style></head><body>\n';

    // Header
    h += '<h1>' + escapeHtml(m.name) + '</h1>';
    var methodStr = m.estimation_method ? ' &nbsp;|&nbsp; ' + escapeHtml(m.estimation_method) : '';
    h += '<div class="subtitle">' + escapeHtml(m.problem || '') + methodStr + ' &nbsp;|&nbsp; ' + now + '</div>';
    if (m.comment) {
        h += '<div style="color:#4b5563;font-size:10.5pt;font-style:italic;margin-bottom:16px">' + escapeHtml(m.comment) + '</div>';
    }

    // Summary boxes
    h += '<div class="summary-grid">';
    h += '<div class="summary-box"><div class="summary-label">Objective Function Value</div><div class="summary-value">' + formatNum(m.ofv, 4) + '</div></div>';
    var minCls = m.minimization_successful ? 'ok' : 'fail';
    h += '<div class="summary-box"><div class="summary-label">Minimization</div><div class="summary-value ' + minCls + '">' + (m.minimization_message || '\u2014') + '</div></div>';
    var covCls = m.covariance_step === true ? 'ok' : (m.covariance_step === false ? 'fail' : '');
    var covTxt = m.covariance_step === true ? 'Successful' : (m.covariance_step === false ? (m.cov_failure_reason || 'Failed') : 'Not requested');
    h += '<div class="summary-box"><div class="summary-label">Covariance Step</div><div class="summary-value ' + covCls + '">' + covTxt + '</div></div>';
    h += '<div class="summary-box"><div class="summary-label">Condition Number</div><div class="summary-value">' + (m.condition_number ? formatNum(m.condition_number, 1) : '\u2014') + '</div></div>';
    h += '<div class="summary-box"><div class="summary-label">Runtime</div><div class="summary-value">' + formatTime(m.runtime) + '</div></div>';
    var shrTxt = (m.eta_shrinkage || []).map(function(s, i) { return '\u03B7' + (i+1) + ': ' + formatNum(s,1) + '%'; }).join(', ') || '\u2014';
    h += '<div class="summary-box"><div class="summary-label">\u03B7-Shrinkage</div><div class="summary-value" style="font-size:10pt">' + shrTxt + '</div></div>';
    h += '</div>';

    // THETA table
    if (m.thetas && m.thetas.length) {
        h += '<h2>Fixed Effects (THETA)</h2>';
        h += '<table><thead><tr><th>#</th><th>Name</th><th>Estimate</th>';
        if (hasSE) h += '<th>SE</th><th>RSE (%)</th>';
        h += '</tr></thead><tbody>';
        m.thetas.forEach(function(val, i) {
            var name = tNames[i] || '';
            var unitStr = tUnitsR[i] ? ' <span style="color:#9ca3af;font-size:8.5pt">[' + escapeHtml(tUnitsR[i]) + ']</span>' : '';
            var se = hasSE ? (m.theta_ses || [])[i] : undefined;
            var isFix = (m.theta_fixed || [])[i] === true;
            var rse = (se != null && val !== 0) ? (se / Math.abs(val) * 100).toFixed(1) : (isFix ? 'FIX' : '\u2014');
            var fixStr = isFix ? ' <span style="color:#2563eb;font-size:9pt;font-weight:600">FIX</span>' : '';
            h += '<tr><td>\u03B8' + (i+1) + '</td><td class="param-name">' + escapeHtml(name) + unitStr + '</td><td>' + formatNum(val, 4) + fixStr + '</td>';
            if (hasSE) h += '<td>' + (se != null ? formatNum(se, 4) : '\u2014') + '</td><td>' + rse + '</td>';
            h += '</tr>';
        });
        h += '</tbody></table>';
    }

    // OMEGA table
    var omMatrix = m.omega_matrix || [];
    if (omMatrix.length) {
        var dim = omMatrix.length;
        var omSEMatrix = m.omega_se_matrix || [];
        var oFixed = m.omega_fixed || [];
        h += '<h2>Random Effects \u2014 Between Subject Variability (OMEGA)</h2>';
        h += '<table><thead><tr><th></th><th>Name</th>';
        for (var j = 0; j < dim; j++) h += '<th>\u03B7' + (j+1) + '</th>';
        if (hasSE) h += '<th>RSE (%)</th>';
        h += '<th>CV (%)</th></tr></thead><tbody>';
        for (var i = 0; i < dim; i++) {
            var name = oNames[i] || '';
            var oUnitStr = oUnitsR[i] ? ' <span style="color:#9ca3af;font-size:8.5pt">[' + escapeHtml(oUnitsR[i]) + ']</span>' : '';
            var oIsFix = oFixed[i] === true;
            var oFixStr = oIsFix ? ' <span style="color:#2563eb;font-size:9pt;font-weight:600">FIX</span>' : '';
            h += '<tr><td><b>\u03B7' + (i+1) + '</b></td><td class="param-name">' + escapeHtml(name) + oUnitStr + oFixStr + '</td>';
            for (var j2 = 0; j2 <= i; j2++) {
                var val = (omMatrix[i] || [])[j2];
                h += '<td>' + (val != null ? formatNum(val, 4) : '\u2014') + '</td>';
            }
            for (var j3 = i + 1; j3 < dim; j3++) h += '<td></td>';
            if (hasSE) {
                if (oIsFix) {
                    h += '<td>FIX</td>';
                } else {
                    var dv = (omMatrix[i] || [])[i], ds = (omSEMatrix[i] || [])[i];
                    var rse2 = (ds != null && dv != null && dv !== 0) ? (ds / Math.abs(dv) * 100).toFixed(1) : '\u2014';
                    h += '<td>' + rse2 + '</td>';
                }
            }
            var diagVal = (omMatrix[i] || [])[i];
            var cv = (diagVal != null && diagVal > 0) ? (Math.sqrt(diagVal) * 100).toFixed(1) : '\u2014';
            h += '<td>' + cv + '</td></tr>';
        }
        h += '</tbody></table>';
    }

    // SIGMA table
    var sigMatrix = m.sigma_matrix || [];
    if (sigMatrix.length) {
        var sdim = sigMatrix.length;
        var sigSEMatrix = m.sigma_se_matrix || [];
        var sFixed = m.sigma_fixed || [];
        h += '<h2>Residual Variability (SIGMA)</h2>';
        h += '<table><thead><tr><th></th><th>Name</th>';
        for (var sj = 0; sj < sdim; sj++) h += '<th>\u03B5' + (sj+1) + '</th>';
        if (hasSE) h += '<th>RSE (%)</th>';
        h += '</tr></thead><tbody>';
        for (var si = 0; si < sdim; si++) {
            var sname = sNames[si] || '';
            var sUnitStr = sUnitsR[si] ? ' <span style="color:#9ca3af;font-size:8.5pt">[' + escapeHtml(sUnitsR[si]) + ']</span>' : '';
            var sIsFix = sFixed[si] === true;
            var sFixStr = sIsFix ? ' <span style="color:#2563eb;font-size:9pt;font-weight:600">FIX</span>' : '';
            h += '<tr><td><b>\u03B5' + (si+1) + '</b></td><td class="param-name">' + escapeHtml(sname) + sUnitStr + sFixStr + '</td>';
            for (var sj2 = 0; sj2 <= si; sj2++) {
                var sval = (sigMatrix[si] || [])[sj2];
                h += '<td>' + (sval != null ? formatNum(sval, 4) : '\u2014') + '</td>';
            }
            for (var sj3 = si + 1; sj3 < sdim; sj3++) h += '<td></td>';
            if (hasSE) {
                if (sIsFix) {
                    h += '<td>FIX</td>';
                } else {
                    var sdv = (sigMatrix[si] || [])[si], sds = (sigSEMatrix[si] || [])[si];
                    var srse = (sds != null && sdv != null && sdv !== 0) ? (sds / Math.abs(sdv) * 100).toFixed(1) : '\u2014';
                    h += '<td>' + srse + '</td>';
                }
            }
            h += '</tr>';
        }
        h += '</tbody></table>';
    }

    // Correlation matrix
    var corMatrix = m.correlation_matrix || [];
    var corLabels = m.cor_labels || [];
    if (corMatrix.length > 1) {
        h += '<h2>Correlation Matrix of Parameter Estimates</h2>';
        var nP = corMatrix.length;
        var cLabels = [];
        if (corLabels.length >= nP) {
            cLabels = corLabels.slice(0, nP);
        } else {
            for (var ci = 0; ci < (m.thetas || []).length; ci++) cLabels.push('\u03B8' + (ci+1));
            for (var ci2 = 0; ci2 < (m.omegas || []).length; ci2++) cLabels.push('\u03C9' + (ci2+1));
            for (var ci3 = 0; ci3 < (m.sigmas || []).length; ci3++) cLabels.push('\u03C3' + (ci3+1));
            while (cLabels.length < nP) cLabels.push('P' + (cLabels.length + 1));
        }
        h += '<table style="font-size:8.5pt"><thead><tr><th></th>';
        for (var cj = 0; cj < nP; cj++) h += '<th style="text-align:center;padding:3px 4px;font-size:8pt">' + cLabels[cj] + '</th>';
        h += '</tr></thead><tbody>';
        for (var ci4 = 0; ci4 < nP; ci4++) {
            h += '<tr><td style="font-weight:600;font-size:8pt;white-space:nowrap">' + cLabels[ci4] + '</td>';
            for (var cj2 = 0; cj2 < nP; cj2++) {
                var cval = null;
                if (cj2 <= ci4 && corMatrix[ci4]) cval = corMatrix[ci4][cj2];
                else if (cj2 > ci4 && corMatrix[cj2]) cval = corMatrix[cj2][ci4];
                var ccls = '';
                if (ci4 === cj2) ccls = ' class="cor-diag"';
                else if (cval !== null && cval !== undefined) {
                    if (cval > 0.95) ccls = ' class="cor-high"';
                    else if (cval < -0.95) ccls = ' class="cor-low"';
                }
                var cdisp = (cval !== null && cval !== undefined) ? cval.toFixed(3) : '';
                h += '<td' + ccls + ' style="text-align:center;padding:3px 4px;font-size:8pt">' + cdisp + '</td>';
            }
            h += '</tr>';
        }
        h += '</tbody></table>';
        h += '<p style="font-size:8pt;color:#6b7280;margin-top:4px">Red: correlation &gt; 0.95 &nbsp;|&nbsp; Blue: correlation &lt; \u22120.95</p>';
    }

    // Shrinkage
    if ((m.eta_shrinkage && m.eta_shrinkage.length) || (m.eps_shrinkage && m.eps_shrinkage.length)) {
        h += '<h2>Shrinkage</h2>';
        if (m.eta_shrinkage && m.eta_shrinkage.length) {
            h += '<h3>\u03B7-Shrinkage (%)</h3><table><thead><tr>';
            m.eta_shrinkage.forEach(function(_, i) { h += '<th>\u03B7' + (i+1) + '</th>'; });
            h += '</tr></thead><tbody><tr>';
            m.eta_shrinkage.forEach(function(s) { h += '<td>' + formatNum(s, 1) + '</td>'; });
            h += '</tr></tbody></table>';
        }
        if (m.eps_shrinkage && m.eps_shrinkage.length) {
            h += '<h3>\u03B5-Shrinkage (%)</h3><table><thead><tr>';
            m.eps_shrinkage.forEach(function(_, i) { h += '<th>\u03B5' + (i+1) + '</th>'; });
            h += '</tr></thead><tbody><tr>';
            m.eps_shrinkage.forEach(function(s) { h += '<td>' + formatNum(s, 1) + '</td>'; });
            h += '</tr></tbody></table>';
        }
    }

    // ETABAR test
    if (m.etabar && m.etabar.length) {
        h += '<h2>ETABAR Test</h2>';
        h += '<p style="font-size:9.5pt;color:#6b7280;margin-bottom:8px">Null hypothesis: true mean of each ETA distribution = 0. P-values &lt; 0.05 (highlighted) suggest model misspecification.</p>';
        h += '<table><thead><tr><th></th>';
        m.etabar.forEach(function(_, i) { h += '<th>\u03B7' + (i+1) + '</th>'; });
        h += '</tr></thead><tbody>';
        h += '<tr><td style="font-weight:600">ETABAR</td>';
        m.etabar.forEach(function(v) { h += '<td>' + v.toExponential(3) + '</td>'; });
        h += '</tr>';
        if (m.etabar_se && m.etabar_se.length) {
            h += '<tr><td style="font-weight:600">SE</td>';
            m.etabar_se.forEach(function(v) { h += '<td>' + v.toExponential(3) + '</td>'; });
            h += '</tr>';
        }
        if (m.etabar_pval && m.etabar_pval.length) {
            h += '<tr><td style="font-weight:600">P-value</td>';
            m.etabar_pval.forEach(function(p) {
                var cls = p < 0.05 ? ' style="background:#fef2f2;color:#dc2626;font-weight:600"' : '';
                h += '<td' + cls + '>' + p.toFixed(4) + '</td>';
            });
            h += '</tr>';
        }
        h += '</tbody></table>';
    }

    // Footer
    h += '<div class="footer">Generated by NMGUI &nbsp;|&nbsp; ' + m.name + ' &nbsp;|&nbsp; ' + now + '</div>';
    h += '</body></html>';

    var win = window.open('', '_blank');
    win.document.write(h);
    win.document.close();
}

// ── Run panel (integrated) ─────────────
function showRunPanel() {
    if (selectedModelIdx < 0) return;
    document.getElementById('run-drawer').style.display = 'block';
}
function hideRunPanel() {
    document.getElementById('run-drawer').style.display = 'none';
}

async function launchRun() {
    if (selectedModelIdx < 0) return;
    const m = scannedModels[selectedModelIdx];
    const tool = document.getElementById('sel-tool').value;
    const extraArgs = document.getElementById('inp-extra-args').value.trim();
    const workDir = document.getElementById('inp-project-dir').value.trim();

    const btn = document.getElementById('btn-launch');
    btn.disabled = true;
    btn.textContent = 'Starting...';

    // Clear previous output and errors
    document.getElementById('console-output').textContent = '';
    const ep = document.getElementById('error-panel');
    if (ep) ep.innerHTML = '';
    document.getElementById('btn-errors').style.display = 'none';

    // Warn if unsaved changes
    if (window.cmIsClean && !window.cmIsClean()) {
        if (!confirm('You have unsaved changes in the editor. Run anyway?\n\n(The file on disk will be executed, not the editor content.)')) {
            btn.disabled = false;
            btn.textContent = '▶ Launch';
            return;
        }
    }

    appendConsole('── Cleaning previous run artifacts...\n');

    const data = await postJson('/api/run/start', {
        model: m.path, tool, extra_args: extraArgs, working_dir: workDir, clean: true
    });

    if (data.error) {
        alert('Error: ' + data.error);
        btn.disabled = false;
        btn.textContent = '▶ Launch';
        return;
    }

    currentRunId = data.run_id;
    document.getElementById('btn-stop').disabled = false;
    appendConsole(`$ ${data.command}\n\n`);

    if (eventSource) eventSource.close();
    eventSource = new EventSource(`/api/run/output/${data.run_id}`);
    eventSource.onmessage = (e) => {
        const msg = JSON.parse(e.data);
        if (msg.type === 'line') {
            appendConsole(msg.text);
        } else if (msg.type === 'done') {
            eventSource.close();
            eventSource = null;
            appendConsole(`\n── Run ${msg.returncode === 0 ? 'completed' : 'failed (rc=' + msg.returncode + ')'} ──\n`);
            btn.disabled = false;
            btn.textContent = '▶ Launch';
            document.getElementById('btn-stop').disabled = true;
            currentRunId = null;
            // Refresh model list to pick up new results
            setTimeout(() => scanModels(), 500);
        }
    };
    eventSource.onerror = () => {
        eventSource.close(); eventSource = null;
        btn.disabled = false; btn.textContent = '▶ Launch';
        document.getElementById('btn-stop').disabled = true;
    };
}

async function stopRun() {
    if (!currentRunId) return;
    await postJson('/api/run/stop', { run_id: currentRunId });
    appendConsole('\n── Run stopped ──\n');
}

function appendConsole(text) {
    const el = document.getElementById('console-output');
    el.textContent += text;
    el.scrollTop = el.scrollHeight;
}

// ── Editor API ─────────────────────────
function setEditorContent(text) {
    if (window.cmReady && window.cmSetContent) {
        window.cmSetContent(text);
    } else {
        // CM not loaded yet — queue content and also listen for ready
        window._cmPendingContent = text;
        console.log('NMGUI: CodeMirror not ready, content queued');
    }
}
function getEditorContent() {
    return (window.cmReady && window.cmGetContent) ? window.cmGetContent() : '';
}
function refreshEditor() {
    // Force CodeMirror to recalculate layout
}

// Change tracking callback — set from cm-init.js
window.cmOnCleanStateChange = function(isClean) {
    const indicator = document.getElementById('editor-unsaved');
    if (indicator) {
        indicator.style.display = isClean ? 'none' : 'inline';
    }
};

async function saveEditorFile() {
    if (!currentEditorPath) { alert('No file loaded.'); return; }
    const content = getEditorContent();
    const data = await postJson('/api/file/save', { path: currentEditorPath, content });
    if (data.error) {
        document.getElementById('editor-status').textContent = 'Error: ' + data.error;
    } else {
        document.getElementById('editor-status').textContent = 'Saved ✓';
        if (window.cmMarkClean) window.cmMarkClean();
    }
}

function saveEditorFileAs() {
    const newPath = prompt('Save as:', currentEditorPath);
    if (newPath) {
        currentEditorPath = newPath;
        document.getElementById('editor-filename').textContent = pathBasename(newPath);
        saveEditorFile();
    }
}

// ══════════════════════════════════════════
// ══ FILE BROWSER ═════════════════════════
// ══════════════════════════════════════════

function browseFor(target) {
    browseTarget = target;
    let startPath = document.getElementById('inp-project-dir').value || homeDir || '/';
    if (target === 'data') {
        startPath = document.getElementById('inp-data-dir').value || document.getElementById('inp-project-dir').value || homeDir;
    } else if (target === 'datadir') {
        startPath = document.getElementById('inp-data-dir').value || document.getElementById('inp-project-dir').value || homeDir;
    } else if (target === 'scandir') {
        startPath = document.getElementById('inp-scan-dir').value || document.getElementById('inp-project-dir').value || homeDir;
    } else if (target === 'evalfile') {
        startPath = document.getElementById('inp-project-dir').value || homeDir;
    } else if (target === 'vpcfolder') {
        startPath = document.getElementById('inp-vpc-folder').value || document.getElementById('inp-project-dir').value || homeDir;
    } else if (target === 'xposerundir') {
        startPath = document.getElementById('inp-xpose-rundir').value || document.getElementById('inp-project-dir').value || homeDir;
    }
    browseSelectedPath = null;
    document.getElementById('modal-browse').style.display = 'flex';
    browseTo(startPath);
}

async function browseTo(path) {
    browseCurrentPath = path;
    document.getElementById('inp-browse-path').value = path;
    const list = document.getElementById('browse-list');
    list.innerHTML = '<div style="padding:20px;color:var(--text-2);text-align:center">Loading...</div>';

    let filterExt = null;
    if (browseTarget === 'data') filterExt = ['.csv', '.tab', '.dat', '.txt', '.fit'];

    const data = await postJson('/api/browse', { path, filter: filterExt });
    if (data.error) {
        list.innerHTML = `<div style="padding:20px;color:var(--text-2)">${data.error}<br><br>
            <button class="btn btn-sm" onclick="browseTo('${homeDir}')">Go to Home</button></div>`;
        return;
    }
    list.innerHTML = '';
    data.items.forEach(item => {
        const el = document.createElement('div');
        el.className = 'browse-item';
        el.innerHTML = `
            <span class="browse-item-icon">${item.is_dir ? '📁' : '📄'}</span>
            <span class="browse-item-name">${item.name}</span>
            ${item.size ? `<span class="browse-item-size">${(item.size / 1024).toFixed(1)}K</span>` : ''}
        `;
        el.onclick = () => {
            if (item.is_dir) { browseTo(item.path); }
            else {
                list.querySelectorAll('.browse-item').forEach(i => i.classList.remove('selected'));
                el.classList.add('selected');
                browseSelectedPath = item.path;
            }
        };
        el.ondblclick = () => {
            if (item.is_dir) browseTo(item.path);
            else { browseSelectedPath = item.path; selectBrowsed(); }
        };
        list.appendChild(el);
    });
}

function browseUp() {
    var parts = browseCurrentPath.split(/[/\\]/).filter(Boolean);
    if (parts.length <= 1) {
        // At root: Unix '/' or Windows 'C:\'
        var root = browseCurrentPath.match(/^[A-Za-z]:\\/) ? parts[0] + '\\' : '/';
        browseTo(root);
        return;
    }
    parts.pop();
    var sep = browseCurrentPath.includes('\\') ? '\\' : '/';
    var parent = parts.join(sep);
    // Preserve leading slash on Unix or drive letter on Windows
    if (sep === '/' && !parent.startsWith('/')) parent = '/' + parent;
    browseTo(parent);
}

function selectBrowsed() {
    const selected = browseSelectedPath || browseCurrentPath;
    if (!selected) return;
    if (browseTarget === 'projectdir') {
        document.getElementById('inp-project-dir').value = selected;
        document.getElementById('inp-scan-dir').value = selected;
        document.getElementById('inp-data-dir').value = selected;
        closeModal();
        scanModels();
        return;
    } else if (browseTarget === 'scandir') {
        document.getElementById('inp-scan-dir').value = selected;
    } else if (browseTarget === 'datadir') {
        document.getElementById('inp-data-dir').value = selected;
        closeModal();
        refreshDataFiles();
        return;
    } else if (browseTarget === 'data') {
        loadDataFromSidebar(selected);
    } else if (browseTarget === 'evalfile') {
        document.getElementById('inp-eval-file').value = selected;
        loadEvalData();
    } else if (browseTarget === 'vpcfolder') {
        document.getElementById('inp-vpc-folder').value = selected;
    } else if (browseTarget === 'xposerundir') {
        document.getElementById('inp-xpose-rundir').value = selected;
    }
    closeModal();
}

function closeModal() {
    document.getElementById('modal-browse').style.display = 'none';
}

// ══════════════════════════════════════════
// ══ COMPARISON TABLE BUILDER ═════════════
// ══════════════════════════════════════════

function buildComparisonTable(runs) {
    const maxThetas = Math.max(...runs.map(r => (r.thetas || []).length));
    const maxOmegas = Math.max(...runs.map(r => (r.omegas || []).length));
    const maxSigmas = Math.max(...runs.map(r => (r.sigmas || []).length));

    let html = '<table class="compare-table"><thead><tr><th>Parameter</th>';
    runs.forEach(r => { html += `<th>${r.name || r.run_name}</th>`; });
    html += '</tr></thead><tbody>';

    // OFV
    const ofvs2 = runs.map(r => r.ofv).filter(v => v !== null);
    const bestOFV = ofvs2.length ? Math.min(...ofvs2) : null;
    html += '<tr><td class="param-label">OFV</td>';
    runs.forEach(r => {
        const cls = r.ofv === bestOFV ? 'compare-better' : '';
        html += `<td class="${cls}">${formatNum(r.ofv, 2)}</td>`;
    });
    html += '</tr>';

    html += '<tr><td class="param-label">ΔOFV (vs best)</td>';
    runs.forEach(r => {
        const d = r.ofv !== null && bestOFV !== null ? (r.ofv - bestOFV).toFixed(2) : '—';
        html += `<td>${d}</td>`;
    });
    html += '</tr>';

    for (let i = 0; i < maxThetas; i++) {
        html += `<tr><td class="param-label">THETA(${i + 1})</td>`;
        runs.forEach(r => {
            const val = (r.thetas || [])[i];
            const se = (r.theta_ses || [])[i];
            let cell = formatNum(val);
            if (se != null && val != null && val !== 0) {
                cell += ` <span style="color:var(--text-2)">(${(se / Math.abs(val) * 100).toFixed(1)}%)</span>`;
            }
            html += `<td>${cell}</td>`;
        });
        html += '</tr>';
    }

    for (let i = 0; i < maxOmegas; i++) {
        html += `<tr><td class="param-label">OMEGA(${i + 1},${i + 1})</td>`;
        runs.forEach(r => {
            const val = (r.omegas || [])[i];
            let cell = formatNum(val);
            if (val !== null && val != null && val > 0) {
                cell += ` <span style="color:var(--text-2)">[CV=${(Math.sqrt(val) * 100).toFixed(1)}%]</span>`;
            }
            html += `<td>${cell}</td>`;
        });
        html += '</tr>';
    }

    for (let i = 0; i < maxSigmas; i++) {
        html += `<tr><td class="param-label">SIGMA(${i + 1},${i + 1})</td>`;
        runs.forEach(r => { html += `<td>${formatNum((r.sigmas || [])[i])}</td>`; });
        html += '</tr>';
    }

    html += '<tr><td class="param-label">Condition #</td>';
    runs.forEach(r => { html += `<td>${r.condition_number ? formatNum(r.condition_number, 1) : '—'}</td>`; });
    html += '</tr>';

    html += '<tr><td class="param-label">η-Shrinkage</td>';
    runs.forEach(r => {
        html += `<td>${(r.eta_shrinkage || []).map(s => formatNum(s, 1) + '%').join(', ') || '—'}</td>`;
    });
    html += '</tr>';

    html += '</tbody></table>';
    return html;
}

// ══════════════════════════════════════════
// ══ RUN OVERVIEW TAB ═════════════════════
// ══════════════════════════════════════════

async function scanRuns() {
    const dir = document.getElementById('inp-scan-dir').value.trim();
    if (!dir) { console.log('NMGUI: scanRuns — no directory'); return; }
    console.log('NMGUI: scanRuns scanning', dir);
    const runs = await postJson('/api/runs/scan', { directory: dir });
    if (runs.error) { alert(runs.error); console.error('NMGUI: scanRuns error', runs.error); return; }
    console.log('NMGUI: scanRuns found', runs.length, 'runs', runs);
    overviewRuns = runs;
    renderOverview();
}

function renderOverview() {
    const tbody = document.getElementById('overview-body');
    tbody.innerHTML = '';
    const ofvs = overviewRuns.map(r => r.ofv).filter(v => v !== null);
    const refOFV = ofvs.length > 0 ? Math.min(...ofvs) : null;

    overviewRuns.forEach((run, idx) => {
        const statusClass = run.minimization_successful === true ? 'status-ok' :
            run.minimization_successful === false ? 'status-fail' : 'text-muted';
        const statusText = run.minimization_message || run.status || '—';
        const deltaOFV = (run.ofv !== null && refOFV !== null) ? (run.ofv - refOFV).toFixed(2) : '—';
        const thetaStr = (run.thetas || []).map(t => formatNum(t)).join(', ') || '—';
        const shrStr = (run.eta_shrinkage || []).map(s => formatNum(s, 1) + '%').join(', ') || '—';

        const covClass = run.covariance_step === true ? 'status-ok' :
            run.covariance_step === false ? 'status-fail' : 'text-muted';
        const covText = run.covariance_step === true ? 'Y' :
            run.covariance_step === false ? 'N' : '—';

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><input type="checkbox" class="run-chk" data-idx="${idx}" onchange="updateCompareBtn()"></td>
            <td><strong>${run.run_name || '—'}</strong></td>
            <td class="${statusClass}">${statusText}</td>
            <td class="${covClass}">${covText}</td>
            <td>${formatNum(run.ofv, 2)}</td>
            <td>${deltaOFV}</td>
            <td style="max-width:300px;overflow:hidden;text-overflow:ellipsis">${thetaStr}</td>
            <td>${run.condition_number ? formatNum(run.condition_number, 1) : '—'}</td>
            <td>${shrStr}</td>
            <td>${formatTime(run.runtime)}</td>
            <td><button class="btn btn-sm" onclick="showRunDetail(${idx})">Details</button></td>
        `;
        tbody.appendChild(tr);
    });
}

function toggleAllRuns(chk) { document.querySelectorAll('.run-chk').forEach(c => { c.checked = chk.checked; }); updateCompareBtn(); }
function updateCompareBtn() { document.getElementById('btn-compare').disabled = document.querySelectorAll('.run-chk:checked').length < 2; }

function compareRuns() {
    const indices = [];
    document.querySelectorAll('.run-chk:checked').forEach(c => indices.push(parseInt(c.dataset.idx)));
    if (indices.length < 2) return;
    const runs = indices.map(i => overviewRuns[i]);
    document.getElementById('compare-content').innerHTML = buildComparisonTable(runs);
    document.getElementById('compare-panel').style.display = 'block';
    document.getElementById('compare-panel').scrollIntoView({ behavior: 'smooth' });
}
function closeCompare() { document.getElementById('compare-panel').style.display = 'none'; }

async function showRunDetail(idx) {
    const run = overviewRuns[idx];
    const panel = document.getElementById('detail-panel');
    const content = document.getElementById('detail-content');
    document.getElementById('detail-title').textContent = `Run: ${run.run_name}`;

    let html = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">';
    html += '<div>';
    html += `<p><strong>OFV:</strong> ${formatNum(run.ofv, 4)}</p>`;
    html += `<p><strong>Status:</strong> ${run.minimization_message || '—'}</p>`;
    html += `<p><strong>Runtime:</strong> ${formatTime(run.runtime)}</p>`;
    html += `<p><strong>Condition #:</strong> ${run.condition_number ? formatNum(run.condition_number, 1) : '—'}</p>`;

    if (run.thetas && run.thetas.length) {
        html += '<h4 style="margin-top:10px;color:var(--text-2);font-size:11px">THETA Estimates</h4>';
        html += '<table class="data-table data-table-sm"><thead><tr><th>#</th><th>Est</th><th>SE</th><th>RSE%</th></tr></thead><tbody>';
        run.thetas.forEach((t, i) => {
            const se = (run.theta_ses || [])[i];
            const rse = (se != null && t !== 0) ? (se / Math.abs(t) * 100).toFixed(1) : '—';
            html += `<tr><td>θ${i + 1}</td><td>${formatNum(t)}</td><td>${se != null ? formatNum(se) : '—'}</td><td>${rse}</td></tr>`;
        });
        html += '</tbody></table>';
    }
    if (run.omegas && run.omegas.length) {
        html += '<h4 style="margin-top:10px;color:var(--text-2);font-size:11px">OMEGA Estimates</h4>';
        html += '<table class="data-table data-table-sm"><thead><tr><th>#</th><th>Est</th><th>CV%</th></tr></thead><tbody>';
        run.omegas.forEach((o, i) => {
            const cv = o > 0 ? (Math.sqrt(o) * 100).toFixed(1) : '—';
            html += `<tr><td>Ω${i + 1},${i + 1}</td><td>${formatNum(o)}</td><td>${cv}</td></tr>`;
        });
        html += '</tbody></table>';
    }
    if (run.eta_shrinkage && run.eta_shrinkage.length) {
        html += `<p style="margin-top:8px"><strong>η-Shrinkage:</strong> ${run.eta_shrinkage.map(s => formatNum(s, 1) + '%').join(', ')}</p>`;
    }
    html += '</div>';

    // Right: file listing
    html += '<div>';
    if (run.directory) {
        const files = await postJson('/api/browse', { path: run.directory });
        if (!files.error && files.items) {
            html += '<h4 style="color:var(--text-2);font-size:11px;margin-bottom:6px">Output Files</h4>';
            html += '<div style="max-height:200px;overflow-y:auto">';
            files.items.forEach(f => {
                if (!f.is_dir) {
                    const isData = ['.tab', '.csv', '.dat', '.fit'].some(e => f.name.endsWith(e));
                    const isLst = f.name.endsWith('.lst');
                    html += `<div style="font-family:var(--mono);font-size:11px;padding:2px 0">${f.name}`;
                    if (isData) html += ` <button class="btn btn-sm" style="font-size:10px;padding:1px 6px" onclick="openInViewer('${f.path.replace(/'/g, "\\'")}')">View</button>`;
                    if (isData) html += ` <button class="btn btn-sm" style="font-size:10px;padding:1px 6px" onclick="openInEvaluation('${f.path.replace(/'/g, "\\'")}')">GOF</button>`;
                    if (isLst) html += ` <button class="btn btn-sm" style="font-size:10px;padding:1px 6px" onclick="showLstRaw('${f.path.replace(/'/g, "\\'")}')">Raw</button>`;
                    html += '</div>';
                }
            });
            html += '</div>';
        }
    }
    html += '</div></div><div id="lst-raw-container"></div>';

    content.innerHTML = html;
    panel.style.display = 'block';
    panel.scrollIntoView({ behavior: 'smooth' });
}

async function showLstRaw(path) {
    const data = await postJson('/api/run/lst', { path });
    if (data.content) {
        document.getElementById('lst-raw-container').innerHTML =
            `<h4 style="color:var(--text-2);font-size:11px;margin:8px 0">Raw .lst Output</h4>
             <pre class="lst-raw">${escapeHtml(data.content)}</pre>`;
    }
}
function closeDetail() { document.getElementById('detail-panel').style.display = 'none'; }

function openInViewer(path) {
    // Switch to viewer tab
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelector('[data-tab="viewer"]').classList.add('active');
    document.getElementById('tab-viewer').classList.add('active');
    // Set the data dir from the file path
    const dir = path.substring(0, path.lastIndexOf('/'));
    if (dir) document.getElementById('inp-data-dir').value = dir;
    refreshDataFiles();
    loadDataFromSidebar(path);
}

// ══════════════════════════════════════════
// ══ DATA VIEWER TAB ══════════════════════
// ══════════════════════════════════════════

let currentDataFilePath = '';

async function refreshDataFiles() {
    const dir = document.getElementById('inp-data-dir').value.trim() || document.getElementById('inp-project-dir').value.trim();
    if (!dir) return;
    document.getElementById('inp-data-dir').value = dir;

    const list = document.getElementById('data-file-list');
    list.innerHTML = '<div style="padding:8px;color:var(--text-2);font-size:11px">Loading...</div>';

    const dataExts = ['.csv', '.tab', '.dat', '.txt', '.fit', '.dta'];

    // Scan root dir
    const root = await postJson('/api/browse', { path: dir });
    if (root.error) { list.innerHTML = `<div style="padding:8px;color:var(--text-2)">${root.error}</div>`; return; }

    let html = '';
    const rootFiles = (root.items || []).filter(i => !i.is_dir && dataExts.some(e => i.name.toLowerCase().endsWith(e)));
    if (rootFiles.length) {
        rootFiles.forEach(f => {
            const active = f.path === currentDataFilePath ? ' active' : '';
            html += `<div class="data-file-item${active}" onclick="loadDataFromSidebar('${f.path.replace(/'/g, "\\'")}')" title="${f.name}"><span class="file-icon">📄</span>${f.name}</div>`;
        });
    }

    // Scan subdirs (run folders) for output tables
    const subdirs = (root.items || []).filter(i => i.is_dir);
    for (const sub of subdirs.slice(0, 30)) {
        const subData = await postJson('/api/browse', { path: sub.path });
        if (subData.error || !subData.items) continue;
        const subFiles = subData.items.filter(i => !i.is_dir && dataExts.some(e => i.name.toLowerCase().endsWith(e)));
        if (subFiles.length) {
            html += `<div class="data-file-subdir">📁 ${sub.name}/</div>`;
            subFiles.forEach(f => {
                const active = f.path === currentDataFilePath ? ' active' : '';
                html += `<div class="data-file-item${active}" onclick="loadDataFromSidebar('${f.path.replace(/'/g, "\\'")}')" title="${f.name}" style="padding-left:20px"><span class="file-icon">📄</span>${f.name}</div>`;
            });
        }
    }

    if (!html) html = '<div style="padding:8px;color:var(--text-2);font-size:11px">No data files found</div>';
    list.innerHTML = html;
}

async function loadDataFromSidebar(path) {
    currentDataFilePath = path;
    // Highlight in list
    document.querySelectorAll('.data-file-item').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.data-file-item').forEach(el => {
        if (el.getAttribute('onclick').includes(path.replace(/'/g, "\\'"))) el.classList.add('active');
    });
    // Load the data
    await loadDataFileByPath(path);
}

async function loadDataFile() {
    const path = document.getElementById('inp-data-path')?.value?.trim();
    if (!path) return;
    await loadDataFileByPath(path);
}

async function loadDataFileByPath(path) {
    const data = await postJson('/api/data/read', { path });
    if (data.error) { alert(data.error); return; }

    currentDataFilePath = path;
    viewerData = { columns: data.columns, data: data.data, filteredData: data.data };
    activeFilters = {};

    document.getElementById('data-title').textContent = data.name;
    document.getElementById('data-info').textContent = `${data.n_rows} rows × ${data.columns.length} cols`;

    const selX = document.getElementById('sel-plot-x');
    const selY = document.getElementById('sel-plot-y');
    selX.innerHTML = ''; selY.innerHTML = '';
    data.columns.forEach(c => {
        selX.innerHTML += `<option value="${c}">${c}</option>`;
        selY.innerHTML += `<option value="${c}">${c}</option>`;
    });
    if (data.columns.length > 1) selY.selectedIndex = 1;

    // Populate custom plot filter dropdowns
    ['sel-pf1-col', 'sel-pf2-col'].forEach(id => {
        const sel = document.getElementById(id);
        sel.innerHTML = '<option value="">\u2014</option>';
        data.columns.forEach(c => { sel.innerHTML += `<option value="${c}">${c}</option>`; });
    });

    renderFilterBar();
    renderDataTable();
}

function renderFilterBar() {
    const bar = document.getElementById('filter-bar');
    bar.innerHTML = '';
    const addBtn = document.createElement('button');
    addBtn.className = 'btn btn-sm';
    addBtn.textContent = '+ Add Filter';
    addBtn.onclick = () => showFilterDropdown(addBtn);
    bar.appendChild(addBtn);

    for (const [col, excluded] of Object.entries(activeFilters)) {
        if (excluded.size === 0) continue;
        const tag = document.createElement('span');
        tag.className = 'filter-tag';
        tag.innerHTML = `${col} ≠ {${[...excluded].slice(0, 3).join(', ')}${excluded.size > 3 ? '...' : ''}}
            <span class="remove-filter" onclick="removeFilter('${col}')">✕</span>`;
        bar.appendChild(tag);
    }
}

async function showFilterDropdown(anchorEl) {
    if (!viewerData) return;
    document.querySelectorAll('.filter-dropdown').forEach(d => d.remove());

    const dd = document.createElement('div');
    dd.className = 'filter-dropdown';
    dd.style.position = 'fixed';
    const rect = anchorEl.getBoundingClientRect();
    dd.style.top = (rect.bottom + 4) + 'px';
    dd.style.left = rect.left + 'px';

    dd.innerHTML = '<div style="padding:4px;font-size:11px;color:var(--text-2);font-weight:600">Select column</div>';
    viewerData.columns.forEach(col => {
        const item = document.createElement('div');
        item.style.cssText = 'padding:4px 8px;cursor:pointer;font-size:12px;border-radius:3px';
        item.textContent = col;
        item.onmouseover = () => item.style.background = 'var(--bg-hover)';
        item.onmouseout = () => item.style.background = '';
        item.onclick = () => showColumnFilterValues(dd, col);
        dd.appendChild(item);
    });
    document.body.appendChild(dd);
    setTimeout(() => {
        document.addEventListener('click', function handler(e) {
            if (!dd.contains(e.target) && e.target !== anchorEl) { dd.remove(); document.removeEventListener('click', handler); }
        });
    }, 10);
}

async function showColumnFilterValues(dd, col) {
    const colIdx = viewerData.columns.indexOf(col);
    const uniqueVals = [...new Set(viewerData.data.map(r => String(r[colIdx])))].sort((a, b) => {
        const na = parseFloat(a), nb = parseFloat(b);
        if (!isNaN(na) && !isNaN(nb)) return na - nb;
        return a.localeCompare(b);
    });
    const excluded = activeFilters[col] || new Set();

    dd.innerHTML = `<div style="padding:4px;font-size:11px;color:var(--text-2);font-weight:600">${col}</div>`;
    const actions = document.createElement('div');
    actions.className = 'filter-dd-actions';
    actions.innerHTML = `<button onclick="filterSelectAll('${col}', true)">Check All</button>
                         <button onclick="filterSelectAll('${col}', false)">Uncheck All</button>
                         <button onclick="applyColumnFilter('${col}')">Apply</button>`;
    dd.appendChild(actions);

    const listDiv = document.createElement('div');
    listDiv.id = 'filter-values-list';
    listDiv.style.maxHeight = '200px';
    listDiv.style.overflowY = 'auto';
    uniqueVals.slice(0, 200).forEach(val => {
        const label = document.createElement('label');
        label.innerHTML = `<input type="checkbox" data-val="${val}" ${!excluded.has(val) ? 'checked' : ''}> ${val}`;
        listDiv.appendChild(label);
    });
    dd.appendChild(listDiv);
}

window.filterSelectAll = function (col, checked) {
    document.querySelectorAll('#filter-values-list input[type="checkbox"]').forEach(cb => { cb.checked = checked; });
};
window.applyColumnFilter = function (col) {
    const excluded = new Set();
    document.querySelectorAll('#filter-values-list input[type="checkbox"]').forEach(cb => {
        if (!cb.checked) excluded.add(cb.dataset.val);
    });
    if (excluded.size > 0) activeFilters[col] = excluded;
    else delete activeFilters[col];
    applyFilters();
    document.querySelectorAll('.filter-dropdown').forEach(d => d.remove());
};

function removeFilter(col) { delete activeFilters[col]; applyFilters(); }

function applyFilters() {
    if (!viewerData) return;
    let filtered = viewerData.data;
    for (const [col, excluded] of Object.entries(activeFilters)) {
        const colIdx = viewerData.columns.indexOf(col);
        if (colIdx < 0) continue;
        filtered = filtered.filter(row => !excluded.has(String(row[colIdx])));
    }
    viewerData.filteredData = filtered;
    renderFilterBar();
    renderDataTable();
    if (document.getElementById('sel-plot-x').value && document.getElementById('sel-plot-y').value) drawPlot();
}

function renderDataTable() {
    if (!viewerData) return;
    document.getElementById('data-thead').innerHTML = viewerData.columns.map(c => `<th>${c}</th>`).join('');
    const tbody = document.getElementById('data-tbody');
    tbody.innerHTML = '';
    const rows = viewerData.filteredData.slice(0, 500);
    document.getElementById('data-info').textContent =
        `${viewerData.filteredData.length} rows × ${viewerData.columns.length} cols` +
        (viewerData.filteredData.length < viewerData.data.length ? ` (filtered from ${viewerData.data.length})` : '') +
        (viewerData.filteredData.length > 500 ? ' — showing first 500' : '');
    rows.forEach(row => {
        const tr = document.createElement('tr');
        tr.innerHTML = row.map(v => `<td>${v}</td>`).join('');
        tbody.appendChild(tr);
    });
}

function applyCustomPlotFilter(data, columns, n) {
    var col = document.getElementById('sel-pf' + n + '-col').value;
    if (!col) return data;
    var op = document.getElementById('sel-pf' + n + '-op').value;
    var valStr = document.getElementById('inp-pf' + n + '-val').value.trim();
    if (valStr === '') return data;
    var colIdx = columns.indexOf(col);
    if (colIdx < 0) return data;
    var numVal = Number(valStr);
    var isNum = !isNaN(numVal);
    return data.filter(function(r) {
        var cell = r[colIdx];
        var cellNum = Number(cell);
        var useNum = isNum && !isNaN(cellNum);
        switch (op) {
            case '==': return useNum ? cellNum === numVal : String(cell) === valStr;
            case '>':  return useNum ? cellNum > numVal : false;
            case '<':  return useNum ? cellNum < numVal : false;
            case '>=': return useNum ? cellNum >= numVal : false;
            case '<=': return useNum ? cellNum <= numVal : false;
            case '!=': return useNum ? cellNum !== numVal : String(cell) !== valStr;
            default: return true;
        }
    });
}

function drawPlot() {
    if (!viewerData || !viewerData.filteredData.length) return;
    const xCol = document.getElementById('sel-plot-x').value;
    const yCol = document.getElementById('sel-plot-y').value;
    if (!xCol || !yCol) return;
    const xIdx = viewerData.columns.indexOf(xCol);
    const yIdx = viewerData.columns.indexOf(yCol);

    // MDV filter
    let plotData = viewerData.filteredData;
    const excludeMDV = document.getElementById('chk-exclude-mdv').checked;
    if (excludeMDV) {
        const mdvIdx = viewerData.columns.findIndex(c => c.toUpperCase() === 'MDV');
        if (mdvIdx >= 0) {
            plotData = plotData.filter(r => r[mdvIdx] === 0 || r[mdvIdx] === '0');
        }
    }

    // Custom filters
    plotData = applyCustomPlotFilter(plotData, viewerData.columns, 1);
    plotData = applyCustomPlotFilter(plotData, viewerData.columns, 2);

    const x = plotData.map(r => r[xIdx]);
    const y = plotData.map(r => r[yIdx]);

    const traces = [{
        x, y,
        mode: 'markers', type: 'scattergl',
        marker: { color: '#5b9cf5', size: 6, opacity: 0.5 },
        name: `${yCol} vs ${xCol}`,
    }];

    const shapes = [];
    const showUnity = document.getElementById('chk-unity').checked;
    const showYZero = document.getElementById('chk-yzero').checked;
    const showLoess = document.getElementById('chk-loess').checked;

    // Y=X line of unity
    if (showUnity) {
        const numX = x.filter(v => typeof v === 'number' && isFinite(v));
        const numY = y.filter(v => typeof v === 'number' && isFinite(v));
        const allVals = numX.concat(numY);
        if (allVals.length) {
            const mn = Math.min(...allVals);
            const mx = Math.max(...allVals);
            traces.push({
                x: [mn, mx], y: [mn, mx],
                mode: 'lines', type: 'scatter',
                line: { color: '#f87171', width: 1.5, dash: 'dash' },
                name: 'Y=X', showlegend: true,
            });
        }
    }

    // Y=0 reference line
    if (showYZero) {
        shapes.push({
            type: 'line', xref: 'paper', x0: 0, x1: 1, yref: 'y', y0: 0, y1: 0,
            line: { color: '#fbbf24', width: 1.5, dash: 'dash' }
        });
    }

    // LOESS smoother
    if (showLoess) {
        const loessTrace = computeLoess(x, y);
        if (loessTrace) {
            traces.push({
                x: loessTrace.x, y: loessTrace.y,
                mode: 'lines', type: 'scatter',
                line: { color: '#4ade80', width: 2 },
                name: 'LOESS', showlegend: true,
            });
        }
    }

    Plotly.newPlot('plot-container', traces, {
        xaxis: { title: xCol, color: '#b0b5c8', gridcolor: '#2e3348', zerolinecolor: '#3a3f57' },
        yaxis: { title: yCol, color: '#b0b5c8', gridcolor: '#2e3348', zerolinecolor: '#3a3f57' },
        paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: '#171922',
        font: { family: 'SF Mono, Menlo, monospace', size: 11, color: '#b0b5c8' },
        margin: { t: 10, r: 20, b: 50, l: 60 },
        shapes: shapes,
        showlegend: traces.length > 1,
        legend: { x: 0.01, y: 0.99, bgcolor: 'rgba(23,25,34,0.8)', font: { size: 10, color: '#b0b5c8' } },
    }, { responsive: true, displayModeBar: true, modeBarButtonsToRemove: ['toImage', 'sendDataToCloud'] });
}

// ── LOESS smoother (local polynomial regression) ──
function computeLoess(xRaw, yRaw, bandwidth) {
    // Filter to numeric pairs
    const pairs = [];
    for (let i = 0; i < xRaw.length; i++) {
        const xv = Number(xRaw[i]), yv = Number(yRaw[i]);
        if (isFinite(xv) && isFinite(yv)) pairs.push([xv, yv]);
    }
    if (pairs.length < 6) return null;
    pairs.sort((a, b) => a[0] - b[0]);

    const xs = pairs.map(p => p[0]);
    const ys = pairs.map(p => p[1]);
    const n = xs.length;
    const bw = bandwidth || 0.3;
    const k = Math.max(3, Math.floor(n * bw));

    // Generate evaluation points
    const nEval = Math.min(80, n);
    const xMin = xs[0], xMax = xs[n - 1];
    const step = (xMax - xMin) / (nEval - 1);
    const evalX = [], evalY = [];

    for (let i = 0; i < nEval; i++) {
        const xp = xMin + i * step;
        // Find k nearest neighbors
        const dists = xs.map((x, j) => ({ d: Math.abs(x - xp), j }));
        dists.sort((a, b) => a.d - b.d);
        const neighbors = dists.slice(0, k);
        const maxDist = neighbors[neighbors.length - 1].d || 1;

        // Tricube weights
        let sumW = 0, sumWX = 0, sumWY = 0, sumWXX = 0, sumWXY = 0;
        for (const nb of neighbors) {
            const u = nb.d / (maxDist * 1.001);
            const w = Math.pow(1 - Math.pow(u, 3), 3);
            const xj = xs[nb.j], yj = ys[nb.j];
            sumW += w; sumWX += w * xj; sumWY += w * yj;
            sumWXX += w * xj * xj; sumWXY += w * xj * yj;
        }
        // Weighted linear regression
        const denom = sumW * sumWXX - sumWX * sumWX;
        if (Math.abs(denom) < 1e-12) continue;
        const b1 = (sumW * sumWXY - sumWX * sumWY) / denom;
        const b0 = (sumWY - b1 * sumWX) / sumW;
        evalX.push(xp);
        evalY.push(b0 + b1 * xp);
    }
    return evalX.length > 2 ? { x: evalX, y: evalY } : null;
}

// ── GOF Presets ────────────────────────
function applyGofPreset() {
    const preset = document.getElementById('sel-gof-preset').value;
    if (!preset || !viewerData) return;

    document.getElementById('eta-cov-row').style.display = 'none';

    // Column name matching — case-insensitive, try common variations
    const cols = viewerData.columns;
    const find = (names) => {
        for (const n of names) {
            const idx = cols.findIndex(c => c.toUpperCase() === n.toUpperCase());
            if (idx >= 0) return cols[idx];
        }
        return null;
    };

    const selX = document.getElementById('sel-plot-x');
    const selY = document.getElementById('sel-plot-y');
    const chkUnity = document.getElementById('chk-unity');
    const chkYZero = document.getElementById('chk-yzero');
    const chkLoess = document.getElementById('chk-loess');

    // Reset
    chkUnity.checked = false;
    chkYZero.checked = false;
    chkLoess.checked = false;

    if (preset === 'dv_pred') {
        const x = find(['PRED']); const y = find(['DV']);
        if (x && y) { selX.value = x; selY.value = y; chkUnity.checked = true; chkLoess.checked = true; drawPlot(); }
        else alert('Columns PRED and/or DV not found');
    } else if (preset === 'dv_ipred') {
        const x = find(['IPRED']); const y = find(['DV']);
        if (x && y) { selX.value = x; selY.value = y; chkUnity.checked = true; chkLoess.checked = true; drawPlot(); }
        else alert('Columns IPRED and/or DV not found');
    } else if (preset === 'cwres_time') {
        const x = find(['TIME', 'TAD']); const y = find(['CWRES', 'WRES']);
        if (x && y) { selX.value = x; selY.value = y; chkYZero.checked = true; chkLoess.checked = true; drawPlot(); }
        else alert('Columns TIME and/or CWRES not found');
    } else if (preset === 'cwres_pred') {
        const x = find(['PRED']); const y = find(['CWRES', 'WRES']);
        if (x && y) { selX.value = x; selY.value = y; chkYZero.checked = true; chkLoess.checked = true; drawPlot(); }
        else alert('Columns PRED and/or CWRES not found');
    } else if (preset === 'iwres_ipred') {
        const x = find(['IPRED']); const y = find(['IWRES']);
        if (x && y) { selX.value = x; selY.value = y; chkYZero.checked = true; chkLoess.checked = true; drawPlot(); }
        else alert('Columns IPRED and/or IWRES not found');
    } else if (preset === 'eta_cov') {
        showEtaCovSelector();
    } else if (preset === 'qq_cwres') {
        const yName = find(['CWRES', 'WRES']);
        if (yName) drawQQPlot(yName);
        else alert('Column CWRES or WRES not found');
    }
}

function showEtaCovSelector() {
    if (!viewerData) return;
    document.getElementById('eta-cov-row').style.display = 'flex';
    const etaSel = document.getElementById('sel-eta-col');
    const covSel = document.getElementById('sel-cov-col');
    etaSel.innerHTML = '';
    covSel.innerHTML = '';

    const etaCols = viewerData.columns.filter(c => /^ETA/i.test(c) || /^ET\d/i.test(c));
    const covCols = viewerData.columns.filter(c =>
        /^(WT|AGE|SEX|CRCL|CLcr|BMI|BSA|HT|LBM|FFM|GFR|RACE|BWT)/i.test(c)
    );
    // Fallback: any non-standard columns could be covariates
    const standardCols = new Set(['ID','TIME','DV','PRED','IPRED','CWRES','IWRES','WRES','RES','IRES',
        'EVID','MDV','CMT','SS','II','ADDL','AMT','RATE','OCC']);
    const otherCovs = viewerData.columns.filter(c =>
        !standardCols.has(c.toUpperCase()) && !/^ETA/i.test(c) && !/^ET\d/i.test(c)
        && !/^(OMEGA|SIGMA|OBJ)/i.test(c)
    );

    etaCols.forEach(c => { etaSel.innerHTML += `<option value="${c}">${c}</option>`; });
    [...covCols, ...otherCovs.filter(c => !covCols.includes(c))].forEach(c => {
        covSel.innerHTML += `<option value="${c}">${c}</option>`;
    });
}

function drawEtaCovPlot() {
    const eta = document.getElementById('sel-eta-col').value;
    const cov = document.getElementById('sel-cov-col').value;
    if (!eta || !cov) return;
    document.getElementById('sel-plot-x').value = cov;
    document.getElementById('sel-plot-y').value = eta;
    document.getElementById('chk-yzero').checked = true;
    document.getElementById('chk-loess').checked = true;
    document.getElementById('chk-unity').checked = false;
    drawPlot();
}

function drawQQPlot(colName) {
    if (!viewerData || !viewerData.filteredData.length) return;
    const colIdx = viewerData.columns.indexOf(colName);
    const vals = viewerData.filteredData
        .map(r => Number(r[colIdx]))
        .filter(v => isFinite(v))
        .sort((a, b) => a - b);

    const n = vals.length;
    if (n < 3) return;

    // Theoretical quantiles (standard normal)
    const theoretical = vals.map((_, i) => {
        const p = (i + 0.5) / n;
        return qnorm(p);
    });

    const traces = [{
        x: theoretical, y: vals,
        mode: 'markers', type: 'scatter',
        marker: { color: '#5b9cf5', size: 6, opacity: 0.5 },
        name: colName,
    }];

    // Reference line through Q1 and Q3
    const q1i = Math.floor(n * 0.25), q3i = Math.floor(n * 0.75);
    const q1t = qnorm(0.25), q3t = qnorm(0.75);
    const slope = (vals[q3i] - vals[q1i]) / (q3t - q1t);
    const intercept = vals[q1i] - slope * q1t;
    const tMin = theoretical[0], tMax = theoretical[n - 1];
    traces.push({
        x: [tMin, tMax], y: [intercept + slope * tMin, intercept + slope * tMax],
        mode: 'lines', type: 'scatter',
        line: { color: '#f87171', width: 1.5, dash: 'dash' },
        name: 'Reference', showlegend: true,
    });

    Plotly.newPlot('plot-container', traces, {
        xaxis: { title: 'Theoretical Quantiles', color: '#b0b5c8', gridcolor: '#2e3348' },
        yaxis: { title: colName, color: '#b0b5c8', gridcolor: '#2e3348' },
        paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: '#171922',
        font: { family: 'SF Mono, Menlo, monospace', size: 11, color: '#b0b5c8' },
        margin: { t: 10, r: 20, b: 50, l: 60 },
        showlegend: true,
        legend: { x: 0.01, y: 0.99, bgcolor: 'rgba(23,25,34,0.8)', font: { size: 10, color: '#b0b5c8' } },
    }, { responsive: true });
}

// ── Standard normal quantile function (Beasley-Springer-Moro approx) ──
function qnorm(p) {
    if (p <= 0) return -Infinity;
    if (p >= 1) return Infinity;
    if (p === 0.5) return 0;
    const a = [-3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2,
               1.383577518672690e2, -3.066479806614716e1, 2.506628277459239e0];
    const b = [-5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2,
               6.680131188771972e1, -1.328068155288572e1];
    const c = [-7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838e0,
               -2.549732539343734e0, 4.374664141464968e0, 2.938163982698783e0];
    const d = [7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996e0, 3.754408661907416e0];
    const pLow = 0.02425, pHigh = 1 - pLow;
    let q, r;
    if (p < pLow) {
        q = Math.sqrt(-2 * Math.log(p));
        return (((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) /
               ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1);
    } else if (p <= pHigh) {
        q = p - 0.5; r = q * q;
        return (((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5]) * q /
               (((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1);
    } else {
        q = Math.sqrt(-2 * Math.log(1 - p));
        return -(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) /
                ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1);
    }
}

// ── Model Evaluation Tab ───────────────
async function loadEvalData() {
    const path = document.getElementById('inp-eval-file').value.trim();
    if (!path) { alert('Select an output table file first.'); return; }

    const data = await postJson('/api/data/read', { path });
    if (data.error) { alert(data.error); return; }

    evalData = { columns: data.columns, data: data.data };

    // Populate GOF time column selector
    const gofTime = document.getElementById('sel-gof-time');
    gofTime.innerHTML = '';
    const timeCols = data.columns.filter(c => /^(TIME|TAD|TAFD|TALD)$/i.test(c));
    data.columns.forEach(c => {
        if (/time/i.test(c) && !timeCols.includes(c)) timeCols.push(c);
    });
    if (timeCols.length === 0) timeCols.push('TIME');
    timeCols.forEach(c => {
        const label = c.toUpperCase() === 'TAD' ? `${c} (Time after dose)` :
                      c.toUpperCase() === 'TAFD' ? `${c} (Time after first dose)` : c;
        gofTime.innerHTML += `<option value="${c}">${label}</option>`;
    });

    document.getElementById('gof-figure-card').querySelector('.card-title').textContent =
        `Goodness of Fit — ${data.name} (${data.n_rows} rows)`;
}

// Allow opening a file directly in the evaluation tab from other tabs
function openInEvaluation(path) {
    document.getElementById('inp-eval-file').value = path;
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelector('[data-tab="evaluation"]').classList.add('active');
    document.getElementById('tab-evaluation').classList.add('active');
    loadEvalData();
}

// ── Publication GOF Figure (2×2) ───────
function drawGofFigure() {
    if (!evalData || !evalData.data.length) {
        alert('Load an output table file in the Model Evaluation tab first.');
        return;
    }

    const cols = evalData.columns;
    const find = (names) => {
        for (const n of names) {
            const idx = cols.findIndex(c => c.toUpperCase() === n.toUpperCase());
            if (idx >= 0) return cols[idx];
        }
        return null;
    };

    const dvCol = find(['DV']);
    const predCol = find(['PRED']);
    const ipredCol = find(['IPRED']);
    const cwresCol = find(['CWRES', 'WRES']);
    const timeCol = document.getElementById('sel-gof-time').value || find(['TIME', 'TAD']) || 'TIME';
    const concUnit = document.getElementById('inp-gof-conc-unit').value || 'mg/L';
    const timeUnit = document.getElementById('inp-gof-time-unit').value || 'h';

    if (!dvCol || !predCol || !ipredCol || !cwresCol) {
        alert('Required columns not found. Need: DV, PRED, IPRED, and CWRES (or WRES).\nAvailable: ' + cols.join(', '));
        return;
    }

    if (!cols.includes(timeCol)) {
        alert(`Time column "${timeCol}" not found in data.`);
        return;
    }

    const data = evalData.data;
    const mdvIdx = cols.findIndex(c => c.toUpperCase() === 'MDV');
    const excludeMDV = document.getElementById('chk-gof-mdv').checked;
    const filteredData = (excludeMDV && mdvIdx >= 0)
        ? data.filter(r => r[mdvIdx] === 0 || r[mdvIdx] === '0')
        : data;
    const getCol = (name) => filteredData.map(r => r[cols.indexOf(name)]);

    const dv = getCol(dvCol);
    const pred = getCol(predCol);
    const ipred = getCol(ipredCol);
    const cwres = getCol(cwresCol);
    const time = getCol(timeCol);

    // Common marker style
    const mkr = { color: 'rgba(55,90,127,0.35)', size: 5 };
    const mkrDark = { color: 'rgba(55,90,127,0.45)', size: 5 };

    // Compute LOESS for each panel
    const loessPredDV = computeLoess(pred, dv);
    const loessIpredDV = computeLoess(ipred, dv);
    const loessPredCW = computeLoess(pred, cwres);
    const loessTimeCW = computeLoess(time, cwres);

    // Unity/reference line ranges
    const allConc = [...dv, ...pred, ...ipred].filter(v => isFinite(Number(v))).map(Number);
    const concMin = Math.min(...allConc);
    const concMax = Math.max(...allConc);

    const loessStyle = { color: 'rgba(220,50,50,0.8)', width: 2 };

    // Build subplot traces — all assigned to specific axes
    const traces = [
        // Panel 1: DV vs PRED (row1, col1)
        { x: pred, y: dv, mode: 'markers', type: 'scattergl', marker: mkr, showlegend: false, xaxis: 'x', yaxis: 'y' },
        { x: [concMin, concMax], y: [concMin, concMax], mode: 'lines', line: { color: '#333', width: 1, dash: 'dash' }, showlegend: false, xaxis: 'x', yaxis: 'y' },

        // Panel 2: DV vs IPRED (row1, col2)
        { x: ipred, y: dv, mode: 'markers', type: 'scattergl', marker: mkr, showlegend: false, xaxis: 'x2', yaxis: 'y2' },
        { x: [concMin, concMax], y: [concMin, concMax], mode: 'lines', line: { color: '#333', width: 1, dash: 'dash' }, showlegend: false, xaxis: 'x2', yaxis: 'y2' },

        // Panel 3: CWRES vs PRED (row2, col1)
        { x: pred, y: cwres, mode: 'markers', type: 'scattergl', marker: mkrDark, showlegend: false, xaxis: 'x3', yaxis: 'y3' },

        // Panel 4: CWRES vs TIME (row2, col2)
        { x: time, y: cwres, mode: 'markers', type: 'scattergl', marker: mkrDark, showlegend: false, xaxis: 'x4', yaxis: 'y4' },
    ];

    // Add LOESS traces
    if (loessPredDV) traces.push({ x: loessPredDV.x, y: loessPredDV.y, mode: 'lines', line: loessStyle, showlegend: false, xaxis: 'x', yaxis: 'y' });
    if (loessIpredDV) traces.push({ x: loessIpredDV.x, y: loessIpredDV.y, mode: 'lines', line: loessStyle, showlegend: false, xaxis: 'x2', yaxis: 'y2' });
    if (loessPredCW) traces.push({ x: loessPredCW.x, y: loessPredCW.y, mode: 'lines', line: loessStyle, showlegend: false, xaxis: 'x3', yaxis: 'y3' });
    if (loessTimeCW) traces.push({ x: loessTimeCW.x, y: loessTimeCW.y, mode: 'lines', line: loessStyle, showlegend: false, xaxis: 'x4', yaxis: 'y4' });

    const timeLabel = timeCol.toUpperCase() === 'TAD' ? `Time after dose (${timeUnit})` : `Time (${timeUnit})`;

    // Y=0 horizontal lines for CWRES panels (as shapes)
    const shapes = [
        { type: 'line', xref: 'x3', x0: concMin, x1: concMax, yref: 'y3', y0: 0, y1: 0, line: { color: '#333', width: 1, dash: 'dash' } },
        { type: 'line', xref: 'x4', x0: Math.min(...time.filter(v => isFinite(Number(v))).map(Number)),
          x1: Math.max(...time.filter(v => isFinite(Number(v))).map(Number)),
          yref: 'y4', y0: 0, y1: 0, line: { color: '#333', width: 1, dash: 'dash' } },
    ];

    const axisCommon = {
        gridcolor: '#ddd', gridwidth: 1,
        zerolinecolor: '#bbb', zerolinewidth: 1,
        linecolor: '#333', linewidth: 1,
        tickfont: { size: 11, color: '#333' },
        titlefont: { size: 13, color: '#222' },
        mirror: true, ticks: 'outside',
    };

    const layout = {
        height: 720,
        paper_bgcolor: '#fff',
        plot_bgcolor: '#fff',
        font: { family: 'Arial, Helvetica, sans-serif', size: 12, color: '#222' },
        margin: { t: 50, r: 30, b: 60, l: 70 },
        shapes: shapes,

        // Grid layout: 2 rows × 2 cols with room for labels
        xaxis:  { ...axisCommon, domain: [0, 0.47], anchor: 'y',  title: `Population predicted (${concUnit})` },
        yaxis:  { ...axisCommon, domain: [0.56, 0.98], anchor: 'x',  title: `Observed (${concUnit})` },
        xaxis2: { ...axisCommon, domain: [0.53, 1], anchor: 'y2', title: `Individual predicted (${concUnit})` },
        yaxis2: { ...axisCommon, domain: [0.56, 0.98], anchor: 'x2', title: `Observed (${concUnit})` },
        xaxis3: { ...axisCommon, domain: [0, 0.47], anchor: 'y3', title: `Population predicted (${concUnit})` },
        yaxis3: { ...axisCommon, domain: [0, 0.42], anchor: 'x3', title: 'CWRES' },
        xaxis4: { ...axisCommon, domain: [0.53, 1], anchor: 'y4', title: timeLabel },
        yaxis4: { ...axisCommon, domain: [0, 0.42], anchor: 'x4', title: 'CWRES' },

        // Panel labels — positioned above each subplot row
        annotations: [
            { text: '<b>A</b>', x: 0, y: 1.0, xref: 'paper', yref: 'paper', xanchor: 'left', yanchor: 'bottom', showarrow: false, font: { size: 16 } },
            { text: '<b>B</b>', x: 0.53, y: 1.0, xref: 'paper', yref: 'paper', xanchor: 'left', yanchor: 'bottom', showarrow: false, font: { size: 16 } },
            { text: '<b>C</b>', x: 0, y: 0.48, xref: 'paper', yref: 'paper', xanchor: 'left', yanchor: 'bottom', showarrow: false, font: { size: 16 } },
            { text: '<b>D</b>', x: 0.53, y: 0.48, xref: 'paper', yref: 'paper', xanchor: 'left', yanchor: 'bottom', showarrow: false, font: { size: 16 } },
        ],
    };

    Plotly.newPlot('gof-figure-container', traces, layout, {
        responsive: true,
        displayModeBar: true,
        toImageButtonOptions: { format: 'png', width: 800, height: 720, scale: 3, filename: 'GOF_figure' },
    });

    // Scroll to it
    document.getElementById('gof-figure-container').scrollIntoView({ behavior: 'smooth' });
}

function exportGofFigure() {
    const container = document.getElementById('gof-figure-container');
    if (!container || !container.data) {
        alert('Generate the GOF figure first.');
        return;
    }
    Plotly.downloadImage(container, {
        format: 'png', width: 800, height: 720, scale: 3, filename: 'GOF_figure'
    });
}

// ── Individual Fit Plots ───────────────
let indFitPage = 0;
let indFitIds = [];
let _indFitCols = null; // cached column refs for pagination

function drawIndividualFits() {
    if (!evalData || !evalData.data.length) { alert('Load an output table first.'); return; }
    const cols = evalData.columns;
    var find = function(names) {
        for (var n of names) {
            var idx = cols.findIndex(function(c) { return c.toUpperCase() === n.toUpperCase(); });
            if (idx >= 0) return cols[idx];
        }
        return null;
    };
    var idCol = find(['ID']);
    var timeCol = find(['TIME', 'TAD']);
    var dvCol = find(['DV']);
    var predCol = find(['PRED']);
    var ipredCol = find(['IPRED']);
    if (!idCol || !timeCol || !dvCol) { alert('Need ID, TIME, DV columns.'); return; }

    var idIdx = cols.indexOf(idCol);
    indFitIds = [...new Set(evalData.data.map(function(r) { return r[idIdx]; }))].sort(function(a,b) { return a - b; });
    indFitPage = 0;
    _indFitCols = { cols, idCol, timeCol, dvCol, predCol, ipredCol };
    renderIndFitPage(cols, idCol, timeCol, dvCol, predCol, ipredCol);
}

function renderIndFitPage(cols, idCol, timeCol, dvCol, predCol, ipredCol) {
    var grid = parseInt(document.getElementById('sel-indfit-grid').value) || 3;
    var perPage = grid * grid;
    var totalPages = Math.ceil(indFitIds.length / perPage);
    document.getElementById('indfit-page-info').textContent = (indFitPage + 1) + '/' + totalPages;

    var pageIds = indFitIds.slice(indFitPage * perPage, (indFitPage + 1) * perPage);
    var idIdx = cols.indexOf(idCol);
    var timeIdx = cols.indexOf(timeCol);
    var dvIdx = cols.indexOf(dvCol);
    var predIdx = predCol ? cols.indexOf(predCol) : -1;
    var ipredIdx = ipredCol ? cols.indexOf(ipredCol) : -1;
    var mdvIdx = cols.findIndex(function(c) { return c.toUpperCase() === 'MDV'; });

    var traces = [];
    var nPlots = pageIds.length;
    var annotations = [];

    for (var p = 0; p < nPlots; p++) {
        var pid = pageIds[p];
        var subData = evalData.data.filter(function(r) { return r[idIdx] === pid; });
        var xAx = p === 0 ? 'x' : 'x' + (p + 1);
        var yAx = p === 0 ? 'y' : 'y' + (p + 1);

        // DV points — exclude MDV=1 (dose records)
        var dvData = mdvIdx >= 0 ? subData.filter(function(r) { return r[mdvIdx] === 0 || r[mdvIdx] === '0'; }) : subData;
        traces.push({
            x: dvData.map(function(r) { return r[timeIdx]; }),
            y: dvData.map(function(r) { return r[dvIdx]; }),
            mode: 'markers', type: 'scatter',
            marker: { color: '#2563eb', size: 5 },
            xaxis: xAx, yaxis: yAx, showlegend: false, name: 'DV'
        });
        // IPRED line
        if (ipredIdx >= 0) {
            var sorted = subData.slice().sort(function(a,b) { return a[timeIdx] - b[timeIdx]; });
            traces.push({
                x: sorted.map(function(r) { return r[timeIdx]; }),
                y: sorted.map(function(r) { return r[ipredIdx]; }),
                mode: 'lines', type: 'scatter',
                line: { color: '#dc2626', width: 1.5 },
                xaxis: xAx, yaxis: yAx, showlegend: false, name: 'IPRED'
            });
        }
        // PRED line
        if (predIdx >= 0) {
            var sorted2 = subData.slice().sort(function(a,b) { return a[timeIdx] - b[timeIdx]; });
            traces.push({
                x: sorted2.map(function(r) { return r[timeIdx]; }),
                y: sorted2.map(function(r) { return r[predIdx]; }),
                mode: 'lines', type: 'scatter',
                line: { color: '#333', width: 1, dash: 'dash' },
                xaxis: xAx, yaxis: yAx, showlegend: false, name: 'PRED'
            });
        }
        // ID label annotation
        var row = Math.floor(p / grid);
        var col = p % grid;
        var xFrac = col / grid + 0.01;
        var yFrac = 1 - row / grid - 0.01;
        annotations.push({
            text: 'ID ' + pid, x: xFrac, y: yFrac, xref: 'paper', yref: 'paper',
            showarrow: false, font: { size: 10, color: '#aab' }
        });
    }

    // Build layout with subplot grid
    var layout = {
        height: 650,
        paper_bgcolor: '#171922', plot_bgcolor: '#fff',
        font: { family: 'Arial, sans-serif', size: 10, color: '#aab' },
        margin: { t: 20, r: 20, b: 40, l: 50 },
        annotations: annotations,
        showlegend: false,
        grid: { rows: grid, columns: grid, pattern: 'independent', xgap: 0.06, ygap: 0.08 },
    };

    for (var i = 0; i < nPlots; i++) {
        var axNum = i === 0 ? '' : (i + 1).toString();
        layout['xaxis' + axNum] = { gridcolor: '#eee', linecolor: '#ccc', ticks: 'inside', tickfont: { size: 9, color: '#555' }, zeroline: false };
        layout['yaxis' + axNum] = { gridcolor: '#eee', linecolor: '#ccc', ticks: 'inside', tickfont: { size: 9, color: '#555' }, zeroline: false };
    }

    Plotly.newPlot('indfit-container', traces, layout, { responsive: true });
}

function indFitPrev() {
    if (indFitPage > 0 && _indFitCols) {
        indFitPage--;
        var c = _indFitCols;
        renderIndFitPage(c.cols, c.idCol, c.timeCol, c.dvCol, c.predCol, c.ipredCol);
    }
}
function indFitNext() {
    var grid = parseInt(document.getElementById('sel-indfit-grid').value) || 3;
    var perPage = grid * grid;
    if ((indFitPage + 1) * perPage < indFitIds.length && _indFitCols) {
        indFitPage++;
        var c = _indFitCols;
        renderIndFitPage(c.cols, c.idCol, c.timeCol, c.dvCol, c.predCol, c.ipredCol);
    }
}

// ── Residual Distribution ──────────────
function drawResidualDist() {
    if (!evalData || !evalData.data.length) { alert('Load data first.'); return; }
    var cols = evalData.columns;
    var find = function(names) {
        for (var n of names) {
            var idx = cols.findIndex(function(c) { return c.toUpperCase() === n.toUpperCase(); });
            if (idx >= 0) return cols[idx];
        }
        return null;
    };
    var cwresCol = find(['CWRES', 'WRES']);
    var iwresCol = find(['IWRES']);
    if (!cwresCol) { alert('CWRES or WRES column not found.'); return; }

    var cwresIdx = cols.indexOf(cwresCol);
    var mdvIdx = cols.findIndex(function(c) { return c.toUpperCase() === 'MDV'; });
    var filtData = mdvIdx >= 0 ? evalData.data.filter(function(r) { return r[mdvIdx] === 0 || r[mdvIdx] === '0'; }) : evalData.data;
    var cwresVals = filtData.map(function(r) { return r[cwresIdx]; }).filter(function(v) { return isFinite(Number(v)); }).map(Number);

    var traces = [{
        x: cwresVals, type: 'histogram', name: cwresCol,
        marker: { color: 'rgba(37,99,235,0.5)', line: { color: 'rgba(37,99,235,0.8)', width: 1 } },
        xbins: { size: 0.3 },
        xaxis: 'x', yaxis: 'y',
    }];

    // Normal density overlay
    var mean = cwresVals.reduce(function(a,b) { return a+b; }, 0) / cwresVals.length;
    var sd = Math.sqrt(cwresVals.reduce(function(a,b) { return a + (b-mean)*(b-mean); }, 0) / cwresVals.length);
    var xNorm = [];
    var yNorm = [];
    var binWidth = 0.3;
    for (var x = -4; x <= 4; x += 0.05) {
        xNorm.push(x);
        yNorm.push(cwresVals.length * binWidth * Math.exp(-0.5 * Math.pow((x - mean) / sd, 2)) / (sd * Math.sqrt(2 * Math.PI)));
    }
    traces.push({
        x: xNorm, y: yNorm, mode: 'lines', type: 'scatter',
        line: { color: '#dc2626', width: 2 }, name: 'Normal', xaxis: 'x', yaxis: 'y'
    });

    // If IWRES available, add second panel
    if (iwresCol) {
        var iwresIdx = cols.indexOf(iwresCol);
        var iwresVals = filtData.map(function(r) { return r[iwresIdx]; }).filter(function(v) { return isFinite(Number(v)); }).map(Number);
        traces.push({
            x: iwresVals, type: 'histogram', name: 'IWRES',
            marker: { color: 'rgba(220,38,38,0.4)', line: { color: 'rgba(220,38,38,0.7)', width: 1 } },
            xbins: { size: 0.3 }, xaxis: 'x2', yaxis: 'y2'
        });
    }

    var layout = {
        height: 350,
        paper_bgcolor: '#171922', plot_bgcolor: '#fff',
        font: { family: 'Arial, sans-serif', size: 11, color: '#aab' },
        margin: { t: 20, r: 20, b: 50, l: 60 },
        xaxis: { title: cwresCol, domain: iwresCol ? [0, 0.47] : [0, 1], gridcolor: '#eee' },
        yaxis: { title: 'Count', gridcolor: '#eee' },
        showlegend: true,
        legend: { x: 0.01, y: 0.99, font: { size: 10 } },
        barmode: 'overlay',
    };
    if (iwresCol) {
        layout.xaxis2 = { title: 'IWRES', domain: [0.53, 1], gridcolor: '#eee', anchor: 'y2' };
        layout.yaxis2 = { title: 'Count', gridcolor: '#eee', anchor: 'x2' };
    }

    Plotly.newPlot('resdist-container', traces, layout, { responsive: true });
}

// ── Convergence Plot ───────────────────
async function drawConvergence() {
    if (selectedModelIdx < 0) { alert('Select a model first.'); return; }
    var m = scannedModels[selectedModelIdx];
    var result = await postJson('/api/ext/read', { path: m.path });
    if (result.error) { alert(result.error); return; }

    var data = result.data;
    var cols = result.columns;
    if (!data || !data.length) { alert('No convergence data found.'); return; }

    // OFV column is usually OBJ or SAEMOBJ
    var objCol = cols.find(function(c) { return c.toUpperCase() === 'OBJ' || c.toUpperCase().indexOf('OBJ') >= 0; });
    var iterCol = cols.find(function(c) { return c.toUpperCase() === 'ITERATION'; });

    if (!iterCol || !objCol) { alert('Cannot find ITERATION and OBJ columns in .ext file.'); return; }

    var iterations = data.map(function(r) { return r[iterCol]; });
    var ofvValues = data.map(function(r) { return r[objCol]; });

    // Find THETA columns
    var thetaCols = cols.filter(function(c) { return /^THETA\d+$/i.test(c); });

    // OFV trace
    var traces = [{
        x: iterations, y: ofvValues, mode: 'lines+markers', type: 'scatter',
        marker: { size: 3, color: '#2563eb' }, line: { color: '#2563eb', width: 2 },
        name: 'OFV', xaxis: 'x', yaxis: 'y'
    }];

    // Parameter traces on second y-axis
    var colors = ['#dc2626', '#16a34a', '#d97706', '#7c3aed', '#0891b2', '#be185d', '#4338ca', '#065f46'];
    thetaCols.forEach(function(tc, i) {
        traces.push({
            x: iterations,
            y: data.map(function(r) { return r[tc]; }),
            mode: 'lines', type: 'scatter',
            line: { color: colors[i % colors.length], width: 1.5 },
            name: tc, xaxis: 'x2', yaxis: 'y2'
        });
    });

    var layout = {
        height: 350,
        paper_bgcolor: '#171922', plot_bgcolor: '#fff',
        font: { family: 'Arial, sans-serif', size: 11, color: '#aab' },
        margin: { t: 20, r: 60, b: 50, l: 70 },
        showlegend: true,
        legend: { x: 1.05, y: 1, font: { size: 9 } },
        grid: { rows: 1, columns: 2, pattern: 'independent', xgap: 0.08 },
        xaxis: { title: 'Iteration', domain: [0, 0.47], gridcolor: '#eee' },
        yaxis: { title: 'OFV', gridcolor: '#eee' },
        xaxis2: { title: 'Iteration', domain: [0.55, 1], gridcolor: '#eee' },
        yaxis2: { title: 'Parameter Value', gridcolor: '#eee' },
    };

    Plotly.newPlot('convergence-container', traces, layout, { responsive: true });
}

// ── Individual OFV Waterfall ──────────
async function drawOfvWaterfall() {
    if (selectedModelIdx < 0) { alert('Select a model first.'); return; }
    var m = scannedModels[selectedModelIdx];
    var result = await postJson('/api/phi/read', { path: m.path });
    if (result.error) {
        document.getElementById('ofv-waterfall-container').innerHTML =
            '<div style="padding:16px;color:var(--red);font-size:12px">' + escapeHtml(result.error) + '</div>';
        return;
    }

    var ids = result.ids;
    var obj = result.obj;
    if (!ids.length || !obj.length) { alert('No individual OBJ data found.'); return; }

    // Create paired array and sort by OBJ descending (largest contributors first)
    var paired = ids.map(function(id, i) { return { id: id, obj: obj[i] }; });
    paired.sort(function(a, b) { return b.obj - a.obj; });

    var sortedIds = paired.map(function(p) { return 'ID ' + (Number.isInteger(p.id) ? p.id : Math.round(p.id)); });
    var sortedObj = paired.map(function(p) { return p.obj; });

    // Color: gradient from red (high OBJ) to blue (low OBJ)
    var maxObj = Math.max.apply(null, sortedObj);
    var minObj = Math.min.apply(null, sortedObj);
    var range = maxObj - minObj || 1;
    var colors = sortedObj.map(function(v) {
        var t = (v - minObj) / range;
        var r = Math.round(220 * t + 37 * (1 - t));
        var g = Math.round(80 * (1 - t) + 99 * t);
        var b = Math.round(235 * (1 - t) + 71 * t);
        return 'rgb(' + r + ',' + g + ',' + b + ')';
    });

    var traces = [{
        x: sortedIds,
        y: sortedObj,
        type: 'bar',
        marker: { color: colors },
        hovertemplate: '%{x}<br>iOFV: %{y:.2f}<extra></extra>'
    }];

    var layout = {
        height: 350,
        paper_bgcolor: '#171922',
        plot_bgcolor: '#fff',
        font: { family: 'Arial, sans-serif', size: 11, color: '#aab' },
        margin: { t: 20, r: 20, b: 80, l: 70 },
        xaxis: {
            title: 'Subject',
            tickangle: -45,
            tickfont: { size: ids.length > 50 ? 7 : 9, color: '#aab' },
            gridcolor: '#eee',
            titlefont: { color: '#aab' },
        },
        yaxis: {
            title: 'Individual OFV contribution (-2LL)',
            gridcolor: '#eee',
            tickfont: { color: '#aab' },
            titlefont: { color: '#aab' },
        },
        bargap: 0.15,
    };

    Plotly.newPlot('ofv-waterfall-container', traces, layout, { responsive: true });
}

// ── Model Duplication ──────────────────
async function duplicateModel() {
    if (selectedModelIdx < 0) { alert('Select a model first.'); return; }
    const m = scannedModels[selectedModelIdx];
    const stem = m.stem;

    // Suggest next run number
    const existingNums = scannedModels.map(m2 => {
        const match = m2.stem.match(/(\d+)/);
        return match ? parseInt(match[1]) : 0;
    });
    const nextNum = Math.max(...existingNums) + 1;
    const suggestedName = stem.replace(/\d+/, '') + String(nextNum).padStart(2, '0') + m.ext;

    // Show duplicate modal
    document.getElementById('inp-dup-name').value = suggestedName;
    const chkEst = document.getElementById('chk-dup-estimates');
    chkEst.checked = false;
    chkEst.disabled = !m.has_run;
    document.getElementById('dup-jitter-group').style.display = 'none';
    document.getElementById('inp-dup-jitter').value = '20';
    document.getElementById('chk-dup-jitter').checked = false;
    document.getElementById('modal-duplicate').style.display = 'flex';
}

function onDupEstimatesChange() {
    var show = document.getElementById('chk-dup-estimates').checked;
    document.getElementById('dup-jitter-group').style.display = show ? 'block' : 'none';
}

async function confirmDuplicate() {
    if (selectedModelIdx < 0) return;
    const m = scannedModels[selectedModelIdx];
    const newName = document.getElementById('inp-dup-name').value.trim();
    if (!newName) return;
    const useEstimates = document.getElementById('chk-dup-estimates').checked;
    const doJitter = useEstimates && document.getElementById('chk-dup-jitter').checked;
    const jitterPct = doJitter ? parseInt(document.getElementById('inp-dup-jitter').value) || 0 : 0;

    document.getElementById('modal-duplicate').style.display = 'none';

    const result = await postJson('/api/model/duplicate', {
        source: m.path,
        new_name: newName,
        use_estimates: useEstimates,
        jitter: jitterPct / 100
    });

    if (result.error) { alert(result.error); return; }

    // Refresh and select the new model
    await scanModels();
    const newIdx = scannedModels.findIndex(m2 => m2.name === newName);
    if (newIdx >= 0) selectModel(newIdx);
}

// ── NMTRAN Error Display ───────────────
async function checkErrors(modelPath) {
    if (!modelPath) return;
    const result = await postJson('/api/model/errors', { path: modelPath });
    const btn = document.getElementById('btn-errors');
    if (result.errors && result.errors.length > 0) {
        btn.style.display = 'inline-flex';
        btn.dataset.errors = JSON.stringify(result.errors);
        btn.textContent = `⚠ ${result.errors.filter(e => e.type === 'error').length} errors`;
    } else {
        btn.style.display = 'none';
    }
}

function showErrors() {
    const btn = document.getElementById('btn-errors');
    const errors = JSON.parse(btn.dataset.errors || '[]');
    if (!errors.length) return;

    let html = '<div style="max-height:200px;overflow:auto;font-family:var(--mono);font-size:11px;padding:8px;background:var(--bg-0);border:1px solid var(--border);border-radius:var(--radius);margin-top:6px">';
    errors.forEach(e => {
        const color = e.type === 'error' ? 'var(--red)' : 'var(--yellow)';
        html += `<div style="color:${color};padding:2px 0">${escapeHtml(e.message)}</div>`;
    });
    html += '</div>';

    // Show below the editor toolbar
    let container = document.getElementById('error-panel');
    if (!container) {
        container = document.createElement('div');
        container.id = 'error-panel';
        document.getElementById('codemirror-host').parentElement.insertBefore(
            container, document.getElementById('codemirror-host')
        );
    }
    if (container.innerHTML) {
        container.innerHTML = '';  // Toggle off
    } else {
        container.innerHTML = html;
    }
}

// ══════════════════════════════════════════
// ══ BOOKMARKS ════════════════════════════
// ══════════════════════════════════════════

async function loadBookmarks() {
    const bookmarks = await fetchJson('/api/bookmarks');
    renderBookmarks(bookmarks);
}

function renderBookmarks(bookmarks) {
    const list = document.getElementById('bookmarks-list');
    if (!bookmarks || !bookmarks.length) {
        list.innerHTML = '<div class="bookmarks-empty">No projects bookmarked yet. Open a project folder and click "+ Add Current" to bookmark it.</div>';
        return;
    }
    list.innerHTML = '';
    bookmarks.forEach(b => {
        const el = document.createElement('div');
        el.className = 'bookmark-item';
        el.onclick = (e) => {
            if (e.target.closest('.bookmark-remove')) return;
            openBookmark(b.path);
        };
        el.innerHTML = `
            <span class="bookmark-icon">📁</span>
            <div class="bookmark-info">
                <div class="bookmark-name">${b.description || b.name}</div>
                <div class="bookmark-path">${b.path}</div>
            </div>
            <button class="bookmark-remove" onclick="event.stopPropagation(); editBookmark('${b.path.replace(/'/g, "\\'")}')" title="Edit">✎</button>
            <button class="bookmark-remove" onclick="event.stopPropagation(); removeBookmark('${b.path.replace(/'/g, "\\'")}')" title="Remove">✕</button>
        `;
        list.appendChild(el);
    });
}

function openBookmark(path) {
    document.getElementById('inp-project-dir').value = path;
    document.getElementById('inp-scan-dir').value = path;
    document.getElementById('inp-data-dir').value = path;
    scanModels();
}

async function addBookmark() {
    const path = document.getElementById('inp-project-dir').value.trim();
    if (!path) { alert('Open a project folder first.'); return; }
    const description = prompt('Project description:', pathBasename(path));
    if (description === null) return;
    const bookmarks = await postJson('/api/bookmarks/add', { path, description });
    renderBookmarks(bookmarks);
}

async function removeBookmark(path) {
    if (!confirm('Remove this bookmark?')) return;
    const bookmarks = await postJson('/api/bookmarks/remove', { path });
    renderBookmarks(bookmarks);
}

async function editBookmark(path) {
    const newDesc = prompt('Edit project description:');
    if (newDesc === null) return;
    const bookmarks = await postJson('/api/bookmarks/update', { path, description: newDesc });
    renderBookmarks(bookmarks);
}

function toggleBookmarks() {
    const panel = document.getElementById('bookmarks-panel');
    if (panel.style.display === 'none') {
        panel.style.display = 'block';
        loadBookmarks();
    } else {
        panel.style.display = 'none';
    }
}

// ══════════════════════════════════════════
// ══ RSTUDIO LAUNCHER ═════════════════════
// ══════════════════════════════════════════

async function launchRStudio() {
    const dir = document.getElementById('inp-project-dir').value;
    if (!dir) { alert('Set a project directory first.'); return; }
    const result = await postJson('/api/launch/rstudio', { directory: dir });
    if (result.error) {
        alert('Could not launch RStudio: ' + result.error);
    }
}

// ══════════════════════════════════════════
// ══ VPC TAB ══════════════════════════════
// ══════════════════════════════════════════

var _vpcRStatus = null; // cached R check result

function toggleVpcOptions() {
    var tool = document.getElementById('sel-vpc-tool').value;
    document.getElementById('vpc-options-vpc').style.display = tool === 'vpc' ? 'block' : 'none';
    document.getElementById('vpc-options-xpose').style.display = tool === 'xpose' ? 'block' : 'none';
    document.getElementById('vpc-options-xpose4').style.display = tool === 'xpose4' ? 'block' : 'none';
    // Clear custom script textarea when switching tools (bug #10 fix)
    document.getElementById('vpc-r-script').value = '';
    // Auto-populate runno and run_dir from selected model
    _autoPopulateRunno();
    _autoPopulateRunDir();
}

function _autoPopulateRunno() {
    if (selectedModelIdx < 0) return;
    var m = scannedModels[selectedModelIdx];
    var elX = document.getElementById('inp-xpose-runno');
    // Prefer table_runno extracted from $TABLE FILE=sdtab{runno} in control stream
    var runno = m.table_runno || '';
    if (!runno) {
        // Fallback: extract from model stem
        var nums = m.stem.match(/(\d+)/);
        if (nums) runno = nums[1];
    }
    if (runno && elX && !elX.value) elX.value = runno;
}

function _autoPopulateRunDir() {
    if (selectedModelIdx < 0) return;
    var m = scannedModels[selectedModelIdx];
    var dir = m.run_dir || document.getElementById('inp-project-dir').value || '';
    var elXpose = document.getElementById('inp-xpose-rundir');
    if (elXpose && !elXpose.value && dir) elXpose.value = dir;
}

async function checkRStatus() {
    var dot = document.getElementById('vpc-r-dot');
    var msg = document.getElementById('vpc-r-msg');
    dot.style.background = 'var(--text-2)';
    msg.textContent = 'Checking R and vpc packages...';
    try {
        var result = await postJson('/api/r/check', {}, 'GET');
        _vpcRStatus = result;
        if (!result.r_available) {
            dot.style.background = 'var(--red)';
            msg.innerHTML = 'R not found. Install R and ensure <code>Rscript</code> is on PATH.';
            _disableUnavailableTools(result);
            return;
        }
        var parts = [result.r_version];
        if (result.vpc_available) parts.push('vpc \u2713');
        else parts.push('<span style="color:var(--red)">vpc \u2717</span> — <code>install.packages("vpc")</code>');
        if (result.xpose_available) parts.push('xpose \u2713');
        else parts.push('<span style="color:var(--text-2)">xpose \u2717</span>');
        if (result.xpose4_available) parts.push('xpose4 \u2713');
        else parts.push('<span style="color:var(--text-2)">xpose4 \u2717</span>');
        dot.style.background = result.vpc_available ? 'var(--green)' : 'var(--yellow)';
        msg.innerHTML = parts.join(' &nbsp;|&nbsp; ');
        _disableUnavailableTools(result);
    } catch (e) {
        dot.style.background = 'var(--red)';
        msg.textContent = 'Could not check R status.';
    }
}

function _disableUnavailableTools(status) {
    var sel = document.getElementById('sel-vpc-tool');
    for (var i = 0; i < sel.options.length; i++) {
        var opt = sel.options[i];
        var available = true;
        if (!status.r_available) available = false;
        else if (opt.value === 'vpc' && !status.vpc_available) available = false;
        else if (opt.value === 'xpose' && !status.xpose_available) available = false;
        else if (opt.value === 'xpose4' && !status.xpose4_available) available = false;
        opt.disabled = !available;
        if (opt.disabled && opt.selected) {
            // Select first available tool
            for (var j = 0; j < sel.options.length; j++) {
                if (!sel.options[j].disabled) { sel.selectedIndex = j; break; }
            }
            toggleVpcOptions();
        }
    }
}

function detectVpcFolder() {
    var projDir = document.getElementById('inp-project-dir').value;
    if (!projDir) { alert('Set a project directory first.'); return; }
    if (selectedModelIdx < 0) { alert('Select a model first.'); return; }

    var m = scannedModels[selectedModelIdx];
    var sep = projDir.includes('\\') ? '\\' : '/';
    // PsN vpc creates directories with various naming conventions
    var candidates = [
        projDir + sep + m.stem + '.vpc',
        projDir + sep + m.stem + '_vpc',
        projDir + sep + m.stem + '.dir',
        projDir + sep + m.stem + '.mod.dir',
    ];
    // PsN increments vpc_dir1, vpc_dir2, ...
    for (var i = 10; i >= 1; i--) candidates.push(projDir + sep + 'vpc_dir' + i);

    // Check each candidate via browse API (async would be better, but keep it sync for now)
    // We can't check filesystem from JS — just set the first candidate
    // But we CAN check the model's run_dir if it exists
    if (m.run_dir) {
        // PsN vpc often creates a subfolder under the run dir
        candidates.unshift(m.run_dir);
    }
    document.getElementById('inp-vpc-folder').value = candidates[0];
    // Also populate the run directory for xpose/xpose4
    if (m.run_dir) {
        document.getElementById('inp-xpose-rundir').value = m.run_dir;

    } else {
        document.getElementById('inp-xpose-rundir').value = projDir;

    }
    _autoPopulateRunno();
}

async function generateVPC() {
    var folder = document.getElementById('inp-vpc-folder').value;
    if (!folder) { alert('Select a VPC folder first.'); return; }
    var tool = document.getElementById('sel-vpc-tool').value;

    var payload = { folder: folder, tool: tool };

    if (tool === 'vpc') {
        payload.pred_corr = document.getElementById('chk-vpc-predcorr').checked;
        payload.lloq = document.getElementById('inp-vpc-lloq').value;
        payload.bins = document.getElementById('sel-vpc-bins').value;
        payload.nbins = document.getElementById('inp-vpc-nbins').value;
        payload.stratify = document.getElementById('inp-vpc-strat').value;
        payload.pi = document.getElementById('sel-vpc-pi').value;
        payload.ci = document.getElementById('sel-vpc-ci').value;
        payload.log_y = document.getElementById('chk-vpc-log').checked;
    } else if (tool === 'xpose') {
        payload.runno = document.getElementById('inp-xpose-runno').value;
        payload.run_dir = document.getElementById('inp-xpose-rundir').value;
        payload.stratify = document.getElementById('inp-xpose-strat').value;
        payload.nbins = document.getElementById('inp-xpose-nbins').value;
        payload.lloq = document.getElementById('inp-xpose-lloq').value;
        payload.pred_corr = document.getElementById('chk-xpose-predcorr').checked;
        payload.log_y = document.getElementById('chk-xpose-log').checked;
    } else if (tool === 'xpose4') {
        // xpose4 reads vpctab directly from VPC folder — no extra params needed
    }

    // Bug #10 fix: NEVER send custom_script from generateVPC.
    // Only runCustomVpcScript() should do that.

    // Bug #11 fix: clear stale image before starting
    var container = document.getElementById('vpc-plot-container');
    document.getElementById('vpc-plot-actions').style.display = 'none';
    container.innerHTML = '<div style="padding:30px;text-align:center;color:var(--text-2)">Running R script... this may take a moment.</div>';

    // Bug #12 fix: disable button during execution
    var btn = document.getElementById('btn-generate-vpc');
    btn.disabled = true;
    btn.textContent = 'Running...';

    var result = await postJson('/api/vpc/generate', payload);

    btn.disabled = false;
    btn.textContent = 'Generate VPC';

    if (result.error) {
        var errHtml = '<div style="padding:16px;color:var(--red);font-size:12px">';
        errHtml += '<strong>Error:</strong> ' + escapeHtml(result.error);
        if (result.stderr) errHtml += '<pre style="margin-top:8px;font-size:10px;color:var(--text-2);white-space:pre-wrap">' + escapeHtml(result.stderr) + '</pre>';
        if (result.stdout) errHtml += '<pre style="margin-top:4px;font-size:10px;color:var(--text-2);white-space:pre-wrap">' + escapeHtml(result.stdout) + '</pre>';
        errHtml += '</div>';
        container.innerHTML = errHtml;

        // Show R script for debugging, auto-expand the details
        if (result.r_script) {
            document.getElementById('vpc-r-script').value = result.r_script;
            document.getElementById('vpc-advanced-details').open = true;
        }
        return;
    }

    // Show generated R script (but don't auto-expand on success)
    if (result.r_script) {
        document.getElementById('vpc-r-script').value = result.r_script;
    }

    // Show warnings from R stderr if any
    if (result.stderr && result.stderr.trim()) {
        var warnHtml = '<div style="font-size:10px;color:var(--yellow);padding:4px 8px;margin-bottom:4px">' +
            escapeHtml(result.stderr.trim().substring(0, 200)) + '</div>';
        container.innerHTML = warnHtml;
    } else {
        container.innerHTML = '';
    }

    // Display the image
    var toolLabel = result.tool ? result.tool : tool;
    var imgUrl = '/api/vpc/image?path=' + encodeURIComponent(result.image_path) + '&t=' + Date.now();
    container.innerHTML += '<div style="font-size:10px;color:var(--text-2);margin-bottom:4px;text-align:right">Generated with: ' + escapeHtml(toolLabel) + '</div>';
    container.innerHTML += '<img src="' + imgUrl + '" style="max-width:100%;border-radius:8px;background:#fff" alt="VPC Plot">';
    document.getElementById('vpc-plot-actions').style.display = 'block';
}

async function runCustomVpcScript() {
    var folder = document.getElementById('inp-vpc-folder').value;
    var script = document.getElementById('vpc-r-script').value.trim();
    if (!folder) { alert('Select a VPC folder first.'); return; }
    if (!script) { alert('No R script to run.'); return; }

    var container = document.getElementById('vpc-plot-container');
    document.getElementById('vpc-plot-actions').style.display = 'none';
    container.innerHTML = '<div style="padding:30px;text-align:center;color:var(--text-2)">Running custom R script...</div>';

    var result = await postJson('/api/vpc/generate', {
        folder: folder, tool: 'vpc', custom_script: script
    });

    if (result.error) {
        var errHtml = '<div style="padding:16px;color:var(--red);font-size:12px">';
        errHtml += '<strong>Error:</strong> ' + escapeHtml(result.error);
        if (result.stderr) errHtml += '<pre style="margin-top:8px;font-size:10px;color:var(--text-2);white-space:pre-wrap">' + escapeHtml(result.stderr) + '</pre>';
        errHtml += '</div>';
        container.innerHTML = errHtml;
        return;
    }

    var imgUrl = '/api/vpc/image?path=' + encodeURIComponent(result.image_path) + '&t=' + Date.now();
    container.innerHTML = '<img src="' + imgUrl + '" style="max-width:100%;border-radius:8px;background:#fff" alt="VPC Plot">';
    document.getElementById('vpc-plot-actions').style.display = 'block';
}

function openVpcImage() {
    var img = document.querySelector('#vpc-plot-container img');
    if (img) window.open(img.src, '_blank');
}

function openVpcFolder() {
    var folder = document.getElementById('inp-vpc-folder').value;
    if (!folder) { alert('No VPC folder set.'); return; }
    // Note: this reuses RStudio launcher to open a directory
    postJson('/api/launch/rstudio', { directory: folder });
}
