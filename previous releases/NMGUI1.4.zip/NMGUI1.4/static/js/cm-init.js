/* ═══ NMGUI — CodeMirror 5 Setup with NONMEM Highlighting ═══ */

// ── Define NONMEM mode using CM5 simple mode ───
CodeMirror.defineSimpleMode("nonmem", {
    start: [
        // Comments
        { regex: /;.*/, token: "comment" },

        // Record names ($BLOCKS)
        { regex: /\$(PROBLEM|PROB|DATA|INPUT|SUBROUTINES|SUBS|PK|PRED|ERROR|DES|MODEL|THETA|OMEGA|SIGMA|ESTIMATION|EST|COVARIANCE|COV|TABLE|TAB|SIMULATION|SIM|SIZES|ABBREVIATED|ABBR|BIND|CONTR|INFN|MIX|PRIOR|SCATTER|LEVEL|ANNEAL|CHAIN|ETAS|PHIS|FORMAT|INDXS|MSFI|NONPARAMETRIC|OMIT|SUPER|THETAI|THETAR|THETAP|THETAPV)\b/i,
          token: "keyword" },

        // THETA(n), ETA(n), EPS(n), ERR(n)
        { regex: /\b(?:THETA|ETA|EPS|ERR)\s*\(\s*\d+\s*\)/, token: "variable-3" },

        // Common PK variables
        { regex: /\b(?:TVKA|TVCL|TVV[23P]?|TVQ[2]?|TVMTT|TVNN|TVALAG|CL|V[123P]?|Q[2]?|KA|K(?:1[23]|2[13]|3[1])?|ALAG[12]|F[12]|S[123]|D[12]|R[12])\b/,
          token: "variable-2" },

        // Control flow
        { regex: /\b(?:IF|THEN|ELSE|ENDIF|ELSEIF|DO|ENDDO|WHILE|CALL|EXIT|RETURN|WRITE|PRINT|OPEN|CLOSE|READ|FORMAT|CONTINUE|GOTO)\b/i,
          token: "keyword" },

        // Built-in functions
        { regex: /\b(?:EXP|LOG|LOG10|SQRT|ABS|SIN|COS|TAN|ASIN|ACOS|ATAN|ATAN2|MAX|MIN|MOD|INT|DBLE|FLOAT|DEXP|DLOG|DSQRT|DABS|GAMLN|PHI|ERF|ERFC)\b/i,
          token: "builtin" },

        // NONMEM special variables
        { regex: /\b(?:TIME|TAD|AMT|RATE|DV|PRED|IPRED|IWRES|IRES|WRES|CWRES|RES|EVID|MDV|CMT|SS|II|ADDL|BWT|AGE|SEX|WT|HT|BSA|CRCL|CLcr|BMI|LBM|FFM|GFR|NEWIND|ICALL|IREP|IOSN|NETA|NTHETA|NRD|A_0|DADT|A|Y|F|COM)\b/,
          token: "atom" },

        // Estimation/option keywords
        { regex: /\b(?:FIX|FIXED|SAME|BLOCK|DIAGONAL|BAND|CHOLESKY|CORRELATION|STANDARD|VARIANCE|COVARIANCE|NOABORT|MAXEVAL|SIGDIGITS|PRINT|NOPRINT|POSTHOC|FORMAT|FILE|FIRSTONLY|ONEHEADER|NOHEADER|APPEND|FORWARD|CONDITIONAL|UNCONDITIONAL|MATRIX|NSIG|SIGL|NOOBT|METHOD|INTER|LAPLACIAN|SLOW|NOSLOW|NUMERICAL|NONINFETA|MCETA|ISAMPLE|NITER|SEED|CTYPE|CALPHA|CITER|CINTERVAL|NOHABORT|IGNORE|ACCEPT|RECORDS|LREC|NULL)\b/i,
          token: "qualifier" },

        // Logical operators
        { regex: /\.(?:AND|OR|NOT|EQ|NE|LT|GT|LE|GE|EQN|NEN)\./, token: "operator" },

        // Numbers (scientific notation, Fortran D format)
        { regex: /[-+]?\d*\.?\d+(?:[eEdD][-+]?\d+)?/, token: "number" },

        // Strings
        { regex: /"[^"]*"/, token: "string" },
        { regex: /'[^']*'/, token: "string" },
    ],
    meta: {
        lineComment: ";"
    }
});

// ── Custom dark theme overrides ────────
// (The material-darker theme handles most of it;
//  we add a few NONMEM-specific token colors via CSS below)
(function() {
    var style = document.createElement('style');
    style.textContent = `
        #codemirror-host .CodeMirror {
            height: 100%;
            font-family: 'SF Mono', 'Menlo', 'Monaco', 'Cascadia Code', 'Consolas', monospace;
            font-size: 13px;
            line-height: 1.55;
            background: #171922;
        }
        #codemirror-host .CodeMirror-gutters {
            background: #1e2130;
            border-right: 1px solid #2e3348;
        }
        #codemirror-host .CodeMirror-linenumber {
            color: #5c6370;
        }
        #codemirror-host .CodeMirror-cursor {
            border-left-color: #5b9cf5;
        }
        #codemirror-host .CodeMirror-selected {
            background: rgba(91,156,245,0.2) !important;
        }
        #codemirror-host .CodeMirror-activeline-background {
            background: rgba(91,156,245,0.05);
        }
        #codemirror-host .CodeMirror-matchingbracket {
            color: #e8eaf0 !important;
            background: rgba(91,156,245,0.25);
            outline: 1px solid rgba(91,156,245,0.4);
        }
        /* Token colors */
        .cm-s-material-darker .cm-keyword     { color: #c678dd; font-weight: bold; }
        .cm-s-material-darker .cm-variable-2  { color: #61afef; }
        .cm-s-material-darker .cm-variable-3  { color: #e5c07b; }
        .cm-s-material-darker .cm-builtin     { color: #98c379; }
        .cm-s-material-darker .cm-atom        { color: #56b6c2; }
        .cm-s-material-darker .cm-qualifier   { color: #d19a66; }
        .cm-s-material-darker .cm-number      { color: #d19a66; }
        .cm-s-material-darker .cm-string      { color: #98c379; }
        .cm-s-material-darker .cm-comment     { color: #5c6370; font-style: italic; }
        .cm-s-material-darker .cm-operator    { color: #c678dd; }
    `;
    document.head.appendChild(style);
})();

// ── Initialize the editor ──────────────
var cmEditor = CodeMirror(document.getElementById("codemirror-host"), {
    value: "; Welcome to NMGUI\n; Select a model from the list to start editing\n",
    mode: "nonmem",
    theme: "material-darker",
    lineNumbers: true,
    matchBrackets: true,
    styleActiveLine: true,
    indentUnit: 2,
    tabSize: 2,
    indentWithTabs: false,
    lineWrapping: true,
    extraKeys: {
        "Tab": function(cm) {
            cm.replaceSelection("  ", "end");
        }
    }
});

// ── Expose API to app.js ───────────────
window.cmSetContent = function(text) {
    cmEditor.setValue(text);
    cmEditor.clearHistory();
    cmEditor.markClean();
    // Force a refresh in case the editor was hidden when content was set
    setTimeout(function() { cmEditor.refresh(); }, 1);
    // Reset unsaved indicator
    if (window.cmOnCleanStateChange) window.cmOnCleanStateChange(true);
};

window.cmGetContent = function() {
    return cmEditor.getValue();
};

window.cmIsClean = function() {
    return cmEditor.isClean();
};

window.cmMarkClean = function() {
    cmEditor.markClean();
    if (window.cmOnCleanStateChange) window.cmOnCleanStateChange(true);
};

// Track changes
cmEditor.on('change', function() {
    if (window.cmOnCleanStateChange) {
        window.cmOnCleanStateChange(cmEditor.isClean());
    }
});

window.cmReady = true;

// Apply any queued content
if (window._cmPendingContent !== undefined) {
    window.cmSetContent(window._cmPendingContent);
    delete window._cmPendingContent;
}

console.log("NMGUI: CodeMirror 5 initialized with NONMEM syntax highlighting");
